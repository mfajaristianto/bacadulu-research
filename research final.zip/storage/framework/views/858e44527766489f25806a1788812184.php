<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="robots" content="noindex,nofollow,noarchive">

    <title><?php echo e(trim($__env->yieldContent('title', 'Admin'))); ?> — BacaDulu Research</title>

    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/admin.css',
        'resources/js/app.js',
        'resources/js/admin.js',
    ]); ?>
</head>

<?php
    $adminUserId = session('research_admin_user_id');
    $admin = $adminUserId ? \App\Models\User::query()->find($adminUserId) : null;
    $adminName = $admin?->name ?: 'Administrator';
    $adminEmail = session('research_admin_email') ?: $admin?->email ?: 'admin';

    $adminInitials = collect(preg_split('/\s+/', trim($adminName), -1, PREG_SPLIT_NO_EMPTY))
        ->take(2)
        ->map(fn ($part) => mb_strtoupper(mb_substr($part, 0, 1)))
        ->implode('');

    $aiProvider = strtolower((string) config('research.ai_provider', 'mock'));
    $aiLive = ! in_array($aiProvider, ['mock', 'unconfigured', ''], true);

    /*
     * Sidebar IA. Labels are plain Indonesian; route names are unchanged.
     */
    $menu = [
        [
            'label' => null,
            'items' => [
                ['name' => 'admin.dashboard', 'label' => 'Beranda', 'icon' => 'overview', 'match' => ['admin.dashboard']],
            ],
        ],
        [
            'label' => 'Sumber & Pustaka',
            'items' => [
                ['name' => 'admin.library.index', 'label' => 'Pustaka', 'icon' => 'library', 'match' => ['admin.library.*']],
                ['name' => 'admin.source-sync.index', 'label' => 'Impor Sumber', 'icon' => 'sync', 'match' => ['admin.source-sync.*']],
                ['name' => 'admin.categories.index', 'label' => 'Kategori', 'icon' => 'category', 'match' => ['admin.categories.*']],
                ['name' => 'admin.collections.index', 'label' => 'Koleksi', 'icon' => 'collection', 'match' => ['admin.collections.*']],
                ['name' => 'admin.glossary.index', 'label' => 'Glosarium', 'icon' => 'glossary', 'match' => ['admin.glossary.*']],
            ],
        ],
        [
            'label' => 'Alat Riset',
            'items' => [
                ['name' => 'admin.tools.index', 'label' => 'Alat Riset', 'icon' => 'tools', 'match' => ['admin.tools.*']],
                ['name' => 'admin.prompts.index', 'label' => 'Instruksi AI', 'icon' => 'prompt', 'match' => ['admin.prompts.*']],
                ['name' => 'admin.prompt-versions.index', 'label' => 'Versi Instruksi', 'icon' => 'versions', 'match' => ['admin.prompt-versions.*']],
                ['name' => 'admin.document-templates.index', 'label' => 'Template Dokumen', 'icon' => 'template', 'match' => ['admin.document-templates.*']],
            ],
        ],
        [
            'label' => 'Pemantauan',
            'items' => [
                ['name' => 'admin.ai-runs.index', 'label' => 'Riwayat Riset', 'icon' => 'runs', 'match' => ['admin.ai-runs.*']],
                ['name' => 'admin.audit.index', 'label' => 'Log Aktivitas', 'icon' => 'audit', 'match' => ['admin.audit.*']],
            ],
        ],
        [
            'label' => 'Pengguna & Sistem',
            'items' => [
                ['name' => 'admin.users.index', 'label' => 'Pengguna', 'icon' => 'users', 'match' => ['admin.users.*']],
                ['name' => 'admin.security.index', 'label' => 'Keamanan', 'icon' => 'security', 'match' => ['admin.security.*']],
                ['name' => 'admin.settings.index', 'label' => 'Pengaturan', 'icon' => 'settings', 'match' => ['admin.settings.*']],
            ],
        ],
    ];
?>

<body class="bd-admin">
    <a href="#admin-content" class="bd-admin__skip">Lewati ke konten</a>

    <div class="bd-admin__mobile-overlay" data-admin-overlay></div>

    <aside id="admin-sidebar" class="bd-admin__sidebar" data-admin-sidebar aria-label="Menu administrator">
        <div class="bd-admin__sidebar-head">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="bd-admin__brand" aria-label="BacaDulu Research — panel admin">
                <span class="bd-admin__brand-mark" aria-hidden="true">
                    <svg viewBox="0 0 48 48" fill="none">
                        <path d="M5 10c8-3 14-2 19 3v28c-6-5-12-6-19-3V10Z" />
                        <path d="M43 10c-8-3-14-2-19 3v28c6-5 12-6 19-3V10Z" />
                        <path d="M24 13v28" />
                    </svg>
                </span>
                <span class="bd-admin__brand-word">
                    <strong>BacaDulu</strong>
                    <small>Panel Admin</small>
                </span>
            </a>

            <button type="button" class="bd-admin__mobile-close" data-admin-sidebar-close aria-label="Tutup menu admin">
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18" /></svg>
            </button>
        </div>

        <nav class="bd-admin__nav" aria-label="Navigasi administrator">
            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <section class="bd-admin__nav-section">
                    <?php if($section['label']): ?>
                        <span class="bd-admin__nav-label"><?php echo e($section['label']); ?></span>
                    <?php endif; ?>

                    <?php $__currentLoopData = $section['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $exists = \Illuminate\Support\Facades\Route::has($item['name']);
                            $active = collect($item['match'])->contains(fn ($pattern) => request()->routeIs($pattern));
                        ?>

                        <?php if($exists): ?>
                            <a
                                href="<?php echo e(route($item['name'])); ?>"
                                class="bd-admin__nav-item <?php echo e($active ? 'is-active' : ''); ?>"
                                <?php if($active): ?> aria-current="page" <?php endif; ?>
                            >
                                <span class="bd-admin__nav-icon"><?php echo $__env->make('admin.partials.nav-icon', ['icon' => $item['icon']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>
                                <span class="bd-admin__nav-copy"><?php echo e($item['label']); ?></span>
                            </a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>

        <div class="bd-admin__sidebar-foot">
            <div class="bd-admin__admin-card">
                <span class="bd-admin__admin-avatar" aria-hidden="true"><?php echo e($adminInitials ?: 'AD'); ?></span>
                <div>
                    <strong><?php echo e($adminName); ?></strong>
                    <small><?php echo e($adminEmail); ?></small>
                </div>
            </div>

            <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="bd-admin__logout">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3" /><path d="M10 17l5-5-5-5" /><path d="M15 12H4" /></svg>
                    Keluar
                </button>
            </form>
        </div>
    </aside>

    <main class="bd-admin__main">
        <header class="bd-admin__topbar">
            <div class="bd-admin__topbar-left">
                <button
                    type="button"
                    class="bd-admin__mobile-menu"
                    data-admin-sidebar-open
                    aria-label="Buka menu admin"
                    aria-expanded="false"
                    aria-controls="admin-sidebar"
                >
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16" /></svg>
                </button>

                <p class="bd-admin__topbar-title"><?php echo $__env->yieldContent('page_title', 'Beranda'); ?></p>
            </div>

            <div class="bd-admin__topbar-right">
                <a
                    href="<?php echo e(route('admin.settings.index')); ?>"
                    class="bd-admin__system <?php echo e($aiLive ? 'is-live' : 'is-mock'); ?>"
                    title="Layanan AI yang aktif saat ini"
                >
                    <i aria-hidden="true"></i>
                    Layanan AI: <?php echo e($aiLive ? strtoupper($aiProvider) : 'Mode uji (mock)'); ?>

                </a>

                <a href="<?php echo e(route('home')); ?>" target="_blank" rel="noopener" class="bd-admin__site-link">
                    Lihat situs <span aria-hidden="true">↗</span>
                </a>
            </div>
        </header>

        <div class="bd-admin__content" id="admin-content">
            <?php if(session('success')): ?>
                <div class="bd-admin__flash bd-admin__flash--success" role="status" data-admin-toast>
                    <span></span>
                    <p><?php echo e(session('success')); ?></p>
                </div>
            <?php endif; ?>

            <?php if(session('warning')): ?>
                <div class="bd-admin__flash bd-admin__flash--warning" role="status">
                    <span></span>
                    <p><?php echo e(session('warning')); ?></p>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="bd-admin__flash bd-admin__flash--error" role="alert">
                    <span></span>
                    <p><?php echo e(session('error')); ?></p>
                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="bd-admin__flash bd-admin__flash--error" role="alert">
                    <span></span>
                    <p><?php echo e($errors->first()); ?></p>
                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
</body>
</html>
<?php /**PATH D:\Pkl\bacadulu-research\resources\views/layouts/admin.blade.php ENDPATH**/ ?>
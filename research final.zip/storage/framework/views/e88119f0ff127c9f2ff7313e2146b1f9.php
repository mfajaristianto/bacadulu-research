
<div class="research-prompt-menu" id="research-prompt-menu" data-prompt-menu role="listbox" aria-label="Pilih Research Tool" hidden>
    <header class="research-prompt-menu__head">
        <div>
            <span>RESEARCH TOOLS</span>
            <strong>Pilih cara analisis</strong>
            <p>Temukan pendekatan yang sesuai untuk pertanyaan research Anda.</p>
        </div>
        <button type="button" data-prompt-close aria-label="Tutup pilihan prompt">×</button>
    </header>
    <div class="research-prompt-menu__body">
        <?php $__empty_1 = true; $__currentLoopData = $prompts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prompt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="research-prompt-option-row">
                <button type="button" class="research-prompt-option" role="option"
                    aria-selected="<?php echo e((int) $activePrompt?->id === (int) $prompt->id ? 'true' : 'false'); ?>"
                    data-prompt-id="<?php echo e($prompt->id); ?>"
                    data-prompt-name="<?php echo e($prompt->display_name); ?>"
                    data-prompt-tool="<?php echo e($prompt->aiTool?->name ?: 'Research Tool'); ?>"
                    data-prompt-description="<?php echo e($prompt->short_description ?: $prompt->aiTool?->description ?: 'Research prompt'); ?>">
                    <span class="research-prompt-option__index"><?php echo e(str_pad((string)$loop->iteration,2,'0',STR_PAD_LEFT)); ?></span>
                    <span class="research-prompt-option__icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">
                            <?php switch($loop->iteration % 4):
                                case (0): ?><path d="M4 18h16M7 15V9M12 15V5M17 15v-4"/><?php break; ?>
                                <?php case (1): ?><circle cx="10" cy="10" r="5"/><path d="m14 14 6 6M8 10h4M10 8v4"/><?php break; ?>
                                <?php case (2): ?><path d="M4 6h16M4 12h11M4 18h8"/><circle cx="18" cy="15" r="3"/><?php break; ?>
                                <?php default: ?><rect x="4" y="4" width="16" height="16" rx="3"/><path d="M8 12h8M12 8v8"/>
                            <?php endswitch; ?>
                        </svg>
                    </span>
                    <span class="research-prompt-option__copy">
                        <strong><?php echo e($prompt->name); ?></strong>
                        <?php if($prompt->indonesian_name): ?><small class="research-prompt-option__translation"><?php echo e($prompt->indonesian_name); ?></small><?php endif; ?>
                        <p><?php echo e($prompt->short_description ?: $prompt->aiTool?->description ?: 'Penjelasan prompt belum tersedia.'); ?></p>
                    </span>
                    <span class="research-prompt-option__arrow" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 12h14m-6-6 6 6-6 6"/></svg>
                    </span>
                </button>
                <button type="button" class="research-prompt-info-button" popovertarget="prompt-info-<?php echo e($prompt->id); ?>" popovertargetaction="show"
                    aria-label="Apa ini: <?php echo e($prompt->name); ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v5m0-8h.01"/></svg>
                    Apa ini?
                </button>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="research-prompt-menu__empty">Belum ada Research Tool yang aktif.</div>
        <?php endif; ?>
    </div>
    <footer class="research-prompt-menu__motion-note">Pilih tool untuk menyesuaikan pendekatan analisis.</footer>
</div>
<?php /**PATH D:\Pkl\bacadulu-research\resources\views/research/workspace/prompt-menu.blade.php ENDPATH**/ ?>
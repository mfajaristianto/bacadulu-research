<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="robots" content="noindex,nofollow,noarchive">

    <title><?php echo e(trim($__env->yieldContent('title', 'Admin'))); ?> — BacaDulu Research</title>

    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/admin.css',
        'resources/js/app.js',
        'resources/js/admin.js',
    ]); ?>
</head>
<body class="bd-admin-auth">
    <a href="#admin-auth-form" class="bd-admin-auth__skip">Lewati ke formulir</a>

    <main class="bd-admin-auth__page">
        <div class="bd-admin-auth__card" id="admin-auth-form">
            <a href="<?php echo e(route('home')); ?>" class="bd-admin-auth__brand" aria-label="BacaDulu Research — beranda">
                <span class="bd-admin-auth__mark" aria-hidden="true">
                    <svg viewBox="0 0 48 48" fill="none">
                        <path d="M5 10c8-3 14-2 19 3v28c-6-5-12-6-19-3V10Z" />
                        <path d="M43 10c-8-3-14-2-19 3v28c6-5 12-6 19-3V10Z" />
                        <path d="M24 13v28" />
                    </svg>
                </span>
                <span>BacaDulu <em>Research</em></span>
            </a>

            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <footer class="bd-admin-auth__footer">
            <span>© <?php echo e(now()->year); ?> BacaDulu Research</span>
            <a href="<?php echo e(route('home')); ?>">Kembali ke situs <span aria-hidden="true">↗</span></a>
        </footer>
    </main>
</body>
</html>
<?php /**PATH D:\Pkl\bacadulu-research\resources\views/layouts/admin-auth.blade.php ENDPATH**/ ?>
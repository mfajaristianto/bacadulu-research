<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <meta
        name="csrf-token"
        content="<?php echo e(csrf_token()); ?>"
    >

    <meta
        name="description"
        content="<?php echo $__env->yieldContent(
            'meta_description',
            'BacaDulu Research membantu pengguna bergerak dari pertanyaan penelitian menuju evidence, insight, dan dokumen yang siap digunakan.'
        ); ?>"
    >

    <meta
        name="theme-color"
        content="#17172B"
    >

    <title>
        <?php echo $__env->yieldContent('title', 'BacaDulu Research'); ?>
    </title>

    <link
        rel="icon"
        type="image/x-icon"
        href="<?php echo e(asset('favicon.ico')); ?>"
    >

    
    <link
        rel="preload"
        href="<?php echo e(asset('fonts/plus-jakarta-sans-latin-wght-normal.woff2')); ?>"
        as="font"
        type="font/woff2"
        crossorigin
    >

    
    <?php echo app('Illuminate\Foundation\Vite')(array_values(array_filter([
        'resources/css/app.css',
        'resources/js/app.js',
        request()->routeIs('home') ? 'resources/js/landing-motion.js' : null,
        request()->routeIs('workspace*') ? 'resources/js/workspace-ui.js' : null,
        request()->routeIs('workspace*', 'saved.*', 'documents.*') ? 'resources/js/research-output.js' : null,
        request()->routeIs('login', 'register', 'password.*', 'google.link.*') ? 'resources/js/auth-research.js' : null,
        request()->routeIs('register.success', 'workspace*') ? 'resources/js/bacadulu-onboarding.js' : null,
    ]))); ?>

    
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<?php
    /*
    |--------------------------------------------------------------------------
    | AUTH PORTAL
    |--------------------------------------------------------------------------
    */

    $isAuthPortal = request()->routeIs(
        'login',
        'register',
        'register.success',
        'google.link.*',
        'password.*'
    );


    /*
    |--------------------------------------------------------------------------
    | WORKSPACE
    |--------------------------------------------------------------------------
    |
    | Khusus halaman research workspace.
    |
    | Variable ini tetap terpisah karena dipakai untuk:
    | - Prompt Question Map
    | - Research prompt runtime
    | - Workspace-only JavaScript data
    |
    */

    $isWorkspace = request()->routeIs(
        'workspace*'
    );


    /*
    |--------------------------------------------------------------------------
    | RESEARCH SHELL
    |--------------------------------------------------------------------------
    |
    | Semua halaman yang memakai UI Research:
    |
    | - Workspace
    | - Saved
    |
    | Halaman di dalam shell ini TIDAK memakai:
    | - navbar publik
    | - footer publik
    |
    | dan mendapatkan class:
    |
    | research-chat-body
    |
    */

     $isResearchShell = request()->routeIs(
    'workspace*',
    'saved.*',
    'profile.edit',
    'documents.*'
    );


    /*
    |--------------------------------------------------------------------------
    | USER-FACING QUESTION TEMPLATE MAP
    |--------------------------------------------------------------------------
    |
    | Data yang dikirim ke browser hanya:
    |
    | - Prompt ID
    | - Question Template
    |
    | System Prompt, Task Prompt,
    | Retrieval Instructions, dan
    | Output Instructions tetap di server.
    |
    */

    $promptQuestionMap = [];

    if (
        $isWorkspace
        && isset($prompts)
    ) {
        $promptQuestionMap = collect(
            $prompts
        )
            ->mapWithKeys(
                function ($prompt): array {
                    return [
                        (string) $prompt->id =>
                            (string) (
                                $prompt->question_template
                                ?: ''
                            ),
                    ];
                }
            )
            ->all();
    }
?>


<body
    class="<?php echo e(collect([
            $isResearchShell
                ? 'research-chat-body'
                : null,

            $isAuthPortal
                ? 'research-auth-body'
                : null,

            trim(
                (string) $__env->yieldContent(
                    'body_class'
                )
            )
                ?: null,
        ])
            ->filter()
            ->implode(' ')); ?>"
>

    
    <a
        class="skip-link"
        href="#main-content"
    >
        Lewati ke konten utama
    </a>


    
    <?php if(
        ! $isAuthPortal
        && ! $isResearchShell
    ): ?>
        <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>


    
    <main id="main-content">
        <?php echo $__env->yieldContent('content'); ?>
    </main>


    
    <?php if(
        ! $isAuthPortal
        && ! $isResearchShell
    ): ?>
        <?php echo $__env->make('components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>


    <?php if($isResearchShell): ?>
        <nav class="br-mobile-tabs" aria-label="Navigasi Research mobile">
            <a href="<?php echo e(route('workspace')); ?>" class="<?php echo e(request()->routeIs('workspace*') ? 'is-active' : ''); ?>" <?php if(request()->routeIs('workspace*')): ?> aria-current="page" <?php endif; ?>><span aria-hidden="true"><svg viewBox="0 0 24 24"><path d="m3 11 9-8 9 8v10h-7v-7h-4v7H3z"/></svg></span>Research</a>
            <a href="<?php echo e(route('saved.index')); ?>" class="<?php echo e(request()->routeIs('saved.*') ? 'is-active' : ''); ?>" <?php if(request()->routeIs('saved.*')): ?> aria-current="page" <?php endif; ?>><span aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M6 3h12v18l-6-4-6 4z"/></svg></span>Saved</a>
            <a href="<?php echo e(route('documents.index')); ?>" class="<?php echo e(request()->routeIs('documents.*') ? 'is-active' : ''); ?>" <?php if(request()->routeIs('documents.*')): ?> aria-current="page" <?php endif; ?>><span aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M6 2h9l4 4v16H6zM15 2v5h5M9 12h7M9 16h7"/></svg></span>Dokumen</a>
            <a href="<?php echo e(route('profile.edit')); ?>" class="<?php echo e(request()->routeIs('profile.edit') ? 'is-active' : ''); ?>" <?php if(request()->routeIs('profile.edit')): ?> aria-current="page" <?php endif; ?>><span aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-5 3-7 8-7s8 2 8 7"/></svg></span>Profil</a>
        </nav>
    <?php endif; ?>

    
    <div
        class="network-banner"
        data-network-banner
        role="status"
        aria-live="polite"
        hidden
    >
        Anda sedang offline. Input yang belum dikirim tetap dipertahankan di halaman ini.
    </div>


    
    <?php if(
        $isWorkspace
        && ! empty($promptQuestionMap)
    ): ?>
        <script
            type="application/json"
            data-prompt-question-map
        ><?php echo json_encode(
            $promptQuestionMap,
            JSON_HEX_TAG
            | JSON_HEX_AMP
            | JSON_HEX_APOS
            | JSON_HEX_QUOT
        ); ?></script>
    <?php endif; ?>


    
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html><?php /**PATH D:\Pkl\bacadulu-research\resources\views/layouts/app.blade.php ENDPATH**/ ?>
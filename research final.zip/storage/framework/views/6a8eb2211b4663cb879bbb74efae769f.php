<?php $__env->startSection('title', 'Library'); ?>
<?php $__env->startSection('page_title', 'Library'); ?>

<?php $__env->startSection('content'); ?>

<section class="admin-page">

    <header class="bd-admin-page-head">

        <div
            class="bd-admin-page-head__copy"
            data-admin-reveal
        >
            <p class="bd-admin-kicker">
                KNOWLEDGE / LIBRARY
            </p>

            <h1>
                Curated Sources
            </h1>

            <p>
                Semua PDF yang menjadi sumber retrieval dan evidence.
                Source harus memiliki chunks sebelum dapat dipublish.
            </p>
        </div>


        <div
            class="bd-admin-page-head__actions"
            data-admin-reveal
            data-reveal-from="right"
        >

            <a
                href="<?php echo e(route('admin.categories.index')); ?>"
                class="
                    bd-admin-button
                    bd-admin-button--ghost
                "
            >
                Categories
            </a>


            <a
                href="<?php echo e(route('admin.collections.index')); ?>"
                class="
                    bd-admin-button
                    bd-admin-button--ghost
                "
            >
                Collections
            </a>


            <a
                href="<?php echo e(route('admin.library.create')); ?>"
                class="
                    bd-admin-button
                    bd-admin-button--primary
                "
            >
                Tambah Source

                <span aria-hidden="true">
                    ＋
                </span>
            </a>

        </div>

    </header>


    <form
        method="GET"
        action="<?php echo e(route('admin.library.index')); ?>"
        class="bd-admin-filter"
        data-admin-reveal
        data-reveal-delay="60"
    >

        <input
            class="bd-admin-input"
            type="search"
            name="search"
            value="<?php echo e(request('search')); ?>"
            maxlength="160"
            placeholder="Cari judul source…"
            aria-label="Cari judul source"
        >


        <select
            class="bd-admin-select"
            name="category"
            aria-label="Filter kategori"
        >

            <option value="">
                Semua kategori
            </option>

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <option
                    value="<?php echo e($category->id); ?>"
                    <?php if(
                        (string) request('category')
                        ===
                        (string) $category->id
                    ): echo 'selected'; endif; ?>
                >
                    <?php echo e($category->name); ?>

                </option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>


        <select
            class="bd-admin-select"
            name="status"
            aria-label="Filter status"
            data-auto-submit
        >

            <option value="">
                Semua status
            </option>

            <?php $__currentLoopData = [
                    'draft',
                    'processing',
                    'ready',
                    'published',
                    'archived',
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <option
                    value="<?php echo e($status); ?>"
                    <?php if(
                        request('status')
                        ===
                        $status
                    ): echo 'selected'; endif; ?>
                >
                    <?php echo e(ucfirst($status)); ?>

                </option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

    </form>


    <?php if($documents->isEmpty()): ?>

        <div
            class="bd-admin-empty"
            data-admin-reveal
            data-reveal-delay="100"
        >

            <div class="bd-admin-empty__inner">

                <span class="bd-admin-empty__mark">
                    SOURCE LAYER
                </span>

                <h3>
                    Belum ada source yang cocok.
                </h3>


                <?php if(
                    request()->hasAny(
                        [
                            'search',
                            'category',
                            'status',
                        ]
                    )
                ): ?>

                    <p>
                        Filter aktif tidak menemukan source.
                        Reset filter atau tambahkan source baru.
                    </p>

                <?php else: ?>

                    <p>
                        Mulai dengan judul, kategori, dan PDF.
                        Sistem akan memproses file menjadi chunks
                        sebelum source dipublish.
                    </p>

                <?php endif; ?>


                <div class="bd-admin-empty__actions">

                    <a
                        href="<?php echo e(route('admin.library.create')); ?>"
                        class="
                            bd-admin-button
                            bd-admin-button--primary
                        "
                    >
                        Tambah Source
                    </a>


                    <?php if(
                        request()->hasAny(
                            [
                                'search',
                                'category',
                                'status',
                            ]
                        )
                    ): ?>

                        <a
                            href="<?php echo e(route('admin.library.index')); ?>"
                            class="
                                bd-admin-button
                                bd-admin-button--ghost
                            "
                        >
                            Reset Filter
                        </a>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    <?php else: ?>

        <div
            class="bd-admin-table-wrap"
            data-admin-reveal
            data-reveal-delay="100"
        >

            <table class="bd-admin-table">

                <thead>

                    <tr>
                        <th>Source</th>
                        <th>Kategori</th>
                        <th>PDF</th>
                        <th>Chunks</th>
                        <th>Status</th>
                        <th></th>
                    </tr>

                </thead>


                <tbody>

                    <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>

                            <td>

                                <div
                                    class="
                                        bd-library-source-cell
                                    "
                                >

                                    <span
                                        class="
                                            bd-library-pdf-mini
                                        "
                                        aria-hidden="true"
                                    >

                                        <i>
                                            PDF
                                        </i>

                                        <b>
                                            <?php echo e(\Illuminate\Support\Str::limit(
                                                    $document->title,
                                                    45
                                                )); ?>

                                        </b>

                                        <em>
                                            SRC-<?php echo e(str_pad(
                                                    $document->id,
                                                    4,
                                                    '0',
                                                    STR_PAD_LEFT
                                                )); ?>

                                        </em>

                                    </span>


                                    <div
                                        class="
                                            bd-admin-table__title
                                        "
                                    >

                                        <strong>
                                            <?php echo e($document->title); ?>

                                        </strong>

                                        <small>
                                            SRC-<?php echo e(str_pad(
                                                    $document->id,
                                                    4,
                                                    '0',
                                                    STR_PAD_LEFT
                                                )); ?>


                                            ·

                                            <?php echo e(optional(
                                                    $document->updated_at
                                                )->format(
                                                    'd M Y · H:i'
                                                )); ?>

                                        </small>

                                    </div>

                                </div>

                            </td>


                            <td>
                                <?php echo e($document->category?->name
                                    ?: '—'); ?>

                            </td>


                            <td>

                                <span
                                    class="
                                        bd-admin-status
                                        bd-admin-status--<?php echo e($document->files_count > 0
                                                ? 'ready'
                                                : 'failed'); ?>

                                    "
                                >
                                    <?php echo e($document->files_count > 0
                                            ? 'Available'
                                            : 'Missing'); ?>

                                </span>

                            </td>


                            <td>
                                <?php echo e($document->chunks_count); ?>

                            </td>


                            <td>

                                <span
                                    class="
                                        bd-admin-status
                                        bd-admin-status--<?php echo e($document->status); ?>

                                    "
                                >
                                    <?php echo e(ucfirst(
                                            $document->status
                                        )); ?>

                                </span>

                            </td>


                            <td>

                                <a
                                    class="
                                        bd-admin-table__action
                                    "
                                    href="<?php echo e(route(
                                            'admin.library.edit',
                                            $document
                                        )); ?>"
                                >
                                    Kelola →
                                </a>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>

            </table>

        </div>


        <div style="margin-top:18px;">
            <?php echo e($documents->links()); ?>

        </div>

    <?php endif; ?>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/library/index.blade.php ENDPATH**/ ?>
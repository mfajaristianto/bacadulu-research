<?php $__env->startSection('title', 'Beranda Admin'); ?>
<?php $__env->startSection('page_title', 'Beranda'); ?>

<?php
    $aiProvider = strtolower((string) config('research.ai_provider', 'mock'));
    $aiLive = ! in_array($aiProvider, ['mock', 'unconfigured', ''], true);

    /* Plain-language labels for raw status codes. */
    $statusLabels = [
        'draft' => 'Draf',
        'queued' => 'Antre',
        'processing' => 'Diproses',
        'ready' => 'Siap terbit',
        'published' => 'Terbit',
        'archived' => 'Diarsipkan',
        'failed' => 'Gagal',
        'retrieving' => 'Mencari sumber',
        'evidence_ready' => 'Bukti siap',
        'generating' => 'Menyusun jawaban',
        'completed' => 'Selesai',
        'insufficient_evidence' => 'Bukti kurang',
        'citation_failed' => 'Sitasi tidak valid',
    ];

    $statusTone = fn (?string $status) => match ($status) {
        'published', 'completed' => 'success',
        'ready', 'evidence_ready' => 'info',
        'processing', 'queued', 'retrieving', 'generating', 'draft' => 'neutral',
        'insufficient_evidence' => 'warning',
        'failed', 'citation_failed' => 'danger',
        default => 'neutral',
    };

    $activityLabels = [
        'admin.login' => 'Admin masuk ke panel',
        'admin.logout' => 'Admin keluar dari panel',
        'admin.login.failed' => 'Percobaan login admin gagal',
        'source.created' => 'Sumber baru ditambahkan',
        'source.updated' => 'Sumber diperbarui',
        'source.published' => 'Sumber diterbitkan',
        'source.unpublished' => 'Sumber ditarik dari publikasi',
        'source.archived' => 'Sumber diarsipkan',
        'source.ingestion_queued' => 'Sumber masuk antrean pemrosesan',
        'source.ingestion_completed' => 'Pemrosesan sumber selesai',
        'source.ingestion_failed' => 'Pemrosesan sumber gagal',
        'research.completed' => 'Riset pengguna selesai',
        'research.failed' => 'Riset pengguna gagal',
        'research.citation_failed' => 'Riset ditahan karena sitasi tidak valid',
        'settings.updated' => 'Pengaturan diperbarui',
        'prompt.activated' => 'Versi instruksi AI diaktifkan',
    ];

    $needsAction = collect([
        [
            'show' => ($stats['failed'] ?? 0) > 0,
            'tone' => 'danger',
            'count' => $stats['failed'] ?? 0,
            'title' => 'sumber gagal diproses',
            'hint' => 'Periksa file PDF lalu proses ulang.',
            'href' => route('admin.library.index', ['status' => 'failed']),
            'cta' => 'Periksa',
        ],
        [
            'show' => ($stats['ready'] ?? 0) > 0,
            'tone' => 'info',
            'count' => $stats['ready'] ?? 0,
            'title' => 'sumber siap diterbitkan',
            'hint' => 'Sudah diproses, tetapi belum bisa dipakai pengguna sampai diterbitkan.',
            'href' => route('admin.library.index', ['status' => 'ready']),
            'cta' => 'Terbitkan',
        ],
        [
            'show' => ($stats['sync_pending'] ?? 0) > 0 && \Illuminate\Support\Facades\Route::has('admin.source-sync.index'),
            'tone' => 'info',
            'count' => $stats['sync_pending'] ?? 0,
            'title' => 'item impor menunggu ditinjau',
            'hint' => 'Pilih kategori lalu impor atau abaikan.',
            'href' => \Illuminate\Support\Facades\Route::has('admin.source-sync.index') ? route('admin.source-sync.index') : '#',
            'cta' => 'Tinjau',
        ],
        [
            'show' => ($stats['runs_failed_today'] ?? 0) > 0,
            'tone' => 'warning',
            'count' => $stats['runs_failed_today'] ?? 0,
            'title' => 'riset pengguna gagal hari ini',
            'hint' => 'Lihat penyebabnya di riwayat riset.',
            'href' => route('admin.ai-runs.index', ['status' => 'failed']),
            'cta' => 'Lihat',
        ],
        [
            'show' => ! $aiLive,
            'tone' => 'warning',
            'count' => null,
            'title' => 'Layanan AI masih mode uji (mock)',
            'hint' => 'Jawaban riset belum memakai layanan AI sungguhan.',
            'href' => route('admin.settings.index'),
            'cta' => 'Pengaturan',
        ],
    ])->where('show', true)->values();
?>

<?php $__env->startSection('content'); ?>
<section class="admin-page bd-dash">
    <header class="bd-admin-page-head">
        <div class="bd-admin-page-head__copy">
            <p class="bd-admin-kicker"><?php echo e(now()->translatedFormat('l, d F Y')); ?></p>
            <h1>Halo, apa yang perlu diurus hari ini?</h1>
            <p>Ringkasan pustaka, riset pengguna, dan hal yang membutuhkan tindakan.</p>
        </div>

        <div class="bd-admin-page-head__actions">
            <?php if(\Illuminate\Support\Facades\Route::has('admin.source-sync.index')): ?>
                <a href="<?php echo e(route('admin.source-sync.index')); ?>" class="bd-admin-button bd-admin-button--ghost">Impor sumber</a>
            <?php endif; ?>
            <a href="<?php echo e(route('admin.library.create')); ?>" class="bd-admin-button bd-admin-button--primary">+ Tambah sumber</a>
        </div>
    </header>

    
    <section class="bd-dash__card bd-dash__attention" aria-labelledby="dash-attention-title">
        <div class="bd-dash__card-head">
            <h2 id="dash-attention-title">Perlu tindakan</h2>
            <?php if($needsAction->isNotEmpty()): ?>
                <span class="bd-dash__count"><?php echo e($needsAction->count()); ?></span>
            <?php endif; ?>
        </div>

        <?php if($needsAction->isEmpty()): ?>
            <div class="bd-dash__all-clear">
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 4.5 4.5L19 7" /></svg>
                <div>
                    <strong>Semua aman.</strong>
                    <span>Tidak ada sumber gagal, sumber menunggu terbit, atau riset gagal hari ini.</span>
                </div>
            </div>
        <?php else: ?>
            <ul class="bd-dash__tasks">
                <?php $__currentLoopData = $needsAction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="bd-dash__task bd-dash__task--<?php echo e($task['tone']); ?>">
                        <span class="bd-dash__task-dot" aria-hidden="true"></span>
                        <div class="bd-dash__task-copy">
                            <strong>
                                <?php if(! is_null($task['count'])): ?><?php echo e(number_format($task['count'])); ?> <?php endif; ?><?php echo e($task['title']); ?>

                            </strong>
                            <span><?php echo e($task['hint']); ?></span>
                        </div>
                        <a href="<?php echo e($task['href']); ?>" class="bd-admin-button bd-admin-button--ghost"><?php echo e($task['cta']); ?> →</a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </section>

    
    <ul class="bd-dash__stats" aria-label="Ringkasan">
        <li>
            <span>Sumber terbit</span>
            <strong><?php echo e(number_format($stats['published'] ?? 0)); ?></strong>
            <small>dari <?php echo e(number_format($stats['sources'] ?? 0)); ?> sumber di pustaka</small>
        </li>
        <li>
            <span>Sedang diproses</span>
            <strong><?php echo e(number_format($stats['processing'] ?? 0)); ?></strong>
            <small>sumber dalam antrean</small>
        </li>
        <li>
            <span>Riset hari ini</span>
            <strong><?php echo e(number_format($stats['runs_today'] ?? 0)); ?></strong>
            <small>permintaan dari pengguna</small>
        </li>
        <li>
            <span>Pengguna</span>
            <strong><?php echo e(number_format($stats['users'] ?? 0)); ?></strong>
            <small>akun terdaftar</small>
        </li>
    </ul>

    <div class="bd-dash__grid">
        
        <section class="bd-dash__card" aria-labelledby="dash-sources-title">
            <div class="bd-dash__card-head">
                <h2 id="dash-sources-title">Sumber terbaru</h2>
                <a href="<?php echo e(route('admin.library.index')); ?>" class="bd-admin-table__action">Buka pustaka →</a>
            </div>

            <?php if($recentDocuments->isEmpty()): ?>
                <div class="bd-dash__empty">
                    <p>Pustaka masih kosong. Tambahkan PDF pertama agar pengguna bisa mulai riset.</p>
                    <a href="<?php echo e(route('admin.library.create')); ?>" class="bd-admin-button bd-admin-button--primary">+ Tambah sumber</a>
                </div>
            <?php else: ?>
                <ul class="bd-dash__list">
                    <?php $__currentLoopData = $recentDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('admin.library.edit', $document->id)); ?>" class="bd-dash__row">
                                <span class="bd-dash__row-main">
                                    <strong><?php echo e($document->title); ?></strong>
                                    <small>
                                        <?php echo e($document->category_name ?? 'Tanpa kategori'); ?>

                                        · diperbarui <?php echo e(\Carbon\Carbon::parse($document->updated_at)->diffForHumans()); ?>

                                    </small>
                                </span>
                                <span class="bd-dash__badge bd-dash__badge--<?php echo e($statusTone($document->status)); ?>">
                                    <?php echo e($statusLabels[$document->status] ?? ucfirst($document->status)); ?>

                                </span>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </section>

        
        <section class="bd-dash__card" aria-labelledby="dash-activity-title">
            <div class="bd-dash__card-head">
                <h2 id="dash-activity-title">Aktivitas terbaru</h2>
                <a href="<?php echo e(route('admin.audit.index')); ?>" class="bd-admin-table__action">Log lengkap →</a>
            </div>

            <?php if($recentActivity->isEmpty()): ?>
                <div class="bd-dash__empty"><p>Belum ada aktivitas tercatat.</p></div>
            <?php else: ?>
                <ol class="bd-dash__timeline">
                    <?php $__currentLoopData = $recentActivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <strong><?php echo e($activityLabels[$activity->action] ?? str($activity->action)->replace(['.', '_'], ' ')->ucfirst()); ?></strong>
                            <small><?php echo e(\Carbon\Carbon::parse($activity->created_at)->diffForHumans()); ?></small>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            <?php endif; ?>
        </section>
    </div>

    
    <?php if($recentRuns->isNotEmpty()): ?>
        <section class="bd-dash__card" aria-labelledby="dash-runs-title">
            <div class="bd-dash__card-head">
                <h2 id="dash-runs-title">Riset terbaru dari pengguna</h2>
                <a href="<?php echo e(route('admin.ai-runs.index')); ?>" class="bd-admin-table__action">Semua riwayat →</a>
            </div>

            <div class="bd-admin-table-wrap">
                <table class="bd-admin-table">
                    <thead>
                        <tr>
                            <th scope="col">Riset</th>
                            <th scope="col">Alat riset</th>
                            <th scope="col">Status</th>
                            <th scope="col">Waktu</th>
                            <th scope="col"><span class="bd-admin__sr-only">Aksi</span></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $recentRuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $run): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><strong>RUN-<?php echo e(str_pad($run->id, 5, '0', STR_PAD_LEFT)); ?></strong></td>
                                <td><?php echo e($run->tool_name ?? '—'); ?></td>
                                <td>
                                    <span class="bd-dash__badge bd-dash__badge--<?php echo e($statusTone($run->status)); ?>">
                                        <?php echo e($statusLabels[$run->status] ?? str($run->status)->replace('_', ' ')->title()); ?>

                                    </span>
                                </td>
                                <td><?php echo e(\Carbon\Carbon::parse($run->created_at)->format('d M · H:i')); ?></td>
                                <td><a href="<?php echo e(route('admin.ai-runs.show', $run->id)); ?>" class="bd-admin-table__action">Detail →</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </section>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
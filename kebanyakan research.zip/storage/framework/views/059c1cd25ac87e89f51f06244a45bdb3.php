<?php $__env->startSection('title', 'Research Operations'); ?>
<?php $__env->startSection('page_title', 'Overview'); ?>

<?php $__env->startSection('content'); ?>

<section class="admin-page">

    <header class="bd-admin-page-head">

        <div
            class="bd-admin-page-head__copy"
            data-admin-reveal
        >
            <p class="bd-admin-kicker">
                RESEARCH OPERATIONS
            </p>

            <h1>
                Operasi research yang perlu diperhatikan hari ini.
            </h1>

            <p>
                Fokus pada source, prompt, dan AI run yang memerlukan tindakan.
                Bukan dashboard statistik dekoratif.
            </p>
        </div>

        <div
            class="bd-admin-page-head__actions"
            data-admin-reveal
            data-reveal-from="right"
        >
            <a
                href="<?php echo e(route('admin.library.create')); ?>"
                class="
                    bd-admin-button
                    bd-admin-button--primary
                "
            >
                Tambah Source

                <span aria-hidden="true">
                    ＋
                </span>
            </a>
        </div>

    </header>

    <div
        class="bd-admin-inline-actions"
        style="
            justify-content:flex-start;
            margin-bottom:18px;
        "
    >
        <a
            href="<?php echo e(route('admin.library.index')); ?>"
            class="bd-admin-link-button"
        >
            Library
        </a>

        <a
            href="<?php echo e(route('admin.categories.index')); ?>"
            class="bd-admin-link-button"
        >
            Categories
        </a>

        <a
            href="<?php echo e(route('admin.tools.index')); ?>"
            class="bd-admin-link-button"
        >
            Research Tools
        </a>

        <a
            href="<?php echo e(route('admin.prompts.index')); ?>"
            class="bd-admin-link-button"
        >
            Prompts
        </a>

        <a
            href="<?php echo e(route('admin.ai-runs.index')); ?>"
            class="bd-admin-link-button"
        >
            AI Runs
        </a>
    </div>

    <section
        class="bd-admin-ops"
        data-admin-reveal
        data-reveal-delay="60"
    >

        <div class="bd-admin-ops__main">

            <span class="bd-admin-ops__label">
                WORK QUEUE
            </span>

            <h2 class="bd-admin-ops__question">
                Yang perlu ditindak, bukan sekadar dihitung.
            </h2>

            <div class="bd-admin-queue">

                <article class="bd-admin-queue__item">

                    <strong>
                        <?php echo e($stats['processing'] ?? 0); ?>

                    </strong>

                    <div>
                        <strong>
                            Source sedang diproses
                        </strong>

                        <small>
                            PDF belum selesai menjadi evidence.
                        </small>
                    </div>

                    <a
                        href="<?php echo e(route(
                                'admin.library.index',
                                [
                                    'status'
                                    =>
                                    'processing',
                                ]
                            )); ?>"
                    >
                        Periksa →
                    </a>

                </article>

                <article class="bd-admin-queue__item">

                    <strong>
                        <?php echo e($stats['failed'] ?? 0); ?>

                    </strong>

                    <div>
                        <strong>
                            Source membutuhkan perhatian
                        </strong>

                        <small>
                            Ingestion atau lifecycle perlu ditinjau.
                        </small>
                    </div>

                    <a
                        href="<?php echo e(route(
                                'admin.library.index'
                            )); ?>"
                    >
                        Library →
                    </a>

                </article>

                <article class="bd-admin-queue__item">

                    <strong>
                        <?php echo e($stats['prompts'] ?? 0); ?>

                    </strong>

                    <div>
                        <strong>
                            Prompt Versions
                        </strong>

                        <small>
                            Kontrol instruction yang digunakan Research Tool.
                        </small>
                    </div>

                    <a
                        href="<?php echo e(route(
                                'admin.prompt-versions.index'
                            )); ?>"
                    >
                        Kelola →
                    </a>

                </article>

                <article class="bd-admin-queue__item">

                    <strong>
                        <?php echo e($stats['runs_today'] ?? 0); ?>

                    </strong>

                    <div>
                        <strong>
                            AI Runs hari ini
                        </strong>

                        <small>
                            Audit retrieval, evidence, provider, dan citation.
                        </small>
                    </div>

                    <a
                        href="<?php echo e(route(
                                'admin.ai-runs.index'
                            )); ?>"
                    >
                        Lihat →
                    </a>

                </article>

            </div>

        </div>

        <aside class="bd-admin-ops__side">

            <span class="bd-admin-ops__label">
                SYSTEM PULSE
            </span>

            <div class="bd-admin-pulse">

                <div class="bd-admin-pulse__row">
                    <span>
                        Library
                    </span>

                    <strong>
                        <?php echo e($stats['sources'] ?? 0); ?>

                        sources
                    </strong>
                </div>

                <div class="bd-admin-pulse__row">
                    <span>
                        Published
                    </span>

                    <strong>
                        <?php echo e($stats['published'] ?? 0); ?>

                    </strong>
                </div>

                <div class="bd-admin-pulse__row">
                    <span>
                        Chunks
                    </span>

                    <strong>
                        <?php echo e(number_format(
                                $stats['chunks']
                                ?? 0
                            )); ?>

                    </strong>
                </div>

                <div class="bd-admin-pulse__row">
                    <span>
                        Research Tools
                    </span>

                    <strong>
                        <?php echo e($stats['tools'] ?? 0); ?>

                    </strong>
                </div>

                <div class="bd-admin-pulse__row">
                    <span>
                        Users
                    </span>

                    <strong>
                        <?php echo e($stats['users'] ?? 0); ?>

                    </strong>
                </div>

                <div class="bd-admin-pulse__row">
                    <span>
                        AI Provider
                    </span>

                    <strong>
                        <?php echo e(strtoupper(
                                config(
                                    'research.ai_provider',
                                    'mock'
                                )
                            )); ?>

                    </strong>
                </div>

            </div>

        </aside>

    </section>

    <section
        class="bd-admin-section"
        data-admin-reveal
        data-reveal-delay="100"
    >

        <div class="bd-admin-section__head">

            <div>
                <h2>
                    Recent Sources
                </h2>

                <p>
                    Source terakhir yang berubah di Library.
                </p>
            </div>

            <a
                href="<?php echo e(route('admin.library.index')); ?>"
                class="bd-admin-table__action"
            >
                Buka Library →
            </a>

        </div>

        <?php if($recentDocuments->isEmpty()): ?>

            <div class="bd-admin-empty">

                <div class="bd-admin-empty__inner">

                    <span class="bd-admin-empty__mark">
                        SOURCE LAYER
                    </span>

                    <h3>
                        Library masih kosong.
                    </h3>

                    <p>
                        Tambahkan PDF pertama agar sistem dapat membangun
                        evidence layer untuk Research Tools.
                    </p>

                    <div class="bd-admin-empty__actions">

                        <a
                            href="<?php echo e(route('admin.library.create')); ?>"
                            class="
                                bd-admin-button
                                bd-admin-button--primary
                            "
                        >
                            Tambah Source
                        </a>

                        <a
                            href="<?php echo e(route('admin.categories.index')); ?>"
                            class="
                                bd-admin-button
                                bd-admin-button--ghost
                            "
                        >
                            Kelola Category
                        </a>

                    </div>

                </div>

            </div>

        <?php else: ?>

            <div class="bd-admin-table-wrap">

                <table class="bd-admin-table">

                    <thead>
                        <tr>
                            <th>Source</th>
                            <th>Kategori</th>
                            <th>Chunks</th>
                            <th>Status</th>
                            <th>Updated</th>
                            <th></th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $recentDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td>
                                    <div class="bd-admin-table__title">
                                        <strong>
                                            <?php echo e($document->title); ?>

                                        </strong>

                                        <small>
                                            SRC-<?php echo e(str_pad(
                                                    $document->id,
                                                    4,
                                                    '0',
                                                    STR_PAD_LEFT
                                                )); ?>

                                        </small>
                                    </div>
                                </td>

                                <td>
                                    <?php echo e($document->category_name
                                        ?? '—'); ?>

                                </td>

                                <td>
                                    <?php echo e($document->chunks_count
                                        ?? 0); ?>

                                </td>

                                <td>
                                    <span
                                        class="
                                            bd-admin-status
                                            bd-admin-status--<?php echo e($document->status); ?>

                                        "
                                    >
                                        <?php echo e(ucfirst(
                                                $document->status
                                            )); ?>

                                    </span>
                                </td>

                                <td>
                                    <?php echo e(\Carbon\Carbon::parse(
                                            $document->updated_at
                                        )->format(
                                            'd M · H:i'
                                        )); ?>

                                </td>

                                <td>
                                    <a
                                        href="<?php echo e(route(
                                                'admin.library.edit',
                                                $document->id
                                            )); ?>"
                                        class="bd-admin-table__action"
                                    >
                                        Kelola →
                                    </a>
                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>

            </div>

        <?php endif; ?>

    </section>

    <?php if($recentRuns->isNotEmpty()): ?>

        <section
            class="bd-admin-section"
            data-admin-reveal
            data-reveal-delay="140"
        >

            <div class="bd-admin-section__head">

                <div>
                    <h2>
                        Recent AI Runs
                    </h2>

                    <p>
                        Execution terbaru yang tercatat untuk audit.
                    </p>
                </div>

                <a
                    href="<?php echo e(route('admin.ai-runs.index')); ?>"
                    class="bd-admin-table__action"
                >
                    Semua AI Runs →
                </a>

            </div>

            <div class="bd-admin-table-wrap">

                <table class="bd-admin-table">

                    <thead>
                        <tr>
                            <th>Run</th>
                            <th>Research Tool</th>
                            <th>Model</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th></th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $recentRuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $run): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td>
                                    <strong>
                                        RUN-<?php echo e(str_pad(
                                                $run->id,
                                                5,
                                                '0',
                                                STR_PAD_LEFT
                                            )); ?>

                                    </strong>
                                </td>

                                <td>
                                    <?php echo e($run->tool_name
                                        ?? '—'); ?>

                                </td>

                                <td>
                                    <?php echo e($run->model_name
                                        ?? '—'); ?>

                                </td>

                                <td>
                                    <span
                                        class="
                                            bd-admin-status
                                            bd-admin-status--<?php echo e($run->status); ?>

                                        "
                                    >
                                        <?php echo e(str(
                                                $run->status
                                            )
                                                ->replace(
                                                    '_',
                                                    ' '
                                                )
                                                ->title()); ?>

                                    </span>
                                </td>

                                <td>
                                    <?php echo e(\Carbon\Carbon::parse(
                                            $run->created_at
                                        )->format(
                                            'd M · H:i'
                                        )); ?>

                                </td>

                                <td>
                                    <a
                                        href="<?php echo e(route(
                                                'admin.ai-runs.show',
                                                $run->id
                                            )); ?>"
                                        class="bd-admin-table__action"
                                    >
                                        Trace →
                                    </a>
                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>

            </div>

        </section>

    <?php endif; ?>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
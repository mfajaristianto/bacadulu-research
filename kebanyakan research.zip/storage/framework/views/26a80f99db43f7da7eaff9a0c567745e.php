<?php $__env->startSection('title', 'AI Runs'); ?>
<?php $__env->startSection('page_title', 'AI Runs'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-page">
    <header class="bd-admin-page-head">
        <div class="bd-admin-page-head__copy">
            <p class="bd-admin-kicker">AI CONTROL / RUNS</p>
            <h1>AI Runs</h1>
            <p>Observability untuk request → prompt → retrieval → evidence → citation → result. Read-only.</p>
        </div>
    </header>

    <form method="GET" action="<?php echo e(route('admin.ai-runs.index')); ?>" class="bd-admin-filter">
        <input class="bd-admin-input" type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="Run UUID, user, tool, prompt…">
        <select class="bd-admin-select" name="status" onchange="this.form.submit()">
            <option value="">Semua status</option>
            <?php $__currentLoopData = ['queued','retrieving','evidence_ready','generating','completed','insufficient_evidence','citation_failed','failed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($status); ?>" <?php if(request('status') === $status): echo 'selected'; endif; ?>><?php echo e(str($status)->replace('_',' ')->title()); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select class="bd-admin-select" name="provider" onchange="this.form.submit()">
            <option value="">Semua provider</option>
            <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($provider); ?>" <?php if(request('provider') === $provider): echo 'selected'; endif; ?>><?php echo e(strtoupper($provider)); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </form>

    <div class="bd-admin-table-wrap">
        <table class="bd-admin-table">
            <thead><tr><th>Run</th><th>User / Conversation</th><th>Research Tool</th><th>Evidence</th><th>Provider</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $runs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $run): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><div class="bd-admin-table__title"><strong>RUN-<?php echo e(str_pad($run->id, 5, '0', STR_PAD_LEFT)); ?></strong><small><?php echo e(Str::limit($run->uuid, 18)); ?></small></div></td>
                    <td><div class="bd-admin-table__title"><strong><?php echo e($run->user?->name ?: '—'); ?></strong><small><?php echo e($run->assistantMessage?->conversation?->title ?: $run->user?->email ?: '—'); ?></small></div></td>
                    <td><div class="bd-admin-table__title"><strong><?php echo e($run->aiTool?->name ?: '—'); ?></strong><small><?php echo e($run->promptTemplate ? $run->promptTemplate->name.' · v'.$run->promptTemplate->version : 'No prompt recorded'); ?></small></div></td>
                    <td><strong><?php echo e($run->retrievals_count); ?></strong><small> retrievals · <?php echo e($run->valid_citations_count); ?> valid citations <?php if($run->invalid_citations_count): ?> · <?php echo e($run->invalid_citations_count); ?> invalid <?php endif; ?></small></td>
                    <td><div class="bd-admin-table__title"><strong><?php echo e(strtoupper($run->model_provider ?: '—')); ?></strong><small><?php echo e($run->model_name ?: '—'); ?></small></div></td>
                    <td><span class="bd-admin-status bd-admin-status--<?php echo e(in_array($run->status, ['completed','evidence_ready'], true) ? 'success' : (in_array($run->status, ['failed','citation_failed'], true) ? 'failed' : (in_array($run->status, ['insufficient_evidence'], true) ? 'warning' : 'processing'))); ?>"><?php echo e(str($run->status)->replace('_',' ')->title()); ?></span></td>
                    <td><a class="bd-admin-table__action" href="<?php echo e(route('admin.ai-runs.show', $run)); ?>">Trace →</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7"><div class="bd-admin-empty"><div class="bd-admin-empty__inner"><span class="bd-admin-empty__mark">RUN</span><h3>Belum ada AI Run.</h3><p>Execution akan muncul setelah user menjalankan Research Tool.</p></div></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo e($runs->links()); ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/ai-runs/index.blade.php ENDPATH**/ ?>
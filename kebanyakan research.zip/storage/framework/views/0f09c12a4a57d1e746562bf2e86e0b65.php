

<?php $__env->startSection('title', 'Source Sync'); ?>
<?php $__env->startSection('page_title', 'Source Sync'); ?>

<?php $__env->startSection('content'); ?>

<section class="admin-page">

    <header class="bd-admin-page-head">

        <div
            class="bd-admin-page-head__copy"
            data-admin-reveal
        >
            <p class="bd-admin-kicker">
                KNOWLEDGE / SOURCE SYNC
            </p>

            <h1>
                Source Connector Staging
            </h1>

            <p>
                Ambil daftar source dari connector, bandingkan checksum,
                review perubahan, lalu ingest ke Library.
                Source hasil sync berhenti di status Ready dan tidak dipublish otomatis.
            </p>
        </div>

        <div
            class="bd-admin-page-head__actions"
            data-admin-reveal
            data-reveal-from="right"
        >

            <a
                href="<?php echo e(route('admin.library.index')); ?>"
                class="bd-admin-button bd-admin-button--ghost"
            >
                Library
            </a>

            <form
                method="POST"
                action="<?php echo e(route('admin.source-sync.scan')); ?>"
            >
                <?php echo csrf_field(); ?>

                <button
                    type="submit"
                    class="bd-admin-button bd-admin-button--primary"
                >
                    Scan Sources

                    <span aria-hidden="true">
                        ↻
                    </span>
                </button>
            </form>

        </div>

    </header>

    <div
        class="bd-admin-note"
        data-admin-reveal
        data-reveal-delay="50"
    >
        <strong>
            Connector aktif:
            <?php echo e(strtoupper($provider)); ?>

        </strong>

        <p>
            Auto-publish:
            <strong>
                <?php echo e($autoPublish ? 'ON' : 'OFF'); ?>

            </strong>.

            Tahap lokal memakai connector mock untuk menguji alur
            Discover → Checksum/Diff → Review → Ingest → Ready.
        </p>
    </div>

    <?php if($selectedRun): ?>

        <?php
            $runStatusClass =
                match(
                    $selectedRun->status
                ) {
                    'completed' =>
                        'completed',

                    'review_ready' =>
                        'warning',

                    'completed_with_errors' =>
                        'warning',

                    'failed' =>
                        'failed',

                    default =>
                        'running',
                };
        ?>

        <section
            data-admin-reveal
            data-reveal-delay="80"
            style="margin-top:22px;"
        >

            <header
                class="bd-admin-page-head"
                style="margin-bottom:12px;"
            >

                <div class="bd-admin-page-head__copy">

                    <p class="bd-admin-kicker">
                        REVIEW RUN
                    </p>

                    <h1 style="font-size:24px;">
                        Sync #<?php echo e($selectedRun->id); ?>

                        ·
                        <?php echo e(strtoupper($selectedRun->connector)); ?>

                    </h1>

                    <p>
                        <?php echo e($selectedRun->discovered_count); ?>

                        ditemukan ·

                        <?php echo e($selectedRun->new_count); ?>

                        baru ·

                        <?php echo e($selectedRun->changed_count); ?>

                        berubah ·

                        <?php echo e($selectedRun->unchanged_count); ?>

                        tidak berubah ·

                        <?php echo e($selectedRun->imported_count); ?>

                        diimport ·

                        <?php echo e($selectedRun->ignored_count); ?>

                        diabaikan.
                    </p>

                </div>

                <span
                    class="
                        bd-admin-status
                        bd-admin-status--<?php echo e($runStatusClass); ?>

                    "
                >
                    <?php echo e(strtoupper(
                            str_replace(
                                '_',
                                ' ',
                                $selectedRun->status
                            )
                        )); ?>

                </span>

            </header>

            <?php if($items->isEmpty()): ?>

                <div class="bd-admin-empty">

                    <div class="bd-admin-empty__inner">

                        <span class="bd-admin-empty__mark">
                            NO ITEMS
                        </span>

                        <h3>
                            Run ini tidak mempunyai source item.
                        </h3>

                        <p>
                            Jalankan scan baru atau periksa konfigurasi connector.
                        </p>

                    </div>

                </div>

            <?php else: ?>

                <div class="bd-admin-table-wrap">

                    <table class="bd-admin-table">

                        <thead>

                            <tr>
                                <th>Source</th>
                                <th>Diff</th>
                                <th>Checksum</th>
                                <th>Library Match</th>
                                <th>Review</th>
                            </tr>

                        </thead>

                        <tbody>

                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php
                                    $itemStatusClass =
                                        match(
                                            $item->status
                                        ) {
                                            'new' =>
                                                'ready',

                                            'changed' =>
                                                'warning',

                                            'unchanged' =>
                                                'completed',

                                            'imported' =>
                                                'success',

                                            'failed' =>
                                                'failed',

                                            'ignored' =>
                                                'draft',

                                            default =>
                                                'draft',
                                        };
                                ?>

                                <tr>

                                    <td>

                                        <div class="bd-admin-table__title">

                                            <strong>
                                                <?php echo e($item->title); ?>

                                            </strong>

                                            <small>
                                                <?php echo e($item->external_id); ?>

                                                ·
                                                <?php echo e(strtoupper($item->connector)); ?>

                                            </small>

                                            <?php if($item->remote_updated_at): ?>

                                                <small>
                                                    Remote update
                                                    <?php echo e($item
                                                            ->remote_updated_at
                                                            ->format(
                                                                'd M Y H:i'
                                                            )); ?>

                                                </small>

                                            <?php endif; ?>

                                        </div>

                                    </td>

                                    <td>

                                        <span
                                            class="
                                                bd-admin-status
                                                bd-admin-status--<?php echo e($itemStatusClass); ?>

                                            "
                                        >
                                            <?php echo e(strtoupper($item->status)); ?>

                                        </span>

                                        <?php if($item->error_message): ?>

                                            <small
                                                style="
                                                    display:block;
                                                    margin-top:6px;
                                                    color:#a33e36;
                                                    max-width:260px;
                                                "
                                            >
                                                <?php echo e($item->error_message); ?>

                                            </small>

                                        <?php endif; ?>

                                    </td>

                                    <td>

                                        <code
                                            title="<?php echo e($item->external_checksum); ?>"
                                        >
                                            <?php echo e($item->external_checksum
                                                    ? substr(
                                                        $item->external_checksum,
                                                        0,
                                                        12
                                                    ).'…'
                                                    : '—'); ?>

                                        </code>

                                        <?php if($item->previous_checksum): ?>

                                            <small
                                                style="
                                                    display:block;
                                                    margin-top:4px;
                                                "
                                            >
                                                Prev
                                                <?php echo e(substr(
                                                        $item->previous_checksum,
                                                        0,
                                                        10
                                                    )); ?>…
                                            </small>

                                        <?php endif; ?>

                                    </td>

                                    <td>

                                        <?php if($item->importedDocument): ?>

                                            <div class="bd-admin-table__title">

                                                <strong>
                                                    <?php echo e($item->importedDocument->title); ?>

                                                </strong>

                                                <small>
                                                    Library
                                                    #<?php echo e($item->importedDocument->id); ?>

                                                    ·
                                                    <?php echo e(strtoupper(
                                                            $item
                                                                ->importedDocument
                                                                ->status
                                                        )); ?>

                                                </small>

                                            </div>

                                        <?php elseif($item->matchedDocument): ?>

                                            <div class="bd-admin-table__title">

                                                <strong>
                                                    <?php echo e($item->matchedDocument->title); ?>

                                                </strong>

                                                <small>
                                                    Existing
                                                    #<?php echo e($item->matchedDocument->id); ?>

                                                    ·
                                                    <?php echo e(strtoupper(
                                                            $item
                                                                ->matchedDocument
                                                                ->status
                                                        )); ?>

                                                </small>

                                            </div>

                                        <?php else: ?>

                                            <small>
                                                Belum ada source lokal.
                                            </small>

                                        <?php endif; ?>

                                    </td>

                                    <td>

                                        <?php if(
                                            in_array(
                                                $item->status,
                                                [
                                                    'new',
                                                    'changed',
                                                ],
                                                true
                                            )
                                        ): ?>

                                            <form
                                                method="POST"
                                                action="<?php echo e(route('admin.source-sync.import', $item)); ?>"
                                                class="bd-admin-inline-actions"
                                                style="
                                                    justify-content:flex-start;
                                                    min-width:300px;
                                                "
                                            >

                                                <?php echo csrf_field(); ?>

                                                <select
                                                    name="category_id"
                                                    class="bd-admin-select"
                                                    required
                                                    style="width:165px;"
                                                    aria-label="Kategori import untuk <?php echo e($item->title); ?>"
                                                >

                                                    <option value="">
                                                        Pilih kategori
                                                    </option>

                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <option
                                                            value="<?php echo e($category->id); ?>"
                                                            <?php if(
                                                                (string)
                                                                    old(
                                                                        'category_id'
                                                                    )
                                                                ===
                                                                (string)
                                                                    $category
                                                                        ->id
                                                            ): echo 'selected'; endif; ?>
                                                        >
                                                            <?php echo e($category->name); ?>

                                                        </option>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </select>

                                                <button
                                                    type="submit"
                                                    class="
                                                        bd-admin-button
                                                        bd-admin-button--primary
                                                    "
                                                >
                                                    Import → Ready
                                                </button>

                                            </form>

                                            <form
                                                method="POST"
                                                action="<?php echo e(route('admin.source-sync.ignore', $item)); ?>"
                                                style="margin-top:7px;"
                                            >

                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>

                                                <button
                                                    type="submit"
                                                    class="bd-admin-link-button"
                                                >
                                                    Abaikan item
                                                </button>

                                            </form>

                                        <?php elseif(
                                            $item->status === 'imported'
                                            &&
                                            $item->importedDocument
                                        ): ?>

                                            <a
                                                href="<?php echo e(route('admin.library.edit', $item->importedDocument)); ?>"
                                                class="bd-admin-table__action"
                                            >
                                                Review di Library →
                                            </a>

                                        <?php elseif(
                                            $item->status
                                            ===
                                            'unchanged'
                                        ): ?>

                                            <small>
                                                Tidak perlu tindakan.
                                            </small>

                                        <?php elseif(
                                            $item->status
                                            ===
                                            'ignored'
                                        ): ?>

                                            <small>
                                                Diabaikan oleh admin.
                                            </small>

                                        <?php else: ?>

                                            <small>
                                                Jalankan scan baru bila source remote berubah.
                                            </small>

                                        <?php endif; ?>

                                    </td>

                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </section>

    <?php else: ?>

        <div
            class="bd-admin-empty"
            data-admin-reveal
            data-reveal-delay="80"
            style="margin-top:22px;"
        >

            <div class="bd-admin-empty__inner">

                <span class="bd-admin-empty__mark">
                    SOURCE CONNECTOR
                </span>

                <h3>
                    Belum ada Source Sync run.
                </h3>

                <p>
                    Klik Scan Sources. Connector hanya membuat staging item;
                    Library tidak diubah sampai admin memilih Import.
                </p>

            </div>

        </div>

    <?php endif; ?>

    <?php if($runs->isNotEmpty()): ?>

        <section
            data-admin-reveal
            data-reveal-delay="120"
            style="margin-top:28px;"
        >

            <header
                class="bd-admin-page-head"
                style="margin-bottom:12px;"
            >

                <div class="bd-admin-page-head__copy">

                    <p class="bd-admin-kicker">
                        SYNC HISTORY
                    </p>

                    <h1 style="font-size:24px;">
                        Run History
                    </h1>

                </div>

            </header>

            <div class="bd-admin-table-wrap">

                <table class="bd-admin-table">

                    <thead>
                        <tr>
                            <th>Run</th>
                            <th>Connector</th>
                            <th>Discovered</th>
                            <th>Diff</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $runs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $run): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php
                                $historyStatusClass =
                                    match(
                                        $run->status
                                    ) {
                                        'completed' =>
                                            'completed',

                                        'review_ready' =>
                                            'warning',

                                        'completed_with_errors' =>
                                            'warning',

                                        'failed' =>
                                            'failed',

                                        default =>
                                            'running',
                                    };
                            ?>

                            <tr>

                                <td>

                                    <div class="bd-admin-table__title">

                                        <strong>
                                            #<?php echo e($run->id); ?>

                                        </strong>

                                        <small>
                                            <?php echo e($run
                                                    ->created_at
                                                    ?->format(
                                                        'd M Y H:i:s'
                                                    )); ?>

                                        </small>

                                    </div>

                                </td>

                                <td>
                                    <?php echo e(strtoupper($run->connector)); ?>

                                </td>

                                <td>
                                    <?php echo e($run->discovered_count); ?>

                                </td>

                                <td>

                                    <small>
                                        New <?php echo e($run->new_count); ?>

                                        ·
                                        Changed <?php echo e($run->changed_count); ?>

                                        ·
                                        Same <?php echo e($run->unchanged_count); ?>

                                        ·
                                        Imported <?php echo e($run->imported_count); ?>

                                    </small>

                                </td>

                                <td>

                                    <span
                                        class="
                                            bd-admin-status
                                            bd-admin-status--<?php echo e($historyStatusClass); ?>

                                        "
                                    >
                                        <?php echo e(strtoupper(
                                                str_replace(
                                                    '_',
                                                    ' ',
                                                    $run->status
                                                )
                                            )); ?>

                                    </span>

                                </td>

                                <td>

                                    <a
                                        href="<?php echo e(route(
                                                'admin.source-sync.index',
                                                [
                                                    'run' =>
                                                        $run->id,
                                                ]
                                            )); ?>"
                                        class="bd-admin-table__action"
                                    >
                                        Review →
                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>

            </div>

            <div style="margin-top:14px;">
                <?php echo e($runs->links()); ?>

            </div>

        </section>

    <?php endif; ?>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/source-sync/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Saved Research — BacaDulu Research'); ?>

<?php $__env->startSection('body_class', 'saved-library-body'); ?>

<?php $__env->startSection('content'); ?>

<?php
    use Illuminate\Support\Str;

    $groups = $savedResults->groupBy('group_key');
    // Chart only uses the current authenticated user's Saved results.
    $savedToolCounts = $savedResults
        ->groupBy(fn ($item) => trim((string) ($item->tool_name ?: 'Research Umum')))
        ->map(fn ($items) => $items->count())
        ->sortDesc()
        ->take(7);
    $savedChartMax = max(1, (int) ($savedToolCounts->max() ?: 0));

    $sidebarConversations = $pinnedConversations
        ->concat($recentConversations)
        ->unique('id')
        ->take(5);

    $initials = collect(
        preg_split('/\s+/', trim($user->name))
    )
        ->filter()
        ->take(2)
        ->map(fn ($part) => Str::upper(Str::substr($part, 0, 1)))
        ->implode('');

    $initials = $initials ?: 'BR';
?>


<div
    class="saved-shell"
    data-saved-library
    data-saved-user="<?php echo e($user->id); ?>"
>

    
    <header class="saved-topbar">

        <div class="saved-topbar__brand-wrap">

            <button
                type="button"
                class="saved-mobile-menu"
                data-chat-sidebar-open
                aria-label="Buka menu"
            >
                <span></span>
                <span></span>
                <span></span>
            </button>


            <a
                href="<?php echo e(route('workspace')); ?>"
                class="saved-topbar__brand"
            >
                <span>BacaDulu</span>
                <strong>Research</strong>
            </a>

        </div>


        <div class="saved-topbar__actions">

            
            <div class="saved-topbar-dropdown">

                <button
                    type="button"
                    class="saved-workspace-trigger"
                    data-saved-workspace-trigger
                    aria-expanded="false"
                >
                    <span class="saved-workspace-trigger__icon">
                        <svg viewBox="0 0 24 24" fill="none">
                            <path d="M5 5h14v14H5z"/>
                            <path d="M9 9h6"/>
                            <path d="M9 13h6"/>
                        </svg>
                    </span>

                    <span>
                        Personal Workspace
                    </span>

                    <svg
                        class="saved-workspace-trigger__chevron"
                        viewBox="0 0 20 20"
                        fill="none"
                    >
                        <path d="m6 8 4 4 4-4"/>
                    </svg>
                </button>


                <div
                    class="saved-workspace-menu"
                    data-saved-workspace-menu
                    hidden
                >
                    <span class="saved-workspace-menu__label">
                        WORKSPACE
                    </span>

                    <a href="<?php echo e(route('workspace')); ?>">
                        <svg viewBox="0 0 24 24" fill="none">
                            <path d="M12 5v14"/>
                            <path d="M5 12h14"/>
                        </svg>

                        <span>
                            <strong>New Research</strong>
                            <small>Mulai research baru</small>
                        </span>
                    </a>

                    <a
                        href="<?php echo e(route('saved.index')); ?>"
                        class="is-active"
                    >
                        <svg viewBox="0 0 24 24" fill="none">
                            <path d="M6 4h12v17l-6-4-6 4z"/>
                        </svg>

                        <span>
                            <strong>Saved</strong>
                            <small>Research yang disimpan</small>
                        </span>
                    </a>
<a href="<?php echo e(route('profile.edit')); ?>">
                        <svg viewBox="0 0 24 24" fill="none">
                            <circle cx="12" cy="8" r="3"/>
                            <path d="M6 20c0-4 2.5-6 6-6s6 2 6 6"/>
                        </svg>

                        <span>
                            <strong>Profile</strong>
                            <small>Profil dan identitas</small>
                        </span>
                    </a>

                </div>
            </div>


            
            <div class="saved-topbar-dropdown">

                <button
                    type="button"
                    class="saved-help-trigger"
                    data-saved-help-trigger
                    aria-label="Bantuan Saved Research"
                >
                    <svg viewBox="0 0 24 24" fill="none">
                        <circle cx="12" cy="12" r="9"/>
                        <path d="M9.8 9a2.4 2.4 0 0 1 4.6 1c0 2-2.4 2.2-2.4 4"/>
                        <path d="M12 17h.01"/>
                    </svg>
                </button>


                <div
                    class="saved-help-menu"
                    data-saved-help-menu
                    hidden
                >
                    <div class="saved-help-menu__head">
                        <div>
                            <span>SAVED RESEARCH</span>
                            <strong>Cara kerja Saved</strong>
                        </div>

                        <button
                            type="button"
                            data-saved-help-close
                        >
                            ×
                        </button>
                    </div>

                    <article>
                        <b>01</b>

                        <div>
                            <strong>Simpan research penting</strong>
                            <p>
                                Jawaban dan dokumen yang disimpan akan
                                terkumpul di halaman ini.
                            </p>
                        </div>
                    </article>

                    <article>
                        <b>02</b>

                        <div>
                            <strong>Temukan kembali dengan cepat</strong>
                            <p>
                                Gunakan pencarian, tipe hasil, atau topik
                                untuk mempersempit daftar.
                            </p>
                        </div>
                    </article>

                    <article>
                        <b>03</b>

                        <div>
                            <strong>Lanjutkan research</strong>
                            <p>
                                Jawaban research dapat dibuka kembali ke
                                conversation asal di Workspace.
                            </p>
                        </div>
                    </article>
                </div>

            </div>


            <span class="saved-topbar__divider"></span>


            
            <a
                href="<?php echo e(route('profile.edit')); ?>"
                class="saved-user"
            >
                <?php if($user->avatar_url): ?>
                    <img
                        src="<?php echo e($user->avatar_url); ?>"
                        alt="<?php echo e($user->name); ?>"
                        referrerpolicy="no-referrer"
                    >
                <?php else: ?>
                    <span class="saved-user__avatar">
                        <?php echo e($initials); ?>

                    </span>
                <?php endif; ?>

                <span class="saved-user__info">
                    <strong>
                        <?php echo e($user->name); ?>

                    </strong>

                    <small>
                        Researcher
                    </small>
                </span>

                <svg viewBox="0 0 20 20" fill="none">
                    <path d="m6 8 4 4 4-4"/>
                </svg>
            </a>

        </div>

    </header>


    <div class="saved-shell__body">

        
        <?php if (isset($component)) { $__componentOriginal20d10595a218a074cc18d48f8c3127ed = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal20d10595a218a074cc18d48f8c3127ed = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.research-sidebar','data' => ['conversation' => null,'pinnedConversations' => $pinnedConversations,'recentConversations' => $recentConversations]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('research-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['conversation' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(null),'pinned-conversations' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pinnedConversations),'recent-conversations' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($recentConversations)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal20d10595a218a074cc18d48f8c3127ed)): ?>
<?php $attributes = $__attributesOriginal20d10595a218a074cc18d48f8c3127ed; ?>
<?php unset($__attributesOriginal20d10595a218a074cc18d48f8c3127ed); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal20d10595a218a074cc18d48f8c3127ed)): ?>
<?php $component = $__componentOriginal20d10595a218a074cc18d48f8c3127ed; ?>
<?php unset($__componentOriginal20d10595a218a074cc18d48f8c3127ed); ?>
<?php endif; ?>
        <button type="button" class="research-sidebar-backdrop" data-chat-sidebar-backdrop aria-label="Tutup navigasi Research"></button>

        
        <main class="saved-page">

            <div class="saved-page__primary">

                
                <header class="saved-page__hero">
                    <h1>
                        Saved Research
                    </h1>

                    <p>
                        Semua hasil penelitian, dokumen, dan jawaban AI
                        yang telah Anda simpan.
                    </p>
                </header>


                
                <section class="saved-toolbar">

                    <div
                        class="saved-tabs"
                        role="tablist"
                    >
                        <button
                            type="button"
                            class="is-active"
                            data-saved-filter="all"
                        >
                            <span>Semua</span>
                            <b data-count-all>
                                <?php echo e($totalCount); ?>

                            </b>
                        </button>

                        <button
                            type="button"
                            data-saved-filter="document"
                        >
                            <svg viewBox="0 0 24 24" fill="none">
                                <path d="M6 3h9l4 4v14H6z"/>
                                <path d="M15 3v5h5"/>
                            </svg>

                            <span>Document</span>

                            <b data-count-document>
                                <?php echo e($documentCount); ?>

                            </b>
                        </button>

                        <button
                            type="button"
                            data-saved-filter="answer"
                        >
                            <svg viewBox="0 0 24 24" fill="none">
                                <path d="M5 6h14v10H9l-4 3z"/>
                            </svg>

                            <span>Jawaban AI</span>

                            <b data-count-answer>
                                <?php echo e($answerCount); ?>

                            </b>
                        </button>
                    </div>


                    <label class="saved-search">
                        <svg viewBox="0 0 24 24" fill="none">
                            <circle cx="11" cy="11" r="6"/>
                            <path d="m16 16 4 4"/>
                        </svg>

                        <input
                            type="search"
                            placeholder="Cari judul, topik, atau kata kunci..."
                            data-saved-search
                            autocomplete="off"
                        >
                    </label>

                </section>


                
                <section class="saved-summary">

                    <div class="saved-summary__count">
                        <strong>
                            <?php echo e($totalCount); ?>

                        </strong>

                        <span>
                            item<br>
                            tersimpan
                        </span>
                    </div>


                    <div class="saved-summary__topics">
                        <span>
                            Topik yang paling sering muncul
                        </span>

                        <div class="saved-topic-chips">

                            <?php $__empty_1 = true; $__currentLoopData = $topics->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <button
                                    type="button"
                                    data-topic-filter="<?php echo e(Str::lower($topic['name'])); ?>"
                                >
                                    <?php echo e($topic['name']); ?>


                                    <b>
                                        <?php echo e($topic['count']); ?>

                                    </b>
                                </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <small>
                                    Belum cukup data untuk membaca pola topik.
                                </small>
                            <?php endif; ?>

                            <?php if($topics->count() > 5): ?>
                                <button
                                    type="button"
                                    class="is-more"
                                    data-show-all-topics
                                >
                                    +<?php echo e($topics->count() - 5); ?> lainnya
                                </button>
                            <?php endif; ?>

                        </div>
                    </div>

                </section>


                
                <div
                    class="saved-empty-filter"
                    data-saved-empty
                    hidden
                >
                    <svg viewBox="0 0 24 24" fill="none">
                        <circle cx="11" cy="11" r="6"/>
                        <path d="m16 16 4 4"/>
                    </svg>

                    <strong>
                        Saved tidak ditemukan
                    </strong>

                    <span>
                        Coba ubah kata kunci atau filter.
                    </span>
                </div>


                
                <div class="saved-groups">

                    <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupKey => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <section
                            class="saved-group"
                            data-saved-group
                        >

                            <h2>
                                <?php echo e($items->first()->group_label); ?>

                            </h2>


                            <div class="saved-list">

                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $topicsText = Str::lower(
                                            implode(
                                                ' ',
                                                $item->topics ?? []
                                            )
                                        );

                                        $searchText = Str::lower(
                                            implode(
                                                ' ',
                                                [
                                                    $item->title,
                                                    $item->description,
                                                    $item->tool_name,
                                                    $topicsText,
                                                ]
                                            )
                                        );

                                        $toolLower = Str::lower(
                                            $item->tool_name
                                        );

                                        $visualType = match (true) {
                                            $item->item_type === 'document'
                                                => 'document',

                                            Str::contains(
                                                $toolLower,
                                                ['literature', 'sintesis']
                                            )
                                                => 'literature',

                                            Str::contains(
                                                $toolLower,
                                                ['comparative', 'perbandingan']
                                            )
                                                => 'comparison',

                                            Str::contains(
                                                $toolLower,
                                                ['theoretical', 'conceptual', 'teori']
                                            )
                                                => 'theory',

                                            default
                                                => 'research',
                                        };

                                        $buttonUrl =
                                            $item->item_type === 'document'
                                                ? $item->detail_url
                                                : $item->continue_url;

                                        $buttonLabel =
                                            $item->item_type === 'document'
                                                ? 'Buka'
                                                : 'Lanjutkan';
                                    ?>


                                    <article
                                        class="
                                            saved-card
                                            saved-card--<?php echo e($visualType); ?>

                                        "
                                        data-saved-item
                                        data-saved-id="<?php echo e($item->id); ?>"
                                        data-saved-type="<?php echo e($item->item_type); ?>"
                                        data-saved-search="<?php echo e($searchText); ?>"
                                        data-saved-topics="<?php echo e($topicsText); ?>"
                                    >

                                        
                                        <div
                                            class="saved-card__visual"
                                            data-saved-visual
                                        >
                                            <span data-saved-default-icon>

                                                <?php switch($visualType):

                                                    case ('document'): ?>
                                                        <svg viewBox="0 0 24 24" fill="none">
                                                            <path d="M6 3h9l4 4v14H6z"/>
                                                            <path d="M15 3v5h5"/>
                                                            <path d="M9 12h6"/>
                                                            <path d="M9 16h5"/>
                                                        </svg>
                                                        <?php break; ?>

                                                    <?php case ('literature'): ?>
                                                        <svg viewBox="0 0 24 24" fill="none">
                                                            <path d="M9 15 7 17a4 4 0 0 1-6-6l3-3a4 4 0 0 1 6 0"/>
                                                            <path d="m15 9 2-2a4 4 0 0 1 6 6l-3 3a4 4 0 0 1-6 0"/>
                                                            <path d="m8 16 8-8"/>
                                                        </svg>
                                                        <?php break; ?>

                                                    <?php case ('comparison'): ?>
                                                        <svg viewBox="0 0 24 24" fill="none">
                                                            <path d="M5 20V13"/>
                                                            <path d="M12 20V6"/>
                                                            <path d="M19 20V10"/>
                                                        </svg>
                                                        <?php break; ?>

                                                    <?php case ('theory'): ?>
                                                        <svg viewBox="0 0 24 24" fill="none">
                                                            <circle cx="6" cy="12" r="2"/>
                                                            <circle cx="18" cy="6" r="2"/>
                                                            <circle cx="18" cy="18" r="2"/>
                                                            <path d="m8 11 8-4"/>
                                                            <path d="m8 13 8 4"/>
                                                        </svg>
                                                        <?php break; ?>

                                                    <?php default: ?>
                                                        <svg viewBox="0 0 24 24" fill="none">
                                                            <circle cx="10" cy="10" r="5"/>
                                                            <path d="m14 14 5 5"/>
                                                            <path d="M7 10h6"/>
                                                        </svg>

                                                <?php endswitch; ?>

                                            </span>

                                            <img
                                                src=""
                                                alt=""
                                                data-saved-custom-image
                                                hidden
                                            >
                                        </div>


                                        
                                        <div class="saved-card__content">

                                            <span
                                                class="saved-card__type"
                                                data-saved-type-label
                                            >
                                                <?php echo e($item->item_type === 'document'
                                                    ? 'DOCUMENT'
                                                    : Str::upper($item->tool_name)); ?>

                                            </span>


                                            <a
                                                href="<?php echo e($buttonUrl); ?>"
                                                class="saved-card__title"
                                                data-saved-title
                                            >
                                                <?php echo e($item->title); ?>

                                            </a>


                                            <p class="saved-card__description">
                                                <?php echo e($item->description); ?>

                                            </p>


                                            <div class="saved-card__bottom">

                                                <div class="saved-card__tags">
                                                    <?php $__currentLoopData = array_slice(
                                                            $item->topics ?? [],
                                                            0,
                                                            3
                                                        ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <span>
                                                            <?php echo e($topic); ?>

                                                        </span>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>


                                                <?php if(
                                                    $item->source_count
                                                    || $item->evidence_count
                                                ): ?>
                                                    <div class="saved-card__evidence">
                                                        <?php if($item->source_count): ?>
                                                            <span>
                                                                <?php echo e($item->source_count); ?>

                                                                source
                                                            </span>
                                                        <?php endif; ?>

                                                        <?php if($item->evidence_count): ?>
                                                            <span>
                                                                <?php echo e($item->evidence_count); ?>

                                                                evidence
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>

                                            </div>

                                        </div>


                                        
                                        <div class="saved-card__date">
                                            <strong>
                                                <?php echo e($item->time_label); ?>

                                            </strong>

                                            <span>
                                                <?php echo e($item->date_label); ?>

                                            </span>
                                        </div>


                                        
                                        <a
                                            href="<?php echo e($buttonUrl); ?>"
                                            class="saved-card__action"
                                        >
                                            <?php if($item->item_type === 'document'): ?>
                                                <svg viewBox="0 0 24 24" fill="none">
                                                    <path d="M6 3h9l4 4v14H6z"/>
                                                    <path d="M15 3v5h5"/>
                                                </svg>
                                            <?php else: ?>
                                                <svg viewBox="0 0 24 24" fill="none">
                                                    <path d="M8 5v14l11-7z"/>
                                                </svg>
                                            <?php endif; ?>

                                            <span>
                                                <?php echo e($buttonLabel); ?>

                                            </span>
                                        </a>


                                        
                                        <div class="saved-card-menu-wrap">

                                            <button
                                                type="button"
                                                class="saved-card-menu-trigger"
                                                data-saved-menu-trigger
                                                aria-label="Opsi Saved"
                                            >
                                                <span></span>
                                                <span></span>
                                                <span></span>
                                            </button>


                                            <div
                                                class="saved-card-menu"
                                                data-saved-menu
                                                hidden
                                            >

                                                <?php if(
                                                    $item->item_type === 'document'
                                                    && $item->continue_url
                                                ): ?>
                                                    <a
                                                        href="<?php echo e($item->continue_url); ?>"
                                                        class="saved-card-menu__item"
                                                    >
                                                        <svg viewBox="0 0 24 24" fill="none">
                                                            <path d="M5 6h14v10H9l-4 3z"/>
                                                        </svg>

                                                        <span>
                                                            <strong>
                                                                Buka percakapan
                                                            </strong>

                                                            <small>
                                                                Kembali ke research asal
                                                            </small>
                                                        </span>
                                                    </a>
                                                <?php endif; ?>


                                                <button
                                                    type="button"
                                                    data-saved-rename
                                                >
                                                    <svg viewBox="0 0 24 24" fill="none">
                                                        <path d="M4 20h4L19 9l-4-4L4 16z"/>
                                                        <path d="m13 7 4 4"/>
                                                    </svg>

                                                    <span>
                                                        <strong>Ganti nama</strong>
                                                        <small>Ubah judul Saved</small>
                                                    </span>
                                                </button>


                                                <button
                                                    type="button"
                                                    data-saved-appearance
                                                >
                                                    <svg viewBox="0 0 24 24" fill="none">
                                                        <rect x="4" y="4" width="16" height="16" rx="3"/>
                                                        <circle cx="9" cy="9" r="2"/>
                                                        <path d="m6 17 4-4 3 3 2-2 3 3"/>
                                                    </svg>

                                                    <span>
                                                        <strong>Ubah tampilan</strong>
                                                        <small>Icon, gambar, gaya, aksen</small>
                                                    </span>
                                                </button>


                                                <div class="saved-card-menu__divider"></div>


                                                <button
                                                    type="button"
                                                    class="is-danger"
                                                    data-saved-delete
                                                >
                                                    <svg viewBox="0 0 24 24" fill="none">
                                                        <path d="M4 7h16"/>
                                                        <path d="M9 7V4h6v3"/>
                                                        <path d="m7 7 1 13h8l1-13"/>
                                                    </svg>

                                                    <span>
                                                        <strong>Hapus</strong>
                                                        <small>Hapus dari Saved</small>
                                                    </span>
                                                </button>

                                            </div>
                                        </div>

                                    </article>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </section>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <section class="saved-zero">
                            <span>
                                <svg viewBox="0 0 24 24" fill="none">
                                    <path d="M6 4h12v17l-6-4-6 4z"/>
                                </svg>
                            </span>

                            <h2>
                                Belum ada Saved Research
                            </h2>

                            <p>
                                Simpan hasil research yang ingin Anda
                                gunakan kembali.
                            </p>

                            <a href="<?php echo e(route('workspace')); ?>">
                                Mulai Research
                            </a>
                        </section>

                    <?php endif; ?>

                </div>

            </div>


            
            <aside class="saved-page__rail">
                <section class="saved-rail-card saved-insights" aria-label="Distribusi hasil tersimpan berdasarkan Research Tool">
                    <header>
                        <span class="saved-rail-card__head-icon is-bars" aria-hidden="true">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 20V12m5 8V6m5 14v-9m5 9V4"/></svg>
                        </span>
                        <div><strong>Research yang tersimpan</strong><small>Distribusi menurut Research Tool</small></div>
                    </header>
                    <div class="saved-insights__summary"><strong><?php echo e($totalCount); ?></strong><span>Total Saved · <?php echo e($savedToolCounts->count()); ?> Research Tool</span></div>
                    <?php if($savedToolCounts->isNotEmpty()): ?>
                        <div class="saved-insights__bars" role="img" aria-label="Diagram jumlah Saved per Research Tool">
                            <?php $__currentLoopData = $savedToolCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $toolLabel => $toolCount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="saved-insights__bar" title="<?php echo e($toolLabel); ?>: <?php echo e($toolCount); ?> tersimpan">
                                    <span class="saved-insights__column" style="--bar-height:<?php echo e(round($toolCount / $savedChartMax * 100)); ?>%"><i></i></span>
                                    <span class="saved-insights__value"><?php echo e($toolCount); ?></span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="saved-insights__legend">
                            <?php $__currentLoopData = $savedToolCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $toolLabel => $toolCount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div><span><?php echo e($toolLabel); ?></span><strong><?php echo e($toolCount); ?></strong></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <p class="saved-rail-empty">Grafik muncul setelah hasil research pertama disimpan.</p>
                    <?php endif; ?>
                </section>


                <section class="saved-rail-card">

                    <header>
                        <span class="saved-rail-card__head-icon is-bars">
                            <svg viewBox="0 0 24 24" fill="none">
                                <path d="M5 20V13"/>
                                <path d="M12 20V7"/>
                                <path d="M19 20V4"/>
                            </svg>
                        </span>

                        <strong>
                            Topik tersimpan terbanyak
                        </strong>
                    </header>


                    <div class="saved-topic-ranking">

                        <?php $__empty_1 = true; $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <button
                                type="button"
                                data-topic-filter="<?php echo e(Str::lower($topic['name'])); ?>"
                                <?php if($index >= 5): ?>
                                    data-extra-topic
                                    hidden
                                <?php endif; ?>
                            >
                                <span>
                                    <?php echo e($topic['name']); ?>

                                </span>

                                <b>
                                    <?php echo e($topic['count']); ?>

                                </b>
                            </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="saved-rail-empty">
                                Topik akan muncul setelah lebih banyak
                                research disimpan.
                            </p>
                        <?php endif; ?>

                    </div>


                    <?php if($topics->count() > 5): ?>
                        <button
                            type="button"
                            class="saved-rail-more"
                            data-show-all-topics
                        >
                            <span>Lihat semua topik</span>

                            <svg viewBox="0 0 20 20" fill="none">
                                <path d="M4 10h12"/>
                                <path d="m12 6 4 4-4 4"/>
                            </svg>
                        </button>
                    <?php endif; ?>

                </section>


                <section class="saved-rail-card">

                    <header>
                        <span class="saved-rail-card__head-icon">
                            <svg viewBox="0 0 24 24" fill="none">
                                <circle cx="12" cy="12" r="8"/>
                                <path d="M12 7v5l3 2"/>
                            </svg>
                        </span>

                        <strong>
                            Aktivitas simpan terbaru
                        </strong>
                    </header>


                    <div class="saved-recent-activity">

                        <?php $__empty_1 = true; $__currentLoopData = $recentActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a href="<?php echo e($recent->detail_url); ?>">

                                <span class="saved-recent-activity__visual">
                                    <svg viewBox="0 0 24 24" fill="none">
                                        <path d="M6 3h12v18H6z"/>
                                        <path d="M9 8h6"/>
                                        <path d="M9 12h6"/>
                                    </svg>
                                </span>


                                <span class="saved-recent-activity__copy">
                                    <strong>
                                        <?php echo e(Str::limit(
                                            $recent->title,
                                            42
                                        )); ?>

                                    </strong>

                                    <small>
                                        <?php echo e($recent->date_label); ?>,
                                        <?php echo e($recent->time_label); ?>

                                    </small>
                                </span>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="saved-rail-empty">
                                Belum ada aktivitas.
                            </p>
                        <?php endif; ?>

                    </div>

                </section>

            </aside>

        </main>

    </div>


    
    <div
        class="saved-modal"
        data-saved-rename-modal
        hidden
    >
        <button
            type="button"
            class="saved-modal__backdrop"
            data-saved-modal-close
        ></button>

        <section class="saved-modal-card saved-modal-card--small">

            <header>
                <div>
                    <span>SAVED RESEARCH</span>
                    <h2>Ganti nama</h2>
                </div>

                <button
                    type="button"
                    data-saved-modal-close
                >
                    ×
                </button>
            </header>


            <label class="saved-modal-field">
                <span>Nama Saved</span>

                <input
                    type="text"
                    maxlength="220"
                    data-saved-rename-input
                >
            </label>


            <footer>
                <button
                    type="button"
                    class="is-secondary"
                    data-saved-modal-close
                >
                    Batal
                </button>

                <button
                    type="button"
                    class="is-primary"
                    data-saved-rename-save
                >
                    Simpan
                </button>
            </footer>

        </section>
    </div>


    
    <div
        class="saved-modal"
        data-saved-appearance-modal
        hidden
    >
        <button
            type="button"
            class="saved-modal__backdrop"
            data-saved-modal-close
        ></button>

        <section class="saved-modal-card saved-appearance-modal">

            <header>
                <div>
                    <span>PERSONAL VIEW</span>

                    <h2>
                        Ubah tampilan
                    </h2>

                    <p>
                        Perubahan hanya terlihat di browser ini.
                    </p>
                </div>

                <button
                    type="button"
                    data-saved-modal-close
                >
                    ×
                </button>
            </header>


            <div class="saved-appearance-section">
                <strong>
                    Icon
                </strong>

                <div class="saved-appearance-icons">

                    <button
                        type="button"
                        data-appearance-icon="auto"
                    >
                        <svg viewBox="0 0 24 24" fill="none">
                            <path d="M5 4h14v16H5z"/>
                            <path d="M9 8h6"/>
                            <path d="M9 12h6"/>
                        </svg>
                    </button>

                    <button
                        type="button"
                        data-appearance-icon="search"
                    >
                        <svg viewBox="0 0 24 24" fill="none">
                            <circle cx="10" cy="10" r="6"/>
                            <path d="m15 15 5 5"/>
                        </svg>
                    </button>

                    <button
                        type="button"
                        data-appearance-icon="theory"
                    >
                        <svg viewBox="0 0 24 24" fill="none">
                            <circle cx="6" cy="12" r="2"/>
                            <circle cx="18" cy="6" r="2"/>
                            <circle cx="18" cy="18" r="2"/>
                            <path d="m8 11 8-4"/>
                            <path d="m8 13 8 4"/>
                        </svg>
                    </button>

                    <button
                        type="button"
                        data-appearance-icon="chart"
                    >
                        <svg viewBox="0 0 24 24" fill="none">
                            <path d="M5 20V12"/>
                            <path d="M12 20V5"/>
                            <path d="M19 20V9"/>
                        </svg>
                    </button>

                    <button
                        type="button"
                        data-appearance-icon="link"
                    >
                        <svg viewBox="0 0 24 24" fill="none">
                            <path d="M10 13a5 5 0 0 0 7.5.5l2-2a5 5 0 0 0-7-7l-1 1"/>
                            <path d="M14 11a5 5 0 0 0-7.5-.5l-2 2a5 5 0 0 0 7 7l1-1"/>
                        </svg>
                    </button>

                </div>
            </div>


            <div class="saved-appearance-section">
                <strong>
                    Gambar sendiri
                </strong>

                <label class="saved-upload">
                    <input
                        type="file"
                        accept="image/png,image/jpeg,image/webp"
                        data-appearance-upload
                    >

                    <span>
                        <svg viewBox="0 0 24 24" fill="none">
                            <path d="M12 16V4"/>
                            <path d="m7 9 5-5 5 5"/>
                            <path d="M5 20h14"/>
                        </svg>
                    </span>

                    <div>
                        <strong>
                            Upload dari device
                        </strong>

                        <small>
                            JPG, PNG, WEBP · maksimum 2 MB
                        </small>
                    </div>
                </label>
            </div>


            <div class="saved-appearance-section">
                <strong>
                    Gaya card
                </strong>

                <div class="saved-style-options">

                    <button
                        type="button"
                        data-appearance-style="academic"
                    >
                        <b>Academic</b>
                        <span>Bersih & formal</span>
                    </button>

                    <button
                        type="button"
                        data-appearance-style="research"
                    >
                        <b>Research</b>
                        <span>Fokus evidence</span>
                    </button>

                    <button
                        type="button"
                        data-appearance-style="insight"
                    >
                        <b>Insight</b>
                        <span>Editorial</span>
                    </button>

                    <button
                        type="button"
                        data-appearance-style="minimal"
                    >
                        <b>Minimal</b>
                        <span>Lebih ringkas</span>
                    </button>

                </div>
            </div>


            <div class="saved-appearance-section">
                <strong>
                    Warna aksen
                </strong>

                <div class="saved-accent-options">
                    <button
                        type="button"
                        data-appearance-accent="coral"
                        aria-label="Coral"
                    ></button>

                    <button
                        type="button"
                        data-appearance-accent="teal"
                        aria-label="Teal"
                    ></button>

                    <button
                        type="button"
                        data-appearance-accent="navy"
                        aria-label="Navy"
                    ></button>

                    <button
                        type="button"
                        data-appearance-accent="gold"
                        aria-label="Gold"
                    ></button>
                </div>
            </div>


            <footer>
                <button
                    type="button"
                    class="is-reset"
                    data-appearance-reset
                >
                    Reset
                </button>

                <button
                    type="button"
                    class="is-primary"
                    data-saved-modal-close
                >
                    Selesai
                </button>
            </footer>

        </section>
    </div>


    
    <div
        class="saved-modal"
        data-saved-delete-modal
        hidden
    >
        <button
            type="button"
            class="saved-modal__backdrop"
            data-saved-modal-close
        ></button>

        <section class="saved-modal-card saved-modal-card--small">

            <header>
                <div>
                    <span>HAPUS DARI SAVED</span>
                    <h2>Hapus item ini?</h2>
                </div>
            </header>

            <p class="saved-delete-copy">
                Item akan hilang dari Saved, tetapi research asli
                tetap tersedia di History.
            </p>

            <footer>
                <button
                    type="button"
                    class="is-secondary"
                    data-saved-modal-close
                >
                    Batal
                </button>

                <button
                    type="button"
                    class="is-danger"
                    data-saved-delete-confirm
                >
                    Hapus
                </button>
            </footer>

        </section>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/saved/index.blade.php ENDPATH**/ ?>
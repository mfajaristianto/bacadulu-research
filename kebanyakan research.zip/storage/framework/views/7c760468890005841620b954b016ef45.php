<?php $__env->startSection('title', 'Dokumen Saya — BacaDulu Research'); ?>

<?php $__env->startSection('content'); ?>
<?php
    use Illuminate\Support\Str;
?>

<div class="br-document-layout br-doc-library" data-document-library>
    <?php if (isset($component)) { $__componentOriginal20d10595a218a074cc18d48f8c3127ed = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal20d10595a218a074cc18d48f8c3127ed = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.research-sidebar','data' => ['conversation' => null,'recentConversations' => $recentConversations]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('research-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['conversation' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(null),'recent-conversations' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($recentConversations)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal20d10595a218a074cc18d48f8c3127ed)): ?>
<?php $attributes = $__attributesOriginal20d10595a218a074cc18d48f8c3127ed; ?>
<?php unset($__attributesOriginal20d10595a218a074cc18d48f8c3127ed); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal20d10595a218a074cc18d48f8c3127ed)): ?>
<?php $component = $__componentOriginal20d10595a218a074cc18d48f8c3127ed; ?>
<?php unset($__componentOriginal20d10595a218a074cc18d48f8c3127ed); ?>
<?php endif; ?>

    <button
        type="button"
        class="research-sidebar-backdrop"
        data-chat-sidebar-backdrop
        aria-label="Tutup navigasi Research"
    ></button>

    <main class="br-document-main">
        <button
            type="button"
            class="br-doc-mobile-nav"
            data-chat-sidebar-open
            aria-expanded="false"
            aria-label="Buka navigasi Research"
        >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">
                <path d="M4 6h16M4 12h16M4 18h16"/>
            </svg>
            Menu Research
        </button>

        <section class="br-doc-library__page">
            <header class="br-doc-library__head">
                <div>
                    <span class="br-doc-library__eyebrow">DOCUMENT LIBRARY</span>
                    <h1>Dokumen Saya</h1>
                    <p>
                        Semua dokumen yang dibuat dari research tersimpan di sini.
                        File tidak hanya terunduh ke perangkat Anda.
                    </p>
                </div>

                <a href="<?php echo e(route('workspace')); ?>" class="br-doc-library__new">
                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M12 5v14M5 12h14"/>
                    </svg>
                    New Research
                </a>
            </header>

            <?php if(session('success')): ?>
                <div class="br-doc-library__feedback" role="status"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <nav class="br-doc-library__formats" aria-label="Pilih tampilan format dokumen">
                <a href="<?php echo e(route('documents.index', ['format' => 'pdf'])); ?>" class="<?php echo e($activeFormat === 'pdf' ? 'is-active' : ''); ?>" <?php if($activeFormat === 'pdf'): ?> aria-current="page" <?php endif; ?>>
                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M6 2h9l4 4v16H6zM15 2v5h4M9 12h6M9 16h5"/></svg> PDF
                </a>
                <a href="<?php echo e(route('documents.index', ['format' => 'docx'])); ?>" class="<?php echo e($activeFormat === 'docx' ? 'is-active' : ''); ?>" <?php if($activeFormat === 'docx'): ?> aria-current="page" <?php endif; ?>>
                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 3h11l3 3v15H5zM9 11h6M9 15h6M9 19h4"/></svg> DOCX
                </a>
                <a href="<?php echo e(route('documents.index', ['format' => 'all'])); ?>" class="<?php echo e($activeFormat === 'all' ? 'is-active' : ''); ?>" <?php if($activeFormat === 'all'): ?> aria-current="page" <?php endif; ?>>
                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="4" y="5" width="7" height="7" rx="1"/><rect x="13" y="5" width="7" height="7" rx="1"/><rect x="4" y="14" width="7" height="7" rx="1"/><rect x="13" y="14" width="7" height="7" rx="1"/></svg> Semua
                </a>
                <p>Memilih format menampilkan dokumen yang tersedia. Klik <b>Buka</b> untuk melihatnya tanpa download.</p>
            </nav>

            <div class="br-doc-library__summary" aria-label="Ringkasan dokumen">
                <article>
                    <span>Total dokumen</span>
                    <strong><?php echo e($totalDocuments); ?></strong>
                </article>
                <article>
                    <span>Ditampilkan</span>
                    <strong><?php echo e($documents->count()); ?></strong>
                </article>
                <article>
                    <span>Status</span>
                    <strong><?php echo e($documents->getCollection()->where('status', 'completed')->count()); ?> siap</strong>
                </article>
            </div>

            <?php if($documents->isEmpty()): ?>
                <section class="br-doc-library__empty">
                    <span class="br-doc-library__empty-icon">
                        <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                            <path d="M6 3h8l4 4v14H6V3Z"/>
                            <path d="M14 3v5h5M9 12h6M9 16h4"/>
                        </svg>
                    </span>
                    <h2><?php echo e($totalDocuments ? 'Tidak ada dokumen untuk format ini' : 'Belum ada dokumen'); ?></h2>
                    <p>
                        Setelah sebuah research selesai, pilih <b>Generate Document</b>.
                        Hasilnya akan otomatis muncul di halaman ini.
                    </p>
                    <a href="<?php echo e(route('workspace')); ?>">Mulai research →</a>
                </section>
            <?php else: ?>
                <div class="br-doc-library__grid">
                    <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $isReady = $document->status === 'completed';
                            $toolName = $document->aiRun?->aiTool?->name ?: 'Research';
                            $conversationTitle = $document->conversation?->title;
                            $storedFormat = data_get($document->settings_snapshot_json, 'output_format');
                            $preferredFormat = in_array($storedFormat, ['pdf', 'docx'], true)
                                ? $storedFormat
                                : ($activeFormat === 'docx' ? 'docx' : 'pdf');
                        ?>

                        <article class="br-doc-library-card">
                            <div class="br-doc-library-card__top">
                                <span class="br-doc-library-card__icon">
                                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                                        <path d="M6 3h8l4 4v14H6V3Z"/>
                                        <path d="M14 3v5h5M9 12h6M9 16h6"/>
                                    </svg>
                                </span>

                                <span class="br-doc-library-card__status is-<?php echo e($document->status); ?>">
                                    <?php echo e($isReady ? 'Siap' : Str::headline($document->status)); ?>

                                </span>
                            </div>

                            <div class="br-doc-library-card__body">
                                <span class="br-doc-library-card__type">
                                    <?php echo e($document->document_type); ?> · <?php echo e($document->citation_style); ?>

                                </span>

                                <h2><?php echo e($document->title); ?></h2>

                                <p>
                                    <?php echo e($conversationTitle ?: $toolName); ?>

                                </p>

                                <div class="br-doc-library-card__meta">
                                    <span><?php echo e($toolName); ?></span>
                                    <span><?php echo e($document->updated_at?->diffForHumans()); ?></span>
                                </div>
                            </div>

                            <div class="br-doc-library-card__actions">
                                <a href="<?php echo e(route('documents.show', ['documentGeneration' => $document, 'format' => $preferredFormat])); ?>" class="is-primary">
                                    <span><?php echo e($preferredFormat === 'pdf' ? 'Buka PDF' : 'Buka & Edit DOCX'); ?></span>
                                    <span aria-hidden="true">↗</span>
                                </a>
                                <form method="POST" action="<?php echo e(route('documents.destroy', $document)); ?>" data-document-delete-form>
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <input type="hidden" name="format" value="<?php echo e($activeFormat); ?>">
                                    <button type="submit" class="br-doc-library-card__delete" aria-label="Hapus <?php echo e($document->title); ?>" title="Hapus dokumen">
                                        <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13M10 11v6M14 11v6"/></svg>
                                    </button>
                                </form>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php if($documents->hasPages()): ?>
                    <div class="br-doc-library__pagination">
                        <?php echo e($documents->links()); ?>

                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </section>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/documents/index.blade.php ENDPATH**/ ?>
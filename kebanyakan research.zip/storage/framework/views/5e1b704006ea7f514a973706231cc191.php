<?php $__env->startSection(
    'title',
    $document->title.' — Research Document'
); ?>

<?php $__env->startSection('content'); ?>

<?php
    $content = is_array($document->content_json)
        ? $document->content_json
        : [];

    $sections = collect(
        data_get(
            $content,
            'sections',
            []
        )
    )
        ->filter(
            fn ($section) => is_array($section)
        )
        ->values();

    $references = collect(
        data_get(
            $content,
            'references',
            []
        )
    )
        ->map(
            fn ($reference) => trim((string) $reference)
        )
        ->filter()
        ->values();

    $documentTitle = (string) data_get(
        $content,
        'title',
        $document->title
    );

    $isReady =
        $document->status === 'completed';

    $storedFormat = in_array(
        $activeFormat ?? null,
        [
            'pdf',
            'docx',
        ],
        true
    )
        ? $activeFormat
        : null;
?>


<div
    class="
        br-document-layout
        br-document-view
        <?php echo e($editing ? 'is-editing-draft' : 'is-final-document'); ?>

    "
>

    <?php if (isset($component)) { $__componentOriginal20d10595a218a074cc18d48f8c3127ed = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal20d10595a218a074cc18d48f8c3127ed = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.research-sidebar','data' => ['conversation' => $document->conversation,'recentConversations' => $recentConversations]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('research-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['conversation' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($document->conversation),'recent-conversations' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($recentConversations)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal20d10595a218a074cc18d48f8c3127ed)): ?>
<?php $attributes = $__attributesOriginal20d10595a218a074cc18d48f8c3127ed; ?>
<?php unset($__attributesOriginal20d10595a218a074cc18d48f8c3127ed); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal20d10595a218a074cc18d48f8c3127ed)): ?>
<?php $component = $__componentOriginal20d10595a218a074cc18d48f8c3127ed; ?>
<?php unset($__componentOriginal20d10595a218a074cc18d48f8c3127ed); ?>
<?php endif; ?>


    <button
        type="button"
        class="research-sidebar-backdrop"
        data-chat-sidebar-backdrop
        aria-label="Tutup navigasi Research"
    ></button>


    <main class="br-document-main">

        <button
            type="button"
            class="br-doc-mobile-nav"
            data-chat-sidebar-open
            aria-expanded="false"
            aria-label="Buka navigasi Research"
        >
            <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="1.8"
                aria-hidden="true"
            >
                <path d="M4 6h16M4 12h16M4 18h16"/>
            </svg>

            Menu Research
        </button>


        <?php if($editing): ?>

            <section
                class="br-draft-workspace"
                data-document-editor
                data-document-id="<?php echo e($document->id); ?>"
                data-update-url="<?php echo e(route('documents.update', $document)); ?>"
                data-render-url="<?php echo e(route('documents.render', $document)); ?>"
            >

                

                <header class="br-draft-workspace__head">

                    <div>

                        <span class="br-doc-eyebrow">
                            EDIT DRAFT · FINAL REVIEW
                        </span>


                        <h1>
                            Periksa dokumen sebelum dicetak
                        </h1>


                        <p>
                            Edit isi di panel kanan.
                            Preview di tengah berubah langsung
                            dan mengikuti bagian yang sedang Anda pilih.
                            Simpan draft sebelum mencetak hasil akhir.
                        </p>

                    </div>


                    <div class="br-draft-workspace__head-actions">

                        <span
                            class="br-draft-save-state"
                            data-draft-save-state
                        >
                            Draft tersimpan
                        </span>


                        <a
                            href="<?php echo e(route('documents.index', ['format' => 'draft'])); ?>"
                            class="btn btn-secondary"
                        >
                            Dokumen Saya
                        </a>

                    </div>

                </header>


                <?php if(session('success')): ?>

                    <div
                        class="alert alert-success"
                        role="status"
                    >
                        <?php echo e(session('success')); ?>

                    </div>

                <?php endif; ?>


                <?php if($errors->any()): ?>

                    <div
                        class="alert alert-error"
                        role="alert"
                    >
                        <?php echo e($errors->first()); ?>

                    </div>

                <?php endif; ?>


                

                <div
                    class="br-draft-mobile-mode"
                    role="tablist"
                    aria-label="Tampilan editor dokumen"
                >

                    <button
                        type="button"
                        role="tab"
                        data-doc-mobile-mode="edit"
                        aria-selected="true"
                    >
                        Edit
                    </button>


                    <button
                        type="button"
                        role="tab"
                        data-doc-mobile-mode="preview"
                        aria-selected="false"
                    >
                        Preview
                    </button>

                </div>


                <div
                    class="br-draft-workspace__grid"
                    data-doc-workspace-grid
                    data-mobile-view="edit"
                >

                    

                    <section
                        class="br-draft-preview"
                        aria-label="Live document preview"
                    >

                        <div class="br-draft-preview__topbar">

                            <div>

                                <span class="br-doc-eyebrow">
                                    LIVE PREVIEW
                                </span>


                                <strong>
                                    Hasil sementara dokumen
                                </strong>

                            </div>


                            <div class="br-draft-preview__meta">

                                <span>
                                    <?php echo e($document->document_type); ?>

                                </span>

                                <span>·</span>

                                <span>
                                    <?php echo e($document->citation_style); ?>

                                </span>

                            </div>

                        </div>


                        <div
                            class="br-draft-preview__canvas"
                            data-preview-scroller
                        >

                            <article
                                class="br-draft-paper"
                                data-draft-paper
                            >

                                <header
                                    class="br-draft-paper__head"
                                    data-preview-title-anchor
                                >

                                    <h2 data-preview-title>
                                        <?php echo e($documentTitle); ?>

                                    </h2>


                                    <p>
                                        <?php echo e($document->document_type); ?>

                                        ·
                                        <?php echo e($document->citation_style); ?>

                                    </p>

                                </header>


                                <div data-preview-sections>

                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <section
                                            class="br-draft-paper__section"
                                            data-preview-section="<?php echo e($index); ?>"
                                        >

                                            <h3 data-preview-heading>
                                                <?php echo e(preg_replace(
                                                        '/^\s*#{1,6}\s*/u',
                                                        '',
                                                        (string) data_get(
                                                            $section,
                                                            'heading',
                                                            'SECTION'
                                                        )
                                                    )); ?>

                                            </h3>


                                            <div
                                                class="br-draft-paper__body"
                                                data-preview-body
                                            >
                                                <?php echo \Illuminate\Support\Str::markdown(
                                                        (string) data_get(
                                                            $section,
                                                            'body',
                                                            ''
                                                        ),
                                                        [
                                                            'html_input' => 'strip',
                                                            'allow_unsafe_links' => false,
                                                        ]
                                                    ); ?>

                                            </div>

                                        </section>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>


                                <section
                                    class="
                                        br-draft-paper__section
                                        br-draft-paper__references
                                    "
                                    data-preview-references
                                >

                                    <h3>
                                        DAFTAR PUSTAKA
                                    </h3>


                                    <div data-preview-reference-list>

                                        <?php $__empty_1 = true; $__currentLoopData = $references; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                            <p>
                                                <?php echo e($reference); ?>

                                            </p>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                            <p class="is-empty-reference">
                                                Belum ada daftar pustaka.
                                            </p>

                                        <?php endif; ?>

                                    </div>

                                </section>

                            </article>

                        </div>

                    </section>


                    

                    <aside class="br-draft-editor">

                        <div class="br-draft-editor__head">

                            <span class="br-doc-eyebrow">
                                EDIT DRAFT
                            </span>


                            <h2>
                                Edit per bagian
                            </h2>


                            <p>
                                Pilih bagian di bawah.
                                Preview tengah otomatis menuju
                                bagian yang sama tanpa reload halaman.
                            </p>

                        </div>


                        

                        <section
                            class="br-draft-print"
                            data-draft-print
                        >

                            <div
                                class="br-draft-print__formats"
                                role="radiogroup"
                                aria-label="Format cetak"
                            >

                                <button
                                    type="button"
                                    data-print-format="pdf"
                                    role="radio"
                                    aria-checked="false"
                                    title="Cetak sebagai PDF"
                                >

                                    <span class="br-draft-print__check">
                                        ✓
                                    </span>


                                    <svg
                                        viewBox="0 0 24 24"
                                        fill="none"
                                        aria-hidden="true"
                                    >
                                        <path d="M6 3h8l4 4v14H6V3Z"/>
                                        <path d="M14 3v5h5"/>
                                    </svg>


                                    <strong>
                                        PDF
                                    </strong>


                                    <small>
                                        Tampilan tetap
                                    </small>

                                </button>


                                <button
                                    type="button"
                                    data-print-format="docx"
                                    role="radio"
                                    aria-checked="false"
                                    title="Cetak sebagai DOCX"
                                >

                                    <span class="br-draft-print__check">
                                        ✓
                                    </span>


                                    <svg
                                        viewBox="0 0 24 24"
                                        fill="none"
                                        aria-hidden="true"
                                    >
                                        <path d="M6 3h8l4 4v14H6V3Z"/>
                                        <path d="M14 3v5h5"/>
                                    </svg>


                                    <strong>
                                        DOCX
                                    </strong>


                                    <small>
                                        File Word editable
                                    </small>

                                </button>

                            </div>


                            <button
                                type="button"
                                class="
                                    btn
                                    btn-primary
                                    br-draft-print__button
                                "
                                data-open-print-confirm
                                disabled
                            >
                                Review & Cetak →
                            </button>

                        </section>


                        

                        <form
                            method="POST"
                            action="<?php echo e(route('documents.update', $document)); ?>"
                            data-draft-edit-form
                        >

                            <?php echo csrf_field(); ?>

                            <?php echo method_field('PATCH'); ?>


                            

                            <div class="br-draft-editor__nav-wrap">

                                <span class="br-draft-editor__nav-label">
                                    BAGIAN DOKUMEN
                                </span>


                                <nav
                                    class="br-draft-editor__nav"
                                    aria-label="Bagian dokumen"
                                >

                                    <button
                                        type="button"
                                        class="is-active"
                                        data-editor-tab="title"
                                        aria-selected="true"
                                    >

                                        <span>
                                            Judul
                                        </span>


                                        <small>
                                            Document title
                                        </small>

                                    </button>


                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <button
                                            type="button"
                                            data-editor-tab="section-<?php echo e($index); ?>"
                                            aria-selected="false"
                                        >

                                            <span>
                                                <?php echo e(preg_replace(
                                                        '/^\s*#{1,6}\s*/u',
                                                        '',
                                                        (string) data_get(
                                                            $section,
                                                            'heading',
                                                            'SECTION'
                                                        )
                                                    )); ?>

                                            </span>


                                            <small>
                                                <?php echo e(str_pad(
                                                        (string) ($index + 1),
                                                        2,
                                                        '0',
                                                        STR_PAD_LEFT
                                                    )); ?>

                                            </small>

                                        </button>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    <button
                                        type="button"
                                        data-editor-tab="references"
                                        aria-selected="false"
                                    >

                                        <span>
                                            Daftar Pustaka
                                        </span>


                                        <small>
                                            <?php echo e($references->count()); ?>

                                            ref.
                                        </small>

                                    </button>

                                </nav>

                            </div>


                            

                            <div class="br-draft-editor__panes">

                                

                                <section
                                    class="
                                        br-draft-editor__pane
                                        is-active
                                    "
                                    data-editor-pane="title"
                                >

                                    <label class="document-field">

                                        <span>
                                            Judul dokumen
                                        </span>


                                        <textarea
                                            name="title"
                                            rows="5"
                                            maxlength="255"
                                            required
                                            data-draft-title-input
                                        ><?php echo e(old('title', $documentTitle)); ?></textarea>

                                    </label>


                                    <p class="br-draft-editor__hint">
                                        Judul diperbarui langsung
                                        pada preview di tengah.
                                    </p>

                                </section>


                                

                                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <section
                                        class="br-draft-editor__pane"
                                        data-editor-pane="section-<?php echo e($index); ?>"
                                        hidden
                                    >

                                        <input
                                            type="hidden"
                                            name="sections[<?php echo e($index); ?>][heading]"
                                            value="<?php echo e(old(
                                                'sections.'.$index.'.heading',
                                                data_get(
                                                    $section,
                                                    'heading',
                                                    'SECTION'
                                                )
                                            )); ?>"
                                            data-section-heading-input="<?php echo e($index); ?>"
                                        >


                                        <div class="br-draft-editor__section-title">

                                            <span>
                                                Bagian
                                                <?php echo e(str_pad(
                                                        (string) ($index + 1),
                                                        2,
                                                        '0',
                                                        STR_PAD_LEFT
                                                    )); ?>

                                            </span>


                                            <h3>
                                                <?php echo e(preg_replace(
                                                        '/^\s*#{1,6}\s*/u',
                                                        '',
                                                        (string) data_get(
                                                            $section,
                                                            'heading',
                                                            'SECTION'
                                                        )
                                                    )); ?>

                                            </h3>

                                        </div>


                                        <label class="document-field">

                                            <span>
                                                Isi bagian
                                            </span>


                                            <textarea
                                                name="sections[<?php echo e($index); ?>][body]"
                                                rows="16"
                                                maxlength="50000"
                                                data-section-body-input="<?php echo e($index); ?>"
                                            ><?php echo e(old(
                                                'sections.'.$index.'.body',
                                                data_get(
                                                    $section,
                                                    'body',
                                                    ''
                                                )
                                            )); ?></textarea>

                                        </label>


                                        <p class="br-draft-editor__hint">
                                            Saat Anda mengetik,
                                            isi preview berubah secara real-time.
                                        </p>

                                    </section>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                

                                <section
                                    class="br-draft-editor__pane"
                                    data-editor-pane="references"
                                    hidden
                                >

                                    <label class="document-field">

                                        <span>
                                            Daftar Pustaka
                                        </span>


                                        <textarea
                                            name="references_text"
                                            rows="16"
                                            data-references-text
                                        ><?php echo e(old(
                                            'references_text',
                                            $references->implode("\n")
                                        )); ?></textarea>

                                    </label>


                                    <p class="br-draft-editor__hint">
                                        Tulis satu referensi per baris.
                                    </p>


                                    <div data-reference-hidden-inputs>

                                        <?php $__currentLoopData = $references; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $reference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <input
                                                type="hidden"
                                                name="references[<?php echo e($index); ?>]"
                                                value="<?php echo e($reference); ?>"
                                            >

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>

                                </section>

                            </div>


                            

                            <div class="br-draft-editor__actions">

                                <span data-draft-unsaved-label>
                                    Tidak ada perubahan
                                </span>


                                <button
                                    type="submit"
                                    class="btn btn-primary"
                                    data-draft-save-button
                                >
                                    Simpan Perubahan
                                </button>

                            </div>

                        </form>

                    </aside>

                </div>

            </section>


            

            <dialog
                class="
                    br-doc-dialog
                    br-print-confirm
                "
                data-print-confirm
                aria-labelledby="br-print-confirm-title"
            >

                <span class="br-doc-eyebrow">
                    FINAL PRINT CHECK
                </span>


                <h2 id="br-print-confirm-title">
                    Cetak dokumen sekarang?
                </h2>


                <p>
                    Pastikan seluruh pengaturan
                    dan isi sudah sesuai.
                </p>


                <dl>

                    <div>
                        <dt>Judul</dt>

                        <dd data-print-summary-title>
                            <?php echo e($documentTitle); ?>

                        </dd>
                    </div>


                    <div>
                        <dt>Jenis dokumen</dt>

                        <dd>
                            <?php echo e($document->document_type); ?>

                        </dd>
                    </div>


                    <div>
                        <dt>Citation Style</dt>

                        <dd>
                            <?php echo e($document->citation_style); ?>

                        </dd>
                    </div>


                    <div>
                        <dt>Bagian</dt>

                        <dd>
                            <?php echo e($sections->count()); ?>

                            bagian + Daftar Pustaka
                        </dd>
                    </div>


                    <div>
                        <dt>Format final</dt>

                        <dd data-print-summary-format>
                            —
                        </dd>
                    </div>

                </dl>


                <div class="br-doc-dialog__actions">

                    <button
                        type="button"
                        class="btn btn-secondary"
                        data-print-cancel
                    >
                        Belum, cek lagi
                    </button>


                    <button
                        type="button"
                        class="btn btn-primary"
                        data-print-confirm-button
                    >
                        Cetak sekarang →
                    </button>

                </div>

            </dialog>


            

            <div
                class="br-doc-generation"
                data-document-generation
                hidden
                aria-live="polite"
                aria-busy="true"
            >

                <div class="br-doc-generation__backdrop"></div>


                <section
                    class="br-doc-generation__panel"
                    role="dialog"
                    aria-modal="true"
                >

                    <span class="br-doc-eyebrow">
                        DOCUMENT ENGINE
                    </span>


                    <div
                        class="br-doc-generation__file-motion"
                        aria-hidden="true"
                    >
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>


                    <strong data-doc-progress-title>
                        Menyiapkan dokumen
                    </strong>


                    <p data-doc-progress-copy>
                        Menata isi final,
                        citation,
                        dan format file.
                    </p>


                    <div
                        class="br-doc-generation__track"
                        role="progressbar"
                        aria-valuemin="0"
                        aria-valuemax="100"
                        aria-valuenow="0"
                        data-doc-progress-bar
                    >
                        <span data-doc-progress-fill></span>
                    </div>


                    <div class="br-doc-generation__meta">

                        <span data-doc-progress-stage>
                            Menyiapkan struktur…
                        </span>


                        <b data-doc-progress-value>
                            0%
                        </b>

                    </div>


                    <div
                        class="br-doc-generation__success"
                        data-doc-success
                        hidden
                    >

                        <div
                            class="br-doc-generation__success-icon"
                            aria-hidden="true"
                        >
                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                            >
                                <path d="m6 12 4 4 8-9"/>
                            </svg>
                        </div>


                        <div class="br-doc-generation__success-copy">

                            <strong data-doc-success-title>
                                Dokumen berhasil dibuat
                            </strong>


                            <p>
                                Anda akan diarahkan dalam

                                <b data-doc-success-countdown>
                                    5
                                </b>

                                detik.

                                Jika tidak ingin menunggu,
                                pilih tindakan di bawah.
                            </p>

                        </div>


                        <div class="br-doc-generation__success-actions">

                            <button
                                type="button"
                                class="btn btn-primary"
                                data-doc-open-result
                            >
                                Buka dokumen sekarang
                            </button>


                            <button
                                type="button"
                                class="btn btn-secondary"
                                data-doc-stay-here
                            >
                                Tetap di halaman ini
                            </button>

                        </div>

                    </div>


                    <button
                        type="button"
                        class="br-doc-generation__retry"
                        data-doc-progress-retry
                        hidden
                    >
                        Coba lagi
                    </button>

                </section>

            </div>


        <?php else: ?>

            

            <section
                class="
                    document-page
                    br-final-document-page
                "
            >

                <header
                    class="
                        document-page-head
                        document-page-head--single
                    "
                >

                    <div>

                        <div class="document-page-kicker">

                            <span>
                                <?php echo e($storedFormat === 'pdf'
                                        ? 'PDF DOCUMENT'
                                        : 'DOCX DOCUMENT'); ?>

                            </span>


                            <span
                                class="
                                    document-status
                                    document-status--<?php echo e($document->status); ?>

                                "
                            >
                                <?php echo e(strtoupper($document->status)); ?>

                            </span>

                        </div>


                        <h1 class="display-type">
                            <?php echo e($document->title); ?>

                        </h1>


                        <p>
                            <?php echo e($document->document_type); ?>

                            ·
                            <?php echo e($document->citation_style); ?>


                            <?php if($document->generated_at): ?>
                                · Generated
                                <?php echo e($document->generated_at->format('d M Y · H:i')); ?>

                            <?php endif; ?>
                        </p>

                    </div>


                    <?php if($isReady && $storedFormat): ?>

                        <a
                            href="<?php echo e(route(
                                    'documents.download',
                                    [
                                        $document,
                                        $storedFormat,
                                    ]
                                )); ?>"
                            class="btn btn-primary"
                        >
                            Download
                            <?php echo e(strtoupper($storedFormat)); ?>

                            ↓
                        </a>

                    <?php endif; ?>

                </header>


                <div class="br-doc-view-toolbar">

                    <a
                        href="<?php echo e(route(
                                'documents.index',
                                [
                                    'format' => $storedFormat ?: 'all',
                                ]
                            )); ?>"
                    >
                        ← Dokumen Saya
                    </a>


                    <span>
                        Dokumen sudah tersimpan di Dokumen Saya
                    </span>

                </div>


                <?php if(session('success')): ?>

                    <div
                        class="alert alert-success"
                        role="status"
                    >
                        <?php echo e(session('success')); ?>

                    </div>

                <?php endif; ?>


                

                <?php if($storedFormat === 'pdf'): ?>

                    <section
                        class="br-doc-pdf-only"
                        aria-label="Pratinjau PDF"
                    >

                        <div class="br-doc-pdf-only__head">

                            <div>

                                <span class="br-doc-eyebrow">
                                    PDF PREVIEW
                                </span>


                                <h2>
                                    Lihat PDF
                                </h2>

                            </div>


                            <small>
                                PDF ditampilkan di browser,
                                tidak diunduh otomatis.
                            </small>

                        </div>


                        <?php if($isReady && filled($document->pdf_path)): ?>

                            <iframe
                                src="<?php echo e(route('documents.preview', $document)); ?>"
                                title="Pratinjau PDF <?php echo e($document->title); ?>"
                                loading="eager"
                            ></iframe>

                        <?php else: ?>

                            <div class="br-doc-view-empty">
                                PDF belum tersedia.
                            </div>

                        <?php endif; ?>

                    </section>


                

                <?php elseif($storedFormat === 'docx'): ?>

                    <section class="br-docx-final-preview">

                        <div class="br-doc-pdf-only__head">

                            <div>

                                <span class="br-doc-eyebrow">
                                    DOCX CONTENT
                                </span>


                                <h2>
                                    Isi dokumen
                                </h2>

                            </div>


                            <small>
                                Gunakan Download DOCX
                                untuk membuka file di Word.
                            </small>

                        </div>


                        <article class="br-draft-paper">

                            <header class="br-draft-paper__head">

                                <h2>
                                    <?php echo e($documentTitle); ?>

                                </h2>


                                <p>
                                    <?php echo e($document->document_type); ?>

                                    ·
                                    <?php echo e($document->citation_style); ?>

                                </p>

                            </header>


                            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <section class="br-draft-paper__section">

                                    <h3>
                                        <?php echo e(preg_replace(
                                                '/^\s*#{1,6}\s*/u',
                                                '',
                                                (string) data_get(
                                                    $section,
                                                    'heading',
                                                    'SECTION'
                                                )
                                            )); ?>

                                    </h3>


                                    <div class="br-draft-paper__body">
                                        <?php echo \Illuminate\Support\Str::markdown(
                                                (string) data_get(
                                                    $section,
                                                    'body',
                                                    ''
                                                ),
                                                [
                                                    'html_input' => 'strip',
                                                    'allow_unsafe_links' => false,
                                                ]
                                            ); ?>

                                    </div>

                                </section>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            <?php if($references->isNotEmpty()): ?>

                                <section
                                    class="
                                        br-draft-paper__section
                                        br-draft-paper__references
                                    "
                                >

                                    <h3>
                                        DAFTAR PUSTAKA
                                    </h3>


                                    <?php $__currentLoopData = $references; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <p>
                                            <?php echo e($reference); ?>

                                        </p>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </section>

                            <?php endif; ?>

                        </article>

                    </section>

                <?php endif; ?>

            </section>

        <?php endif; ?>

    </main>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/documents/show.blade.php ENDPATH**/ ?>
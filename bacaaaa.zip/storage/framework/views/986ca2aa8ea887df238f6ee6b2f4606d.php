
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'code',
    'mascot',
    'heading',
    'description',
    'primary' => 'home',
    'secondary' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'code',
    'mascot',
    'heading',
    'description',
    'primary' => 'home',
    'secondary' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    try {
        $signedIn = auth()->check();
    } catch (\Throwable $e) {
        $signedIn = false;
    }

    $isGet = request()->isMethod('GET');
    $homeHref = $signedIn ? route('workspace') : url('/');

    // Tautan aman: dipakai sebagai fallback "Kembali" dan "Coba lagi" untuk request non-GET.
    $actions = [
        'home' => ['label' => $signedIn ? 'Ke Workspace' : 'Ke Beranda', 'href' => $homeHref],
        'beranda' => ['label' => 'Ke Beranda', 'href' => url('/')],
        'login' => ['label' => 'Masuk lagi', 'href' => route('login')],
        'back' => ['label' => 'Kembali', 'href' => $homeHref, 'attr' => 'data-error-back'],
        'retry' => ['label' => 'Coba lagi', 'href' => $isGet ? request()->fullUrl() : $homeHref, 'attr' => 'data-error-retry'],
    ];

    $buttons = collect([$primary, $secondary])->filter()->map(fn ($key) => $actions[$key])->values();
?>
<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex">
    <meta name="theme-color" content="#fbf8f4">

    <title><?php echo e($code); ?> — BacaDulu Research</title>

    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="error-body">
    <main class="error-page" data-error-page data-method="<?php echo e($isGet ? 'get' : 'other'); ?>">

        <header class="error-page__top">
            <a href="<?php echo e(url('/')); ?>" class="error-page__brand">
                <span>BacaDulu</span>
                <strong>Research</strong>
            </a>
        </header>

        <section class="error-page__body">
            <img
                class="error-page__mascot"
                src="<?php echo e(asset('assets/mascot/mascot-'.$mascot.'.png')); ?>"
                alt=""
                width="260"
                height="260"
                decoding="async"
            >

            <p class="error-page__code">ERROR <?php echo e($code); ?></p>

            <h1><?php echo e($heading); ?></h1>

            <p class="error-page__text"><?php echo e($description); ?></p>

            <div class="error-page__actions">
                <?php $__currentLoopData = $buttons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $button): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a
                        href="<?php echo e($button['href']); ?>"
                        class="error-page__btn <?php echo e($index === 0 ? 'error-page__btn--primary' : 'error-page__btn--plain'); ?>"
                        <?php echo $button['attr'] ?? ''; ?>

                    >
                        <?php echo e($button['label']); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

    </main>
</body>

</html>
<?php /**PATH D:\Pkl\bacadulu-research\resources\views\components\error-page.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Collections'); ?>
<?php $__env->startSection('page_title', 'Collections'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-page">
    <header class="bd-admin-page-head">
        <div class="bd-admin-page-head__copy">
            <p class="bd-admin-kicker">KNOWLEDGE / COLLECTIONS</p>
            <h1>Collections</h1>
            <p>Bundel source lintas category untuk konteks research tertentu.</p>
        </div>
        <div class="bd-admin-page-head__actions"><a href="<?php echo e(route('admin.collections.create')); ?>" class="bd-admin-button bd-admin-button--primary">Tambah Collection ＋</a></div>
    </header>

    <form method="GET" class="bd-admin-filter">
        <input class="bd-admin-input" type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="Cari collection…">
        <select class="bd-admin-select" name="status" data-auto-submit><option value="">Semua status</option><option value="active" <?php if(request('status') === 'active'): echo 'selected'; endif; ?>>Active</option><option value="archived" <?php if(request('status') === 'archived'): echo 'selected'; endif; ?>>Archived</option></select>
        <span></span>
    </form>

    <div class="bd-admin-table-wrap">
        <table class="bd-admin-table">
            <thead><tr><th>Collection</th><th>Sources</th><th>Status</th><th>Updated</th><th></th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><div class="bd-admin-table__title"><strong><?php echo e($collection->name); ?></strong><small><?php echo e(Str::limit($collection->description ?: 'Tanpa deskripsi', 110)); ?></small></div></td>
                    <td><?php echo e($collection->documents_count); ?></td>
                    <td><span class="bd-admin-status bd-admin-status--<?php echo e($collection->status); ?>"><?php echo e(ucfirst($collection->status)); ?></span></td>
                    <td><?php echo e(optional($collection->updated_at)->format('d M Y')); ?></td>
                    <td><a class="bd-admin-table__action" href="<?php echo e(route('admin.collections.edit', $collection)); ?>">Edit →</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5"><div class="bd-admin-empty"><div class="bd-admin-empty__inner"><span class="bd-admin-empty__mark">COL</span><h3>Belum ada collection.</h3><p>Buat bundel source untuk tema research tertentu.</p></div></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php echo e($collections->links()); ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/collections/index.blade.php ENDPATH**/ ?>
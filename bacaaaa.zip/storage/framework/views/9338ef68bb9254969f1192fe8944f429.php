

<?php $__env->startSection(
    'title',
    'Hapus Conversation — BacaDulu Research'
); ?>

<?php $__env->startSection('content'); ?>

<section class="conversation-delete-page">

    <div
        class="conversation-delete-card"
        data-reveal
    >

        <p class="eyebrow">
            DELETE CONVERSATION
        </p>

        <h1 class="display-type">
            Hapus research ini?
        </h1>

        <p class="conversation-delete-lead">
            Conversation akan dihapus dari
            history Anda. Tindakan ini tidak
            dapat dibatalkan dari interface.
        </p>

        <div class="conversation-delete-summary">

            <span>
                RESEARCH
            </span>

            <strong>
                <?php echo e($conversation->title); ?>

            </strong>

            <dl>

                <div>
                    <dt>
                        Kategori
                    </dt>

                    <dd>
                        <?php echo e($conversation
                                ->category
                                ?->name
                            ?: 'Research'); ?>

                    </dd>
                </div>

                <div>
                    <dt>
                        Pesan
                    </dt>

                    <dd>
                        <?php echo e($conversation
                                ->messages_count); ?>

                    </dd>
                </div>

                <div>
                    <dt>
                        Terakhir diperbarui
                    </dt>

                    <dd>
                        <?php echo e($conversation
                                ->updated_at
                                ->format(
                                    'd M Y H:i'
                                )); ?>

                    </dd>
                </div>

            </dl>

        </div>

        <div
            class="
                conversation-delete-actions
            "
        >

            <a
                href="<?php echo e(route(
                    'workspace.conversation',
                    $conversation
                )); ?>"
                class="btn btn-secondary"
            >
                Batal
            </a>

            <form
                method="POST"
                action="<?php echo e(route(
                    'conversations.destroy',
                    $conversation
                )); ?>"
            >
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>

                <button
                    type="submit"
                    class="
                        btn
                        conversation-delete-button
                    "
                >
                    Ya, hapus conversation
                </button>
            </form>

        </div>

    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views\research\conversations\delete.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Verify Email — BacaDulu Research'); ?>
<?php $__env->startSection('content'); ?>
<section class="auth-page auth-page-compact">
    <div class="auth-card" data-reveal>
        <p class="eyebrow">VERIFY EMAIL</p>
        <h1>Check your inbox.</h1>
        <p class="auth-subtitle">Kami mengirim tautan verifikasi ke <strong><?php echo e(auth()->user()->email); ?></strong>. Verifikasi email diperlukan bila mode verifikasi diaktifkan administrator.</p>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('verification.send')); ?>" class="form-stack">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary btn-full">Send verification link again</button>
        </form>

        <form method="POST" action="<?php echo e(route('logout')); ?>" class="auth-secondary-form">
            <?php echo csrf_field(); ?>
            <button type="submit" class="text-button">Logout</button>
        </form>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views\auth\verify-email.blade.php ENDPATH**/ ?>
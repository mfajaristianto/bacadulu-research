<?php $__env->startSection('title', 'User Detail'); ?>
<?php $__env->startSection('page_title', 'Users'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-page">
    <header class="bd-admin-page-head">
        <div class="bd-admin-page-head__copy">
            <p class="bd-admin-kicker">ACCESS / USER</p>
            <h1><?php echo e($user->name); ?></h1>
            <p><?php echo e($user->email); ?> · User #<?php echo e($user->id); ?></p>
        </div>
        <div class="bd-admin-page-head__actions"><a href="<?php echo e(route('admin.users.index')); ?>" class="bd-admin-button bd-admin-button--ghost">← Users</a></div>
    </header>

    <div class="bd-admin-panels">
        <article class="bd-admin-panel"><small>PROFILE COMPLETION</small><strong><?php echo e($user->profileCompletion()); ?>%</strong><p><?php echo e(implode(', ', $user->missingProfileFields()) ?: 'Profile minimum lengkap.'); ?></p></article>
        <article class="bd-admin-panel"><small>AI RUNS</small><strong><?php echo e($user->ai_runs_count); ?></strong><p>Total execution yang tercatat.</p></article>
        <article class="bd-admin-panel"><small>CONVERSATIONS</small><strong><?php echo e($user->conversations_count); ?></strong><p>Research conversations.</p></article>
    </div>

    <section class="bd-admin-section">
        <div class="bd-admin-two-column">
            <div class="bd-admin-detail-list">
                <div><span>Email</span><strong><?php echo e($user->email); ?></strong></div>
                <div><span>Institusi</span><strong><?php echo e($user->institution ?: '—'); ?></strong></div>
                <div><span>Peran</span><strong><?php echo e($user->role ?? $user->occupation ?? '—'); ?></strong></div>
                <div><span>Domisili</span><strong><?php echo e($user->domicile_city ?? $user->address ?? '—'); ?></strong></div>
                <div><span>Email verified</span><strong><?php echo e($user->email_verified_at ? 'Yes' : 'No'); ?></strong></div>
                <div><span>Last login</span><strong><?php echo e(optional($user->last_login_at)->format('d M Y · H:i') ?: '—'); ?></strong></div>
                <div><span>Status</span><strong><span class="bd-admin-status bd-admin-status--<?php echo e($user->status); ?>"><?php echo e(ucfirst($user->status)); ?></span></strong></div>
            </div>

            <aside class="bd-admin-form__aside">
                <section><strong>Access Control</strong><p>Suspend memblokir user dari area Research tanpa menghapus data historis.</p></section>
                <section>
                    <form method="POST" action="<?php echo e(route('admin.users.status', $user)); ?>">
                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                        <input type="hidden" name="status" value="<?php echo e($user->status === 'active' ? 'suspended' : 'active'); ?>">
                        <button class="bd-admin-button <?php echo e($user->status === 'active' ? 'bd-admin-button--danger' : 'bd-admin-button--primary'); ?>" type="submit"><?php echo e($user->status === 'active' ? 'Suspend User' : 'Aktifkan User'); ?></button>
                    </form>
                </section>
            </aside>
        </div>
    </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views\admin\users\show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', $document->title.' — BacaDulu Research'); ?>
<?php $__env->startSection('content'); ?>
<section class="document-detail">
    <a class="back-link" href="<?php echo e(route('library.index')); ?>">← Back to Library</a>
    <div class="document-detail-grid">
        <article class="document-detail-main" data-reveal>
            <p class="document-category"><?php echo e($document->category?->name ?: 'Internal Source'); ?></p>
            <h1><?php echo e($document->title); ?></h1>
            <div class="document-meta-large"><span><?php echo e($document->document_type ?: 'Document'); ?></span><span><?php echo e($document->publication_year ?: 'Year unavailable'); ?></span><span><?php echo e(strtoupper($document->language ?: 'n/a')); ?></span></div>
            <div class="document-body"><h2>Abstract</h2><p><?php echo e($document->abstract ?: 'No abstract available.'); ?></p></div>
        </article>
        <aside class="document-facts" data-reveal>
            <p class="eyebrow">SOURCE METADATA</p>
            <dl>
                <div><dt>Publisher</dt><dd><?php echo e($document->publisher ?: 'Not specified'); ?></dd></div>
                <div><dt>DOI</dt><dd><?php echo e($document->doi ?: 'Not available'); ?></dd></div>
                <div><dt>ISBN</dt><dd><?php echo e($document->isbn ?: 'Not available'); ?></dd></div>
                <div><dt>Visibility</dt><dd>Eligible public source</dd></div>
            </dl>
            <a href="<?php echo e(route('workspace', ['source' => $document->id])); ?>" class="btn btn-primary btn-full">Use in Research <span>↗</span></a>
        </aside>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views\research\library\show.blade.php ENDPATH**/ ?>


<?php $__env->startSection(
    'title',
    $savedResult->title
    .' — Saved Result'
); ?>

<?php $__env->startSection('content'); ?>

<?php
    $run = $savedResult->aiRun;

    $conversation =
        $run
            ?->assistantMessage
            ?->conversation;

    $primaryResult =
        $run
            ?->results
            ?->firstWhere(
                'result_type',
                'primary'
            )
        ?: $run
            ?->results
            ?->first();

    $answer =
        $primaryResult
            ?->content
        ?: $run
            ?->assistantMessage
            ?->content
        ?: 'Belum ada output final pada AI Run ini.';

    $evidence =
        data_get(
            $primaryResult
                ?->structured_output_json,
            'evidence',
            data_get(
                $run
                    ?->assistantMessage
                    ?->metadata,
                'evidence',
                []
            )
        );

    $citations =
        $primaryResult
            ?->citations_json
        ?: data_get(
            $run
                ?->assistantMessage
                ?->metadata,
            'citations',
            []
        );
?>

<section class="saved-detail-page">

    <div class="saved-detail-breadcrumb">
        <a href="<?php echo e(route('saved.index')); ?>">
            ← Saved Results
        </a>
    </div>

    <?php if(session('success')): ?>

        <div
            class="alert alert-success"
            role="status"
        >
            <?php echo e(session('success')); ?>

        </div>

    <?php endif; ?>

    <?php if($errors->any()): ?>

        <div
            class="alert alert-error"
            role="alert"
        >
            <?php echo e($errors->first()); ?>

        </div>

    <?php endif; ?>

    <header
        class="saved-detail-head"
        data-reveal
    >
        <div>
            <div class="saved-detail-kicker">

                <?php if(
                    $savedResult
                        ->is_favorite
                ): ?>
                    <span>
                        ★ FAVORITE
                    </span>
                <?php endif; ?>

                <span>
                    <?php echo e($run
                            ?->aiTool
                            ?->name
                        ?: 'RESEARCH RESULT'); ?>

                </span>

            </div>

            <h1 class="display-type">
                <?php echo e($savedResult->title); ?>

            </h1>

            <p>
                Disimpan
                <?php echo e($savedResult
                        ->created_at
                        ->format(
                            'd M Y · H:i'
                        )); ?>.
                Output tetap terhubung dengan
                AI Run dan source asalnya.
            </p>
        </div>

        <form
            method="POST"
            action="<?php echo e(route(
                    'saved.favorite',
                    $savedResult
                )); ?>"
        >
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            <button
                type="submit"
                class="
                    saved-detail-favorite
                    <?php echo e($savedResult
                            ->is_favorite
                        ? 'is-active'
                        : ''); ?>

                "
            >
                <span>
                    <?php echo e($savedResult
                            ->is_favorite
                        ? '★'
                        : '☆'); ?>

                </span>

                <?php echo e($savedResult
                        ->is_favorite
                    ? 'Favorite'
                    : 'Add favorite'); ?>

            </button>
        </form>
    </header>

    <div class="saved-detail-layout">

        <main class="saved-detail-main">

            <section class="saved-answer">

                <div class="saved-section-label">
                    ANSWER
                </div>

                <div
                    class="
                        saved-answer__content
                    "
                >
                    <?php echo nl2br(
                        e($answer)
                    ); ?>

                </div>

            </section>

            <?php if(
                is_array($evidence)
                && count($evidence)
            ): ?>

                <section class="saved-evidence">

                    <div class="saved-section-label">
                        EVIDENCE
                    </div>

                    <div
                        class="
                            saved-evidence__items
                        "
                    >
                        <?php $__currentLoopData = $evidence; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <article
                                class="
                                    saved-evidence__item
                                "
                            >
                                <span>
                                    [
                                    <?php echo e(str_pad(
                                            (string) (
                                                $index
                                                + 1
                                            ),
                                            2,
                                            '0',
                                            STR_PAD_LEFT
                                        )); ?>

                                    ]
                                </span>

                                <p>
                                    <?php echo e(is_array(
                                            $item
                                        )
                                        ? (
                                            data_get(
                                                $item,
                                                'text'
                                            )
                                            ?: data_get(
                                                $item,
                                                'content'
                                            )
                                            ?: json_encode(
                                                $item,
                                                JSON_UNESCAPED_UNICODE
                                                | JSON_UNESCAPED_SLASHES
                                            )
                                        )
                                        : $item); ?>

                                </p>
                            </article>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </section>

            <?php endif; ?>

            <?php if(
                $run
                    ?->sources
                    ?->isNotEmpty()
            ): ?>

                <section class="saved-sources">

                    <div class="saved-section-label">
                        SOURCES
                    </div>

                    <div
                        class="
                            saved-sources__list
                        "
                    >

                        <?php $__currentLoopData = $run->sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <article
                                class="
                                    saved-source
                                "
                            >
                                <span
                                    class="
                                        saved-source__index
                                    "
                                >
                                    <?php echo e(str_pad(
                                            (string) (
                                                $index
                                                + 1
                                            ),
                                            2,
                                            '0',
                                            STR_PAD_LEFT
                                        )); ?>

                                </span>

                                <div>
                                    <strong>
                                        <?php echo e($source->title); ?>

                                    </strong>

                                    <p>
                                        <?php echo e($source
                                                ->source_label
                                            ?: 'Curated Source'); ?>


                                        <?php if(
                                            $source
                                                ->publication_year
                                        ): ?>
                                            ·
                                            <?php echo e($source
                                                    ->publication_year); ?>

                                        <?php endif; ?>

                                        <?php if(
                                            $source
                                                ->category
                                                ?->name
                                        ): ?>
                                            ·
                                            <?php echo e($source
                                                    ->category
                                                    ->name); ?>

                                        <?php endif; ?>
                                    </p>

                                    <?php if($source->doi): ?>
                                        <small>
                                            DOI:
                                            <?php echo e($source->doi); ?>

                                        </small>
                                    <?php endif; ?>
                                </div>

                            </article>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </section>

            <?php endif; ?>

            <?php if(
                is_array($citations)
                && count($citations)
            ): ?>

                <section class="saved-citations">

                    <div class="saved-section-label">
                        CITATIONS
                    </div>

                    <div
                        class="
                            saved-citations__content
                        "
                    >
                        <?php $__currentLoopData = $citations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $citation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <p>
                                <?php echo e(is_array(
                                        $citation
                                    )
                                    ? (
                                        data_get(
                                            $citation,
                                            'text'
                                        )
                                        ?: data_get(
                                            $citation,
                                            'citation'
                                        )
                                        ?: json_encode(
                                            $citation,
                                            JSON_UNESCAPED_UNICODE
                                            | JSON_UNESCAPED_SLASHES
                                        )
                                    )
                                    : $citation); ?>

                            </p>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </section>

            <?php endif; ?>

        </main>

        <aside class="saved-detail-side">

            <section class="saved-info-card">

                <div class="saved-section-label">
                    RESEARCH CONTEXT
                </div>

                <dl>

                    <div>
                        <dt>
                            Status
                        </dt>

                        <dd>
                            <?php echo e(strtoupper(
                                    $run?->status
                                    ?: 'UNKNOWN'
                                )); ?>

                        </dd>
                    </div>

                    <div>
                        <dt>
                            Research Tool
                        </dt>

                        <dd>
                            <?php echo e($run
                                    ?->aiTool
                                    ?->name
                                ?: '—'); ?>

                        </dd>
                    </div>

                    <div>
                        <dt>
                            Prompt
                        </dt>

                        <dd>
                            <?php echo e($run
                                    ?->promptTemplate
                                    ?->name
                                ?: '—'); ?>

                        </dd>
                    </div>

                    <div>
                        <dt>
                            Model
                        </dt>

                        <dd>
                            <?php echo e($run?->model_name
                                ?: '—'); ?>

                        </dd>
                    </div>

                    <div>
                        <dt>
                            Sources
                        </dt>

                        <dd>
                            <?php echo e($run
                                    ?->sources
                                    ?->count()
                                ?? 0); ?>

                        </dd>
                    </div>

                </dl>

                <?php if($conversation): ?>

                    <a
                        href="<?php echo e(route(
                                'workspace.conversation',
                                $conversation
                            )); ?>"
                        class="
                            btn
                            btn-secondary
                            btn-full
                        "
                    >
                        Buka Conversation
                    </a>

                <?php endif; ?>

            </section>

            <section class="saved-edit-card">

                <div class="saved-section-label">
                    SAVED NOTE
                </div>

                <form
                    method="POST"
                    action="<?php echo e(route(
                            'saved.update',
                            $savedResult
                        )); ?>"
                >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>

                    <label>
                        Judul

                        <input
                            type="text"
                            name="title"
                            value="<?php echo e(old(
                                    'title',
                                    $savedResult
                                        ->title
                                )); ?>"
                            maxlength="255"
                            required
                        >
                    </label>

                    <label>
                        Catatan
                        <span
                            class="
                                field-optional
                            "
                        >
                            Opsional
                        </span>

                        <textarea
                            name="notes"
                            rows="6"
                            maxlength="4000"
                            placeholder="Kenapa hasil ini penting? Apa langkah berikutnya?"
                        ><?php echo e(old(
                            'notes',
                            $savedResult->notes
                        )); ?></textarea>
                    </label>

                    <button
                        type="submit"
                        class="
                            btn
                            btn-primary
                            btn-full
                        "
                    >
                        Simpan Catatan
                    </button>
                </form>

            </section>

            <section
                class="
                    saved-delete-card
                "
            >

                <strong>
                    Hapus dari Saved Results
                </strong>

                <p>
                    Conversation dan AI Run
                    tidak ikut dihapus.
                </p>

                <form
                    method="POST"
                    action="<?php echo e(route(
                            'saved.destroy',
                            $savedResult
                        )); ?>"
                    data-confirm="Hapus hasil ini dari Saved Results?"
                >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button
                        type="submit"
                    >
                        Hapus Saved Result
                    </button>
                </form>

            </section>

        </aside>

    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views\saved\show.blade.php ENDPATH**/ ?>
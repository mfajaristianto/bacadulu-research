<?php $__env->startSection('title', 'AI Run #'.$run->id); ?>
<?php $__env->startSection('page_title', 'AI Runs'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $validCitations = $run->citations->where('is_valid', true);
    $invalidCitations = $run->citations->where('is_valid', false);
    $primaryResult = $run->results->firstWhere('result_type', 'primary');
?>

<section class="admin-page">
    <header class="bd-admin-page-head">
        <div class="bd-admin-page-head__copy">
            <p class="bd-admin-kicker">AI CONTROL / RUN TRACE</p>
            <h1>RUN-<?php echo e(str_pad($run->id, 5, '0', STR_PAD_LEFT)); ?></h1>
            <p><?php echo e($run->uuid); ?></p>
        </div>
        <div class="bd-admin-page-head__actions"><a href="<?php echo e(route('admin.ai-runs.index')); ?>" class="bd-admin-button bd-admin-button--ghost">← AI Runs</a></div>
    </header>

    <div class="bd-admin-panels">
        <article class="bd-admin-panel"><small>STATUS</small><strong><?php echo e(str($run->status)->replace('_',' ')->title()); ?></strong><p><?php echo e($durationMs !== null ? number_format($durationMs / 1000, 2).' sec' : 'Execution timing incomplete'); ?></p></article>
        <article class="bd-admin-panel"><small>RETRIEVAL</small><strong><?php echo e($run->retrievals->count()); ?></strong><p><?php echo e($run->sources->count()); ?> contributing sources.</p></article>
        <article class="bd-admin-panel"><small>CITATIONS</small><strong><?php echo e($validCitations->count()); ?></strong><p><?php echo e($invalidCitations->count()); ?> invalid citation.</p></article>
    </div>

    <section class="bd-admin-section">
        <div class="bd-admin-section__head"><div><h2>Execution Trace</h2><p>Urutan provenance run ini.</p></div></div>
        <div class="bd-admin-trace">
            <article><span>01</span><div><strong>Request</strong><small><?php echo e($run->user?->name ?: 'Unknown user'); ?> · <?php echo e($conversation?->title ?: 'No conversation title'); ?></small></div></article>
            <article><span>02</span><div><strong>Prompt Version</strong><small><?php echo e($run->promptTemplate ? $run->promptTemplate->name.' · v'.$run->promptTemplate->version : 'Not recorded'); ?></small></div></article>
            <article><span>03</span><div><strong>Retrieval</strong><small><?php echo e($run->retrievals->count()); ?> ranked chunks selected</small></div></article>
            <article><span>04</span><div><strong>Evidence</strong><small><?php echo e($run->sources->count()); ?> source documents contributed</small></div></article>
            <article><span>05</span><div><strong>Provider</strong><small><?php echo e(strtoupper($run->model_provider ?: '—')); ?> · <?php echo e($run->model_name ?: '—'); ?></small></div></article>
            <article><span>06</span><div><strong>Citation Validation</strong><small><?php echo e($validCitations->count()); ?> valid · <?php echo e($invalidCitations->count()); ?> invalid</small></div></article>
            <article><span>07</span><div><strong>Result</strong><small><?php echo e($primaryResult ? 'Primary result stored' : 'No primary result stored'); ?></small></div></article>
        </div>
    </section>

    <section class="bd-admin-section">
        <div class="bd-admin-two-column">
            <div class="bd-admin-detail-list">
                <div><span>User</span><strong><?php echo e($run->user?->name ?: '—'); ?></strong></div>
                <div><span>Email</span><strong><?php echo e($run->user?->email ?: '—'); ?></strong></div>
                <div><span>Research Tool</span><strong><?php echo e($run->aiTool?->name ?: '—'); ?></strong></div>
                <div><span>Prompt</span><strong><?php echo e($run->promptTemplate ? $run->promptTemplate->name.' · v'.$run->promptTemplate->version : '—'); ?></strong></div>
                <div><span>Provider</span><strong><?php echo e(strtoupper($run->model_provider ?: '—')); ?></strong></div>
                <div><span>Model</span><strong><?php echo e($run->model_name ?: '—'); ?></strong></div>
                <div><span>Started</span><strong><?php echo e(optional($run->started_at)->format('d M Y · H:i:s') ?: '—'); ?></strong></div>
                <div><span>Finished</span><strong><?php echo e(optional($run->finished_at)->format('d M Y · H:i:s') ?: '—'); ?></strong></div>
            </div>

            <aside class="bd-admin-form__aside">
                <section><strong>Parameters</strong><?php $__empty_1 = true; $__currentLoopData = $parameters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><p><code><?php echo e($key); ?></code>: <?php echo e(is_scalar($value) ? $value : json_encode($value)); ?></p><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><p>No user parameters recorded.</p><?php endif; ?></section>
                <?php if($run->error_message): ?><section><strong>Error</strong><p class="admin-danger-text"><?php echo e($run->error_message); ?></p></section><?php endif; ?>
            </aside>
        </div>
    </section>

    <section class="bd-admin-section">
        <div class="bd-admin-section__head"><div><h2>Retrieved Evidence</h2><p>Ranked evidence chunks used by the run.</p></div></div>
        <div class="bd-admin-table-wrap">
            <table class="bd-admin-table">
                <thead><tr><th>Rank</th><th>Source</th><th>Chunk</th><th>Score</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $run->retrievals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retrieval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>#<?php echo e($retrieval->rank_no); ?></td>
                        <td><div class="bd-admin-table__title"><strong><?php echo e($retrieval->document?->title ?: '—'); ?></strong><small>SRC-<?php echo e($retrieval->document_id); ?></small></div></td>
                        <td><?php echo e($retrieval->document_chunk_id ?: '—'); ?></td>
                        <td><?php echo e($retrieval->score !== null ? number_format((float) $retrieval->score, 4) : '—'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4">No retrieval evidence recorded.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <section class="bd-admin-section">
        <div class="bd-admin-section__head"><div><h2>Citations</h2><p>Validation result per citation key.</p></div></div>
        <div class="bd-admin-table-wrap">
            <table class="bd-admin-table">
                <thead><tr><th>Key</th><th>Source</th><th>Chunk</th><th>Validation</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $run->citations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $citation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><code><?php echo e($citation->citation_key); ?></code></td>
                        <td><?php echo e($citation->document?->title ?: '—'); ?></td>
                        <td><?php echo e($citation->document_chunk_id ?: '—'); ?></td>
                        <td><span class="bd-admin-status bd-admin-status--<?php echo e($citation->is_valid ? 'success' : 'failed'); ?>"><?php echo e($citation->is_valid ? 'Valid' : 'Invalid'); ?></span></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4">No citations recorded.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <section class="bd-admin-section">
        <div class="bd-admin-section__head"><div><h2>Primary Result</h2><p>Stored output from the provider pipeline.</p></div></div>
        <div class="bd-admin-result"><pre><?php echo e($primaryResult?->content ?: 'No primary result stored.'); ?></pre></div>
    </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views\admin\ai-runs\show.blade.php ENDPATH**/ ?>
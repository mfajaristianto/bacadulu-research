

<?php
    $editing =
        $template->exists;

    $schemaValue =
        old(
            'schema_json',
            json_encode(
                $template->schema_json
                ?? [],
                JSON_PRETTY_PRINT
                |
                JSON_UNESCAPED_UNICODE
                |
                JSON_UNESCAPED_SLASHES
            )
        );
?>

<?php $__env->startSection(
    'title',
    $editing
        ? 'Edit Document Template'
        : 'Document Template Baru'
); ?>

<?php $__env->startSection('page_title', 'Document Templates'); ?>

<?php $__env->startSection('content'); ?>

<section class="admin-page">

    <header class="bd-admin-page-head">

        <div class="bd-admin-page-head__copy">

            <p class="bd-admin-kicker">
                OUTPUT ENGINE / TEMPLATE
            </p>

            <h1>
                <?php echo e($editing
                        ? $template->name
                        : 'Template Baru'); ?>

            </h1>

            <p>
                Setiap perubahan pada template menaikkan version.
                Generation lama tetap menyimpan snapshot template lama.
            </p>

        </div>

        <div class="bd-admin-page-head__actions">

            <a
                href="<?php echo e(route('admin.document-templates.index')); ?>"
                class="bd-admin-button bd-admin-button--ghost"
            >
                ← Templates
            </a>

        </div>

    </header>

    <form
        method="POST"
        action="<?php echo e($editing
                ? route(
                    'admin.document-templates.update',
                    $template
                )
                : route(
                    'admin.document-templates.store'
                )); ?>"
        class="bd-admin-form-shell"
    >

        <?php echo csrf_field(); ?>

        <?php if($editing): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <div class="bd-admin-form">

            <section class="bd-admin-form__section">

                <div class="bd-admin-form__section-head">

                    <strong>
                        Identity
                    </strong>

                    <p>
                        Code harus stabil karena masuk provenance generation.
                    </p>

                </div>

                <div class="bd-admin-form__grid">

                    <label class="bd-admin-form-field">

                        <span>
                            Code
                        </span>

                        <input
                            class="bd-admin-input"
                            name="code"
                            value="<?php echo e(old('code', $template->code)); ?>"
                            placeholder="custom-research-article"
                            required
                        >

                    </label>

                    <label class="bd-admin-form-field">

                        <span>
                            Name
                        </span>

                        <input
                            class="bd-admin-input"
                            name="name"
                            value="<?php echo e(old('name', $template->name)); ?>"
                            required
                        >

                    </label>

                    <label class="bd-admin-form-field">

                        <span>
                            Document type
                        </span>

                        <select
                            class="bd-admin-select"
                            name="document_type"
                        >

                            <?php $__currentLoopData = $documentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option
                                    value="<?php echo e($type); ?>"
                                    <?php if(
                                        old(
                                            'document_type',
                                            $template->document_type
                                        )
                                        ===
                                        $type
                                    ): echo 'selected'; endif; ?>
                                >
                                    <?php echo e($type); ?>

                                </option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>

                    </label>

                    <label class="bd-admin-form-field">

                        <span>
                            Status
                        </span>

                        <select
                            class="bd-admin-select"
                            name="status"
                        >

                            <option
                                value="active"
                                <?php if(
                                    old(
                                        'status',
                                        $template->status
                                        ?: 'active'
                                    )
                                    ===
                                    'active'
                                ): echo 'selected'; endif; ?>
                            >
                                Active
                            </option>

                            <option
                                value="inactive"
                                <?php if(
                                    old(
                                        'status',
                                        $template->status
                                    )
                                    ===
                                    'inactive'
                                ): echo 'selected'; endif; ?>
                            >
                                Inactive
                            </option>

                        </select>

                    </label>

                    <label class="bd-admin-form-field is-full">

                        <span>
                            Description
                        </span>

                        <textarea
                            class="bd-admin-input"
                            name="description"
                            rows="3"
                        ><?php echo e(old('description', $template->description)); ?></textarea>

                    </label>

                    <label class="bd-admin-form-field is-full">

                        <input
                            type="hidden"
                            name="is_default"
                            value="0"
                        >

                        <span
                            style="
                                display:flex;
                                align-items:center;
                                gap:10px;
                            "
                        >
                            <input
                                type="checkbox"
                                name="is_default"
                                value="1"
                                <?php if(
                                    old(
                                        'is_default',
                                        $template->is_default
                                    )
                                ): echo 'checked'; endif; ?>
                            >

                            Jadikan default template untuk document type ini
                        </span>

                    </label>

                </div>

            </section>

            <section class="bd-admin-form__section">

                <div class="bd-admin-form__section-head">

                    <strong>
                        Schema JSON
                    </strong>

                    <p>
                        Role yang diizinkan:
                        research_result,
                        evidence,
                        method_note,
                        conclusion,
                        draft.
                    </p>

                </div>

                <label class="bd-admin-form-field is-full">

                    <textarea
                        class="bd-admin-input"
                        name="schema_json"
                        rows="28"
                        spellcheck="false"
                        style="
                            font-family:
                                ui-monospace,
                                SFMono-Regular,
                                Menlo,
                                Consolas,
                                monospace;
                            line-height:1.55;
                        "
                        required
                    ><?php echo e($schemaValue); ?></textarea>

                </label>

            </section>

            <section class="bd-admin-form__section">

                <button
                    type="submit"
                    class="bd-admin-button bd-admin-button--primary"
                >
                    <?php echo e($editing
                            ? 'Simpan sebagai Version Baru'
                            : 'Buat Template'); ?>

                </button>

            </section>

        </div>

    </form>

    <?php if(
        $editing
        &&
        ! $template->is_default
        &&
        $template->status === 'active'
    ): ?>

        <form
            method="POST"
            action="<?php echo e(route('admin.document-templates.destroy', $template)); ?>"
            style="margin-top:18px;"
        >

            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>

            <button
                type="submit"
                class="bd-admin-button bd-admin-button--ghost"
            >
                Nonaktifkan Template
            </button>

        </form>

    <?php endif; ?>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/document-templates/form.blade.php ENDPATH**/ ?>
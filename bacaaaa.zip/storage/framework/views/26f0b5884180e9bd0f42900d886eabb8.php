<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'item',
    'activeId' => null,
    'conversationTitle',
    'conversationMeta',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'item',
    'activeId' => null,
    'conversationTitle',
    'conversationMeta',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $itemId = data_get($item, 'id');
    $title = $conversationTitle($item);
    $meta = $conversationMeta($item);
    $isActive = (string) $activeId === (string) $itemId;
    $isPinned = filled(data_get($item, 'pinned_at'));
?>

<div
    class="br-sidebar-conversation-row <?php echo e($isActive ? 'is-active' : ''); ?>"
    data-sidebar-conversation
    data-conversation-id="<?php echo e($itemId); ?>"
>
    <a
        href="<?php echo e(route('workspace.conversation', $item)); ?>"
        class="br-sidebar-conversation <?php echo e($isActive ? 'is-active' : ''); ?>"
        title="<?php echo e($title); ?>"
        data-conversation-link
    >
        <span class="br-sidebar-conversation__icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none">
                <path d="M5 6.5h14v9.2H9.4L5 19V6.5Z"/>
            </svg>
        </span>

        <span class="br-sidebar-conversation__body">
            <strong data-conversation-title><?php echo e(\Illuminate\Support\Str::limit($title, 43)); ?></strong>
            <small><?php echo e($meta); ?></small>
        </span>

        <?php if($isPinned): ?>
            <span class="br-sidebar-conversation__pin" title="Dipin" aria-label="Dipin">
                <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <path d="M9 3h6l-1 5 3 4v2H7v-2l3-4-1-5ZM12 14v7"/>
                </svg>
            </span>
        <?php endif; ?>
    </a>

    
    <form
        method="POST"
        action="<?php echo e(route('conversations.rename', $item)); ?>"
        class="br-sidebar-inline-rename"
        data-conversation-rename-form
        hidden
    >
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>

        <span class="br-sidebar-conversation__icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none">
                <path d="M5 6.5h14v9.2H9.4L5 19V6.5Z"/>
            </svg>
        </span>

        <input
            type="text"
            name="title"
            value="<?php echo e($title); ?>"
            maxlength="220"
            autocomplete="off"
            aria-label="Ubah nama percakapan"
            data-conversation-rename-input
            required
        >

        <button type="submit" class="sr-only" tabindex="-1">Simpan nama</button>
    </form>

    <details class="br-sidebar-conversation-menu" data-conversation-menu>
        <summary aria-label="Opsi untuk <?php echo e($title); ?>" title="Opsi percakapan">
            <svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor">
                <circle cx="5" cy="12" r="1.75"/>
                <circle cx="12" cy="12" r="1.75"/>
                <circle cx="19" cy="12" r="1.75"/>
            </svg>
        </summary>

        <div class="br-sidebar-conversation-menu__items" data-conversation-menu-panel>
            <button type="button" data-conversation-rename>
                <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <path d="m4 20 4.5-1 10-10-3.5-3.5-10 10L4 20Z"/>
                    <path d="m13.8 6.7 3.5 3.5"/>
                </svg>
                <span>Rename</span>
            </button>

            <form method="POST" action="<?php echo e(route($isPinned ? 'conversations.unpin' : 'conversations.pin', $item)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <button type="submit">
                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                        <path d="M9 3h6l-1 5 3 4v2H7v-2l3-4-1-5ZM12 14v7"/>
                    </svg>
                    <span><?php echo e($isPinned ? 'Lepas pin' : 'Pin percakapan'); ?></span>
                </button>
            </form>

            <span class="br-sidebar-conversation-menu__divider" aria-hidden="true"></span>

            <a
                class="is-danger"
                href="<?php echo e(route('conversations.delete.confirmation', $item)); ?>"
            >
                <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13M10 11v6M14 11v6"/>
                </svg>
                <span>Delete</span>
            </a>
        </div>
    </details>
</div>
<?php /**PATH D:\Pkl\bacadulu-research\resources\views\components\research-sidebar-conversation.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Document Templates'); ?>
<?php $__env->startSection('page_title', 'Document Templates'); ?>

<?php $__env->startSection('content'); ?>

<section class="admin-page">

    <header class="bd-admin-page-head">

        <div class="bd-admin-page-head__copy">

            <p class="bd-admin-kicker">
                OUTPUT ENGINE / TEMPLATES
            </p>

            <h1>
                Document Templates
            </h1>

            <p>
                Template menentukan section structure dan format
                DOCX/PDF tanpa mengubah provenance generation lama.
            </p>

        </div>

        <div class="bd-admin-page-head__actions">

            <a
                href="<?php echo e(route('admin.document-templates.create')); ?>"
                class="bd-admin-button bd-admin-button--primary"
            >
                Template Baru ＋
            </a>

        </div>

    </header>

    <form
        method="GET"
        class="bd-admin-filter"
    >

        <input
            class="bd-admin-input"
            type="search"
            name="search"
            value="<?php echo e(request('search')); ?>"
            placeholder="Cari template…"
        >

        <select
            class="bd-admin-select"
            name="document_type"
            data-auto-submit
        >

            <option value="">
                Semua document type
            </option>

            <?php $__currentLoopData = $documentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <option
                    value="<?php echo e($type); ?>"
                    <?php if(
                        request(
                            'document_type'
                        )
                        ===
                        $type
                    ): echo 'selected'; endif; ?>
                >
                    <?php echo e($type); ?>

                </option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

        <select
            class="bd-admin-select"
            name="status"
            data-auto-submit
        >

            <option value="">
                Semua status
            </option>

            <option
                value="active"
                <?php if(
                    request('status')
                    ===
                    'active'
                ): echo 'selected'; endif; ?>
            >
                Active
            </option>

            <option
                value="inactive"
                <?php if(
                    request('status')
                    ===
                    'inactive'
                ): echo 'selected'; endif; ?>
            >
                Inactive
            </option>

        </select>

    </form>

    <div class="bd-admin-table-wrap">

        <table class="bd-admin-table">

            <thead>

                <tr>
                    <th>Template</th>
                    <th>Document Type</th>
                    <th>Version</th>
                    <th>Generation</th>
                    <th>Status</th>
                    <th></th>
                </tr>

            </thead>

            <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>

                        <td>

                            <div class="bd-admin-table__title">

                                <strong>
                                    <?php echo e($template->name); ?>


                                    <?php if($template->is_default): ?>
                                        · DEFAULT
                                    <?php endif; ?>
                                </strong>

                                <small>
                                    <?php echo e($template->code); ?>

                                </small>

                            </div>

                        </td>

                        <td>
                            <?php echo e($template->document_type); ?>

                        </td>

                        <td>
                            v<?php echo e($template->version); ?>

                        </td>

                        <td>
                            <?php echo e($template->generations_count); ?>

                        </td>

                        <td>

                            <span
                                class="
                                    bd-admin-status
                                    bd-admin-status--<?php echo e($template->status === 'active'
                                            ? 'active'
                                            : 'draft'); ?>

                                "
                            >
                                <?php echo e(ucfirst($template->status)); ?>

                            </span>

                        </td>

                        <td>

                            <a
                                href="<?php echo e(route('admin.document-templates.edit', $template)); ?>"
                                class="bd-admin-table__action"
                            >
                                Edit →
                            </a>

                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td colspan="6">

                            <div class="bd-admin-empty">

                                <div class="bd-admin-empty__inner">

                                    <span class="bd-admin-empty__mark">
                                        DOC
                                    </span>

                                    <h3>
                                        Belum ada Document Template.
                                    </h3>

                                </div>

                            </div>

                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

    <?php echo e($templates->links()); ?>


</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/document-templates/index.blade.php ENDPATH**/ ?>
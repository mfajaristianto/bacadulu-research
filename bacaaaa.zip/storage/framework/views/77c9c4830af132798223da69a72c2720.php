<?php $__env->startSection('title', 'Internal Library — BacaDulu Research'); ?>
<?php $__env->startSection('content'); ?>
<section class="library-page">
    <div class="library-head" data-reveal>
        <div><p class="eyebrow">INTERNAL LIBRARY</p><h1>Research Library.</h1><p>Browse sumber published yang eligible untuk research workspace.</p></div>
        <div class="library-head-note"><span>Public sources only</span><small>Restricted records stay outside user retrieval.</small></div>
    </div>

    <form method="GET" action="<?php echo e(route('library.index')); ?>" class="library-filter" data-reveal>
        <label class="filter-field"><span>Search</span><input id="search" type="search" name="search" value="<?php echo e(request('search')); ?>" maxlength="160" placeholder="Title, abstract, publisher, DOI…"></label>
        <label class="filter-field"><span>Category</span><select id="category" name="category"><option value="">All categories</option><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($category->id); ?>" <?php if((string) request('category') === (string) $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
        <button type="submit" class="btn btn-primary">Search</button>
        <?php if(request()->filled('search') || request()->filled('category')): ?><a href="<?php echo e(route('library.index')); ?>" class="btn btn-ghost">Reset</a><?php endif; ?>
    </form>

    <div class="library-result-meta"><span><?php echo e($documents->total()); ?> sources</span><span>Page <?php echo e($documents->currentPage()); ?> of <?php echo e($documents->lastPage()); ?></span></div>

    <div class="document-grid">
        <?php $__empty_1 = true; $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('library.show', $document)); ?>" class="document-card" data-reveal>
                <div class="document-card-top"><span class="document-type"><?php echo e(strtoupper($document->document_type ?: 'DOCUMENT')); ?></span><?php if($document->publication_year): ?><span class="document-year"><?php echo e($document->publication_year); ?></span><?php endif; ?></div>
                <h3><?php echo e($document->title); ?></h3>
                <p><?php echo e(Str::limit($document->abstract ?: 'No abstract available.', 165)); ?></p>
                <div class="document-meta"><span><?php echo e($document->category?->name ?: 'Uncategorised'); ?></span><?php if($document->publisher): ?><span><?php echo e($document->publisher); ?></span><?php endif; ?></div>
                <div class="document-card-action">Open source <span>↗</span></div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty-state" data-reveal><span>0 results</span><strong>No matching sources.</strong><p>Try another keyword or category filter.</p></div>
        <?php endif; ?>
    </div>

    <?php if($documents->hasPages()): ?><div class="library-pagination"><?php echo e($documents->links()); ?></div><?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views\research\library\index.blade.php ENDPATH**/ ?>
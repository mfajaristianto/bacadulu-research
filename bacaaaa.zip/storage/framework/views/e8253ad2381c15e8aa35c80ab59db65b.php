<?php $__env->startSection('title', 'Prompt Versions'); ?>
<?php $__env->startSection('page_title', 'Prompt Versions'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-page">
    <header class="bd-admin-page-head">
        <div class="bd-admin-page-head__copy">
            <p class="bd-admin-kicker">AI CONTROL / PROMPT VERSIONS</p>
            <h1>Prompt Versions</h1>
            <p>Riwayat instruction yang pernah dibuat untuk setiap Research Tool. Versi aktif tidak diedit langsung.</p>
        </div>
    </header>

    <form method="GET" class="bd-admin-filter">
        <input class="bd-admin-input" type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="Cari prompt…">
        <select class="bd-admin-select" name="tool" data-auto-submit>
            <option value="">Semua Research Tool</option>
            <?php $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($tool->id); ?>" <?php if((string) request('tool') === (string) $tool->id): echo 'selected'; endif; ?>><?php echo e($tool->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select class="bd-admin-select" name="status" data-auto-submit>
            <option value="">Semua status</option>
            <?php $__currentLoopData = ['draft','active','archived']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($status); ?>" <?php if(request('status') === $status): echo 'selected'; endif; ?>><?php echo e(ucfirst($status)); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </form>

    <div class="bd-admin-table-wrap">
        <table class="bd-admin-table">
            <thead><tr><th>Prompt</th><th>Research Tool</th><th>Version</th><th>Status</th><th>Updated</th><th></th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $versions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prompt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><div class="bd-admin-table__title"><strong><?php echo e($prompt->display_name); ?></strong><small>PROMPT-<?php echo e(str_pad($prompt->id, 4, '0', STR_PAD_LEFT)); ?></small></div></td>
                    <td><?php echo e($prompt->aiTool?->name ?: 'Unassigned'); ?></td>
                    <td>v<?php echo e($prompt->version); ?></td>
                    <td><span class="bd-admin-status bd-admin-status--<?php echo e($prompt->status); ?>"><?php echo e(ucfirst($prompt->status)); ?></span></td>
                    <td><?php echo e(optional($prompt->updated_at)->format('d M Y · H:i')); ?></td>
                    <td>
                        <div class="bd-admin-inline-actions">
                            <a class="bd-admin-table__action" href="<?php echo e(route('admin.prompts.edit', $prompt)); ?>">Open</a>
                            <form method="POST" action="<?php echo e(route('admin.prompt-versions.duplicate', $prompt)); ?>"><?php echo csrf_field(); ?><button class="bd-admin-link-button" type="submit">New version</button></form>
                            <?php if($prompt->status !== 'active'): ?>
                                <form method="POST" action="<?php echo e(route('admin.prompt-versions.activate', $prompt)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><button class="bd-admin-link-button" type="submit">Activate</button></form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6"><div class="bd-admin-empty"><div class="bd-admin-empty__inner"><span class="bd-admin-empty__mark">VER</span><h3>Belum ada prompt version.</h3><p>Buat prompt dari Prompt Manager untuk memulai version history.</p></div></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo e($versions->links()); ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/prompt-versions/index.blade.php ENDPATH**/ ?>
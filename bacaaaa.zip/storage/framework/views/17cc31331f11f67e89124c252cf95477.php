<?php ($editing = $tool->exists); ?>

<?php $__env->startSection('title', $editing ? 'Edit Research Tool' : 'Tambah Research Tool'); ?>
<?php $__env->startSection('page_title', 'Research Tools'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-page">
    <header class="bd-admin-page-head">
        <div class="bd-admin-page-head__copy"><p class="bd-admin-kicker">AI CONTROL / TOOL</p><h1><?php echo e($editing ? $tool->name : 'Tambah Research Tool'); ?></h1><p>Tool menjelaskan jenis pekerjaan research; prompt version mengontrol instruction internal.</p></div>
        <div class="bd-admin-page-head__actions"><a href="<?php echo e(route('admin.tools.index')); ?>" class="bd-admin-button bd-admin-button--ghost">← Research Tools</a></div>
    </header>

    <form method="POST" action="<?php echo e($editing ? route('admin.tools.update', $tool) : route('admin.tools.store')); ?>" class="bd-admin-form-shell">
        <?php echo csrf_field(); ?>
        <?php if($editing): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

        <div class="bd-admin-form">
            <section class="bd-admin-form__section">
                <div class="bd-admin-form__section-head"><strong>Tool Identity</strong><p>Code dipakai internal, nama dan deskripsi dapat ditampilkan ke user.</p></div>
                <div class="bd-admin-form__grid">
                    <label class="bd-admin-form-field"><span>Code</span><input class="bd-admin-input" name="code" value="<?php echo e(old('code', $tool->code)); ?>" placeholder="research-gap" required></label>
                    <label class="bd-admin-form-field"><span>Status</span><select class="bd-admin-select" name="status"><option value="active" <?php if(old('status', $tool->status ?: 'active') === 'active'): echo 'selected'; endif; ?>>Active</option><option value="archived" <?php if(old('status', $tool->status) === 'archived'): echo 'selected'; endif; ?>>Archived</option></select></label>
                    <label class="bd-admin-form-field is-full"><span>Nama</span><input class="bd-admin-input" name="name" value="<?php echo e(old('name', $tool->name)); ?>" maxlength="180" required></label>
                    <label class="bd-admin-form-field is-full"><span>Deskripsi</span><textarea class="bd-admin-textarea" name="description" maxlength="2000"><?php echo e(old('description', $tool->description)); ?></textarea></label>
                    <input type="hidden" name="icon" value="<?php echo e(old('icon', $tool->icon)); ?>">
                </div>
            </section>
            <section class="bd-admin-form__section"><button class="bd-admin-button bd-admin-button--primary" type="submit"><?php echo e($editing ? 'Simpan Tool' : 'Buat Tool'); ?></button></section>
        </div>

        <aside class="bd-admin-form__aside">
            <section><strong>Active Prompt</strong><p><?php if($tool->activePromptTemplate): ?><?php echo e($tool->activePromptTemplate->name); ?> · v<?php echo e($tool->activePromptTemplate->version); ?>@elseBelum ada Prompt Version aktif.<?php endif; ?></p></section>
            <?php if($editing): ?><section><a href="<?php echo e(route('admin.prompt-versions.index', ['tool' => $tool->id])); ?>" class="bd-admin-button bd-admin-button--ghost">Lihat Prompt Versions</a></section><?php endif; ?>
        </aside>
    </form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/tools/form.blade.php ENDPATH**/ ?>
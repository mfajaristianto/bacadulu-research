
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'name',
    'label',
    'as' => 'input',
    'type' => 'text',
    'id' => null,
    'value' => null,
    'hint' => null,
    'error' => null,
    'required' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'name',
    'label',
    'as' => 'input',
    'type' => 'text',
    'id' => null,
    'value' => null,
    'hint' => null,
    'error' => null,
    'required' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $id ??= 'field-'.\Illuminate\Support\Str::slug(str_replace(['[', ']'], '-', $name));
    $errorKey = $error ?? str_replace(['[', ']'], ['.', ''], $name);
    $message = $errors->first($errorKey);
    $describedBy = collect([
        $hint ? $id.'-hint' : null,
        $message ? $id.'-error' : null,
    ])->filter()->implode(' ');
    $controlAttributes = $attributes->class('field__control')->merge(array_filter([
        'id' => $id,
        'name' => $name,
        'required' => $required,
        'aria-invalid' => $message ? 'true' : null,
        'aria-describedby' => $describedBy ?: null,
    ]));
?>

<div class="field">
    <label class="field__label" for="<?php echo e($id); ?>">
        <?php echo e($label); ?><?php if($required): ?><span class="field__required" aria-hidden="true">*</span><?php endif; ?>
    </label>

    <?php if($as === 'textarea'): ?>
        <textarea <?php echo e($controlAttributes); ?>><?php echo e(old($name, $value)); ?></textarea>
    <?php elseif($as === 'select'): ?>
        <select <?php echo e($controlAttributes); ?>><?php echo e($slot); ?></select>
    <?php else: ?>
        <input type="<?php echo e($type); ?>" value="<?php echo e($type === 'password' ? '' : old($name, $value)); ?>" <?php echo e($controlAttributes); ?>>
    <?php endif; ?>

    <?php if($hint): ?>
        <p class="field__hint" id="<?php echo e($id); ?>-hint"><?php echo e($hint); ?></p>
    <?php endif; ?>

    <?php if($message): ?>
        <p class="field__error" id="<?php echo e($id); ?>-error"><?php echo e($message); ?></p>
    <?php endif; ?>
</div>
<?php /**PATH D:\Pkl\bacadulu-research\resources\views\components\ui\field.blade.php ENDPATH**/ ?>
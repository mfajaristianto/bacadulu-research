<?php $__env->startSection('title', 'Users'); ?>
<?php $__env->startSection('page_title', 'Users'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-page">
    <header class="bd-admin-page-head">
        <div class="bd-admin-page-head__copy">
            <p class="bd-admin-kicker">ACCESS / USERS</p>
            <h1>Research Users</h1>
            <p>Lihat akun yang terdaftar, kelengkapan profile, aktivitas research, dan status akses.</p>
        </div>
    </header>

    <form method="GET" class="bd-admin-filter">
        <input class="bd-admin-input" type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="Nama, email, institusi…">
        <select class="bd-admin-select" name="status" data-auto-submit><option value="">Semua status</option><option value="active" <?php if(request('status') === 'active'): echo 'selected'; endif; ?>>Active</option><option value="suspended" <?php if(request('status') === 'suspended'): echo 'selected'; endif; ?>>Suspended</option></select>
        <span></span>
    </form>

    <div class="bd-admin-table-wrap">
        <table class="bd-admin-table">
            <thead><tr><th>User</th><th>Institusi</th><th>Profile</th><th>Research</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><div class="bd-admin-table__title"><strong><?php echo e($user->name); ?></strong><small><?php echo e($user->email); ?></small></div></td>
                    <td><?php echo e($user->institution ?: '—'); ?></td>
                    <td><?php echo e($user->profileCompletion()); ?>%</td>
                    <td><?php echo e($user->ai_runs_count); ?> runs · <?php echo e($user->conversations_count); ?> conversations</td>
                    <td><span class="bd-admin-status bd-admin-status--<?php echo e($user->status); ?>"><?php echo e(ucfirst($user->status)); ?></span></td>
                    <td><a class="bd-admin-table__action" href="<?php echo e(route('admin.users.show', $user)); ?>">Detail →</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6"><div class="bd-admin-empty"><div class="bd-admin-empty__inner"><span class="bd-admin-empty__mark">USR</span><h3>Tidak ada user.</h3></div></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo e($users->links()); ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views\admin\users\index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Buat Kata Sandi Baru — BacaDulu Research'); ?>

<?php $__env->startSection('content'); ?>
<section class="br-password-page">
    <div class="br-password-card">
        <a href="<?php echo e(route('home')); ?>" class="br-password-card__brand">
            <span>BacaDulu</span> Research
        </a>

        <h1>Buat kata sandi baru</h1>
        <p>
            Gunakan minimal 12 karakter dengan huruf besar, huruf kecil, angka,
            dan simbol agar akun lebih aman.
        </p>

        <?php if($errors->any()): ?>
            <p class="br-password-card__error" role="alert"><?php echo e($errors->first()); ?></p>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('password.update')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="token" value="<?php echo e($token); ?>">

            <label>
                <span>Email akun</span>
                <input
                    type="email"
                    name="email"
                    value="<?php echo e(old('email', $email)); ?>"
                    autocomplete="email"
                    required
                >
            </label>

            <label>
                <span>Kata sandi baru</span>
                <input
                    type="password"
                    name="password"
                    minlength="12"
                    autocomplete="new-password"
                    required
                >
            </label>

            <label>
                <span>Ulangi kata sandi baru</span>
                <input
                    type="password"
                    name="password_confirmation"
                    minlength="12"
                    autocomplete="new-password"
                    required
                >
            </label>

            <button type="submit">Simpan kata sandi baru</button>
        </form>

        <a href="<?php echo e(route('login')); ?>" class="br-password-card__back">← Kembali ke Masuk</a>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views\auth\reset-password.blade.php ENDPATH**/ ?>
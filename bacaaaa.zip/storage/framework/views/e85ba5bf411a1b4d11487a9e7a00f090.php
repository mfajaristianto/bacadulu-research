<?php ($editing = $category->exists); ?>

<?php $__env->startSection('title', $editing ? 'Edit Category' : 'Tambah Category'); ?>
<?php $__env->startSection('page_title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-page">
    <header class="bd-admin-page-head">
        <div class="bd-admin-page-head__copy">
            <p class="bd-admin-kicker">KNOWLEDGE / CATEGORY</p>
            <h1><?php echo e($editing ? 'Edit Category' : 'Tambah Category'); ?></h1>
            <p>Gunakan nama yang jelas dan stabil agar klasifikasi source konsisten.</p>
        </div>
        <div class="bd-admin-page-head__actions"><a href="<?php echo e(route('admin.categories.index')); ?>" class="bd-admin-button bd-admin-button--ghost">← Categories</a></div>
    </header>

    <form method="POST" action="<?php echo e($editing ? route('admin.categories.update', $category) : route('admin.categories.store')); ?>" class="bd-admin-form-shell">
        <?php echo csrf_field(); ?>
        <?php if($editing): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

        <div class="bd-admin-form">
            <section class="bd-admin-form__section">
                <div class="bd-admin-form__section-head"><strong>Category Detail</strong><p>Slug dibuat otomatis dari nama category.</p></div>
                <div class="bd-admin-form__grid">
                    <label class="bd-admin-form-field is-full"><span>Nama</span><input class="bd-admin-input" name="name" value="<?php echo e(old('name', $category->name)); ?>" maxlength="180" required></label>
                    <label class="bd-admin-form-field"><span>Parent <small>opsional</small></span><select class="bd-admin-select" name="parent_id"><option value="">Tidak ada</option><?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($parent->id); ?>" <?php if((string) old('parent_id', $category->parent_id) === (string) $parent->id): echo 'selected'; endif; ?>><?php echo e($parent->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
                    <label class="bd-admin-form-field"><span>Status</span><select class="bd-admin-select" name="status"><option value="active" <?php if(old('status', $category->status ?: 'active') === 'active'): echo 'selected'; endif; ?>>Active</option><option value="archived" <?php if(old('status', $category->status) === 'archived'): echo 'selected'; endif; ?>>Archived</option></select></label>
                </div>
            </section>
            <section class="bd-admin-form__section"><button class="bd-admin-button bd-admin-button--primary" type="submit"><?php echo e($editing ? 'Simpan Perubahan' : 'Buat Category'); ?></button></section>
        </div>

        <aside class="bd-admin-form__aside"><section><strong>Prinsip</strong><p>Category adalah klasifikasi utama source. Collection digunakan untuk bundel lintas category.</p></section></aside>
    </form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/categories/form.blade.php ENDPATH**/ ?>
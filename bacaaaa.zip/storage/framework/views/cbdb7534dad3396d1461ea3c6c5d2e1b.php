<?php $__env->startSection('title', 'Audit Logs'); ?>
<?php $__env->startSection('page_title', 'Audit Logs'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-page">
    <header class="bd-admin-page-head">
        <div class="bd-admin-page-head__copy"><p class="bd-admin-kicker">SYSTEM / AUDIT</p><h1>Audit Logs</h1><p>Jejak administratif dan perubahan operasional penting. Read-only.</p></div>
    </header>

    <form method="GET" class="bd-admin-filter">
        <input class="bd-admin-input" type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="Action, user, IP…">
        <select class="bd-admin-select" name="action" data-auto-submit><option value="">Semua action</option><?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($action); ?>" <?php if(request('action') === $action): echo 'selected'; endif; ?>><?php echo e($action); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
        <span></span>
    </form>

    <div class="bd-admin-table-wrap">
        <table class="bd-admin-table">
            <thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Target</th><th>IP</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e(optional($log->created_at)->format('d M Y · H:i:s')); ?></td>
                    <td><div class="bd-admin-table__title"><strong><?php echo e($log->user?->name ?: 'System / Admin'); ?></strong><small><?php echo e($log->user?->email ?: '—'); ?></small></div></td>
                    <td><code><?php echo e($log->action); ?></code></td>
                    <td><?php echo e($log->auditable_type ? class_basename($log->auditable_type).' #'.($log->auditable_id ?: '—') : '—'); ?></td>
                    <td><?php echo e($log->ip_address ?: '—'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5"><div class="bd-admin-empty"><div class="bd-admin-empty__inner"><span class="bd-admin-empty__mark">LOG</span><h3>Belum ada audit event.</h3><p>Event admin baru akan muncul setelah login dan operasi source berikutnya.</p></div></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo e($logs->links()); ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/audit/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Lengkapi Profil — BacaDulu Research'); ?>

<?php $__env->startSection('content'); ?>
<section class="profile-page profile-page--setup">
    <header
        class="profile-head"
        data-reveal
    >
        <div class="profile-head-copy">
            <p class="eyebrow">PROFILE SETUP</p>

            <h1 class="display-type">
                Sedikit konteks sebelum mulai research.
            </h1>

            <p>
                Lengkapi profil sampai minimum
                <?php echo e(config('research.profile_gate', 80)); ?>%.
                Field kosong tetap dapat disimpan dan tidak akan
                merusak halaman profil.
            </p>
        </div>

        <div
            class="profile-score"
            aria-label="Kelengkapan profil <?php echo e($user->profileCompletion()); ?> persen"
        >
            <span>Kelengkapan</span>

            <strong>
                <?php echo e($user->profileCompletion()); ?>%
            </strong>
        </div>
    </header>

    <div
        class="profile-progress-card"
        data-reveal
    >
        <div class="profile-progress-meta">
            <div>
                <strong>
                    <?php echo e($user->profileCompletion()); ?>%
                </strong>

                <span>
                    dari minimum
                    <?php echo e(config('research.profile_gate', 80)); ?>%
                </span>
            </div>

            <?php if($user->profileCompletion() >= config('research.profile_gate', 80)): ?>
                <span class="profile-progress-status is-ready">
                    Siap
                </span>
            <?php else: ?>
                <span class="profile-progress-status">
                    Belum lengkap
                </span>
            <?php endif; ?>
        </div>

        <div
            class="setup-progress"
            role="progressbar"
            aria-valuemin="0"
            aria-valuemax="100"
            aria-valuenow="<?php echo e($user->profileCompletion()); ?>"
        >
            <span
                data-progress-value="<?php echo e(min(
                    100,
                    $user->profileCompletion()
                )); ?>"
            ></span>
        </div>

        <?php if($user->missingProfileFields()): ?>
            <p>
                Masih kosong:
                <strong>
                    <?php echo e(implode(
                        ', ',
                        $user->missingProfileFields()
                    )); ?>

                </strong>
            </p>
        <?php else: ?>
            <p>
                Field profil yang digunakan untuk kelengkapan sudah terisi.
            </p>
        <?php endif; ?>
    </div>

    <?php if(session('success')): ?>
        <div
            class="alert alert-success"
            role="status"
        >
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div
            class="alert alert-error"
            role="alert"
        >
            Periksa kembali field yang ditandai di bawah.
        </div>
    <?php endif; ?>

    <div data-reveal>
        <?php echo $__env->make('components.profile-form', [
            'user' => $user,
            'mode' => 'setup',
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views\profile\setup.blade.php ENDPATH**/ ?>
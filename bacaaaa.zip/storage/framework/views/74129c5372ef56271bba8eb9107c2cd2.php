<?php $__env->startSection('title', 'Categories'); ?>
<?php $__env->startSection('page_title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-page">
    <header class="bd-admin-page-head">
        <div class="bd-admin-page-head__copy">
            <p class="bd-admin-kicker">KNOWLEDGE / CATEGORIES</p>
            <h1>Categories</h1>
            <p>Struktur utama untuk mengelompokkan source sebelum masuk ke retrieval.</p>
        </div>
        <div class="bd-admin-page-head__actions">
            <a href="<?php echo e(route('admin.categories.create')); ?>" class="bd-admin-button bd-admin-button--primary">Tambah Category ＋</a>
        </div>
    </header>

    <form method="GET" class="bd-admin-filter">
        <input class="bd-admin-input" type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="Cari kategori…">
        <select class="bd-admin-select" name="status" data-auto-submit>
            <option value="">Semua status</option>
            <option value="active" <?php if(request('status') === 'active'): echo 'selected'; endif; ?>>Active</option>
            <option value="archived" <?php if(request('status') === 'archived'): echo 'selected'; endif; ?>>Archived</option>
        </select>
        <span></span>
    </form>

    <div class="bd-admin-table-wrap">
        <table class="bd-admin-table">
            <thead><tr><th>Category</th><th>Parent</th><th>Sources</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><div class="bd-admin-table__title"><strong><?php echo e($category->name); ?></strong><small><?php echo e($category->slug); ?></small></div></td>
                    <td><?php echo e($category->parent?->name ?: '—'); ?></td>
                    <td><?php echo e($category->documents_count); ?></td>
                    <td><span class="bd-admin-status bd-admin-status--<?php echo e($category->status); ?>"><?php echo e(ucfirst($category->status)); ?></span></td>
                    <td><a class="bd-admin-table__action" href="<?php echo e(route('admin.categories.edit', $category)); ?>">Edit →</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5"><div class="bd-admin-empty"><div class="bd-admin-empty__inner"><span class="bd-admin-empty__mark">CAT</span><h3>Belum ada category.</h3><p>Buat category pertama agar source dapat diklasifikasikan.</p></div></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo e($categories->links()); ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>
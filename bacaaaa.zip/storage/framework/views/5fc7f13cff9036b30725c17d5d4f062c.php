<?php $__env->startSection('title', 'Lupa Kata Sandi — BacaDulu Research'); ?>

<?php $__env->startSection('content'); ?>
<section class="br-password-page">
    <div class="br-password-card">
        <a href="<?php echo e(route('home')); ?>" class="br-password-card__brand">
            <span>BacaDulu</span> Research
        </a>

        <h1>Lupa kata sandi?</h1>
        <p>
            Masukkan email akun Anda. Kami akan mengirim tautan reset ke email tersebut.
            Tautan ini menjadi verifikasi bahwa akun memang milik Anda.
        </p>

        <?php if(session('status')): ?>
            <p class="br-password-card__message" role="status"><?php echo e(session('status')); ?></p>
        <?php endif; ?>

        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="br-password-card__error" role="alert"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <form method="POST" action="<?php echo e(route('password.email')); ?>">
            <?php echo csrf_field(); ?>

            <label>
                <span>Email akun</span>
                <input
                    type="email"
                    name="email"
                    value="<?php echo e(old('email', $email)); ?>"
                    autocomplete="email"
                    required
                    autofocus
                >
            </label>

            <button type="submit">Kirim tautan reset</button>
        </form>

        <a
            href="<?php echo e(auth()->check() ? route('profile.edit') : route('login')); ?>"
            class="br-password-card__back"
        >
            ← <?php echo e(auth()->check() ? 'Kembali ke Profil' : 'Kembali ke Masuk'); ?>

        </a>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views\auth\forgot-password.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Research Tools'); ?>
<?php $__env->startSection('page_title', 'Research Tools'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-page">
    <header class="bd-admin-page-head">
        <div class="bd-admin-page-head__copy">
            <p class="bd-admin-kicker">AI CONTROL / RESEARCH TOOLS</p>
            <h1>Research Tools</h1>
            <p>Identitas pekerjaan research yang tersedia untuk user. Instruction internal dikelola melalui Prompt Versions.</p>
        </div>
        <div class="bd-admin-page-head__actions">
            <a href="<?php echo e(route('admin.tools.create')); ?>" class="bd-admin-button bd-admin-button--primary">Tambah Tool ＋</a>
        </div>
    </header>

    <form method="GET" action="<?php echo e(route('admin.tools.index')); ?>" class="bd-admin-filter">
        <input class="bd-admin-input" type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="Cari tool atau code…">
        <select class="bd-admin-select" name="status" data-auto-submit><option value="">Semua status</option><option value="active" <?php if(request('status') === 'active'): echo 'selected'; endif; ?>>Active</option><option value="archived" <?php if(request('status') === 'archived'): echo 'selected'; endif; ?>>Archived</option></select>
        <span></span>
    </form>

    <div class="bd-admin-table-wrap">
        <table class="bd-admin-table">
            <thead><tr><th>Tool</th><th>Code</th><th>Active Prompt</th><th>Versions</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><div class="bd-admin-table__title"><strong><?php echo e($tool->name); ?></strong><small><?php echo e(Str::limit($tool->description ?: 'Tanpa deskripsi', 100)); ?></small></div></td>
                    <td><code><?php echo e($tool->code); ?></code></td>
                    <td><?php if($tool->activePromptTemplate): ?><strong><?php echo e($tool->activePromptTemplate->name); ?></strong><small> v<?php echo e($tool->activePromptTemplate->version); ?></small><?php else: ?><span class="bd-admin-status">Belum ada</span><?php endif; ?></td>
                    <td><?php echo e($tool->prompt_templates_count); ?></td>
                    <td><span class="bd-admin-status bd-admin-status--<?php echo e($tool->status); ?>"><?php echo e(ucfirst($tool->status)); ?></span></td>
                    <td><a class="bd-admin-table__action" href="<?php echo e(route('admin.tools.edit', $tool)); ?>">Edit →</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6"><div class="bd-admin-empty"><div class="bd-admin-empty__inner"><span class="bd-admin-empty__mark">TOOL</span><h3>Belum ada Research Tool.</h3><p>Tool canonical dapat dibuat dari sini jika seeding belum dijalankan.</p></div></div></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php echo e($tools->links()); ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views\admin\tools\index.blade.php ENDPATH**/ ?>

<span class="bd-dash__ring bd-dash__ring--<?php echo e($tone ?? 'gold'); ?>" role="img" aria-label="<?php echo e($label); ?>">
    <svg viewBox="0 0 36 36" aria-hidden="true">
        <circle class="bd-dash__ring-track" cx="18" cy="18" r="15.9" pathLength="100" />
        <circle class="bd-dash__ring-fill" cx="18" cy="18" r="15.9" pathLength="100" stroke-dasharray="100" stroke-dashoffset="<?php echo e(100 - $pct); ?>" data-dash-ring="<?php echo e($pct); ?>" />
    </svg>
    <span class="bd-dash__ring-value" aria-hidden="true"><b data-dash-count="<?php echo e($pct); ?>"><?php echo e($pct); ?></b>%</span>
</span>
<?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/partials/dash-ring.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Security'); ?>
<?php $__env->startSection('page_title', 'Security'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-page">
    <header class="bd-admin-page-head">
        <div class="bd-admin-page-head__copy">
            <p class="bd-admin-kicker">SYSTEM / SECURITY</p>
            <h1>Security</h1>
            <p>Status konfigurasi keamanan admin tanpa pernah menampilkan password atau secret key.</p>
        </div>
    </header>

    <div class="bd-admin-panels">
        <article class="bd-admin-panel"><small>ADMIN CREDENTIAL</small><strong><?php echo e($security['admin_email_configured'] && $security['admin_password_configured'] ? 'Configured' : 'Incomplete'); ?></strong><p><?php echo e($security['admin_password_hashed'] ? 'Password admin tersimpan sebagai hash (ADMIN_PASSWORD_HASH).' : 'Password admin masih plaintext. Jalankan php artisan research:admin-password-hash lalu isi ADMIN_PASSWORD_HASH.'); ?></p></article>
        <article class="bd-admin-panel"><small>SESSION</small><strong><?php echo e(strtoupper($security['session_driver'])); ?></strong><p>SameSite <?php echo e($security['same_site']); ?> · Secure cookie <?php echo e($security['secure_cookie'] ? 'on' : 'off'); ?>.</p></article>
        <article class="bd-admin-panel"><small>APP ENV</small><strong><?php echo e(strtoupper($security['environment'])); ?></strong><p>Debug <?php echo e($security['debug'] ? 'ON' : 'OFF'); ?>.</p></article>
    </div>

    <section class="bd-admin-section">
        <div class="bd-admin-section__head"><div><h2>Security Configuration</h2><p>Nilai aman yang boleh dilihat administrator.</p></div></div>
        <div class="bd-admin-detail-list">
            <div><span>Admin path</span><strong>/<?php echo e($security['admin_path']); ?></strong></div>
            <div><span>Email verification user</span><strong><?php echo e($security['email_verification'] ? 'Required' : 'Optional'); ?></strong></div>
            <div><span>Current request IP</span><strong><?php echo e($security['current_ip']); ?></strong></div>
            <div><span>Login throttle</span><strong>Enabled</strong></div>
            <div><span>Security headers</span><strong>Enabled</strong></div>
        </div>
    </section>

    <section class="bd-admin-section">
        <div class="bd-admin-section__head"><div><h2>Recent Admin Events</h2><p>Login, logout, dan login gagal.</p></div></div>
        <div class="bd-admin-table-wrap">
            <table class="bd-admin-table">
                <thead><tr><th>Time</th><th>Action</th><th>IP</th><th>Metadata</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $recentAdminEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e(optional($event->created_at)->format('d M Y · H:i:s')); ?></td>
                        <td><code><?php echo e($event->action); ?></code></td>
                        <td><?php echo e($event->ip_address ?: '—'); ?></td>
                        <td><?php echo e(data_get($event->metadata_json, 'email', '—')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4">Belum ada admin security event.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/security/index.blade.php ENDPATH**/ ?>
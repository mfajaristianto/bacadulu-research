<?php $__env->startSection('title', 'Prompts'); ?>
<?php $__env->startSection('page_title', 'Prompts'); ?>

<?php
    $promptStatuses = [
        'draft',
        'active',
        'archived',
    ];
?>

<?php $__env->startSection('content'); ?>

<section class="admin-page">

    <header class="bd-admin-page-head">

        <div
            class="bd-admin-page-head__copy"
            data-admin-reveal
        >
            <p class="bd-admin-kicker">
                AI CONTROL / PROMPTS
            </p>

            <h1>
                Prompt Manager
            </h1>

            <p>
                Atur bagaimana setiap Research Tool memahami pertanyaan,
                memilih evidence, dan menyusun jawaban.
            </p>
        </div>

        <div
            class="bd-admin-page-head__actions"
            data-admin-reveal
            data-reveal-from="right"
        >
            <a
                href="<?php echo e(route('admin.tools.index')); ?>"
                class="
                    bd-admin-button
                    bd-admin-button--ghost
                "
            >
                Research Tools
            </a>

            <a
                href="<?php echo e(route('admin.prompt-versions.index')); ?>"
                class="
                    bd-admin-button
                    bd-admin-button--ghost
                "
            >
                Version History
            </a>

            <a
                href="<?php echo e(route('admin.prompts.create')); ?>"
                class="
                    bd-admin-button
                    bd-admin-button--primary
                "
            >
                Prompt Baru
                <span aria-hidden="true">＋</span>
            </a>
        </div>

    </header>

    <form
        method="GET"
        action="<?php echo e(route('admin.prompts.index')); ?>"
        class="bd-admin-filter"
        data-admin-reveal
        data-reveal-delay="60"
    >
        <input
            class="bd-admin-input"
            type="search"
            name="search"
            value="<?php echo e(request('search')); ?>"
            maxlength="160"
            placeholder="Cari prompt, deskripsi, atau instruction…"
            aria-label="Cari prompt"
        >

        <select
            class="bd-admin-select"
            name="status"
            data-auto-submit
            aria-label="Filter status prompt"
        >
            <option value="">
                Semua status
            </option>

            <?php $__currentLoopData = $promptStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option
                    value="<?php echo e($status); ?>"
                    <?php if(request('status') === $status): echo 'selected'; endif; ?>
                >
                    <?php echo e(ucfirst($status)); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <span></span>
    </form>

    <?php if($prompts->isEmpty()): ?>

        <div
            class="bd-admin-empty"
            data-admin-reveal
            data-reveal-delay="100"
        >
            <div class="bd-admin-empty__inner">

                <span class="bd-admin-empty__mark">
                    PROMPT SYSTEM
                </span>

                <h3>
                    Belum ada prompt.
                </h3>

                <p>
                    Buat Prompt Version pertama, hubungkan ke Research Tool,
                    lalu aktifkan version yang akan digunakan oleh pipeline AI.
                </p>

                <div class="bd-admin-empty__actions">

                    <a
                        href="<?php echo e(route('admin.prompts.create')); ?>"
                        class="
                            bd-admin-button
                            bd-admin-button--primary
                        "
                    >
                        Buat Prompt
                    </a>

                    <a
                        href="<?php echo e(route('admin.tools.index')); ?>"
                        class="
                            bd-admin-button
                            bd-admin-button--ghost
                        "
                    >
                        Lihat Research Tools
                    </a>

                </div>

            </div>
        </div>

    <?php else: ?>

        <div
            class="bd-admin-table-wrap"
            data-admin-reveal
            data-reveal-delay="100"
        >

            <table class="bd-admin-table">

                <thead>
                    <tr>
                        <th>Prompt</th>
                        <th>Research Tool</th>
                        <th>Version</th>
                        <th>Status</th>
                        <th>Updated</th>
                        <th></th>
                    </tr>
                </thead>

                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $prompts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prompt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr>

                            <td>
                                <div class="bd-admin-table__title">

                                    <strong>
                                        <?php echo e($prompt->display_name); ?>

                                    </strong>

                                    <small>
                                        <?php echo e(\Illuminate\Support\Str::limit(
                                                $prompt->short_description
                                                ?: $prompt->task_prompt,
                                                110
                                            )); ?>

                                    </small>

                                </div>
                            </td>

                            <td>
                                <?php echo e($prompt->aiTool?->name
                                    ?: 'Unassigned'); ?>

                            </td>

                            <td>
                                v<?php echo e($prompt->version); ?>

                            </td>

                            <td>
                                <span
                                    class="
                                        bd-admin-status
                                        bd-admin-status--<?php echo e($prompt->status); ?>

                                    "
                                >
                                    <?php echo e(ucfirst($prompt->status)); ?>

                                </span>
                            </td>

                            <td>
                                <?php echo e(optional(
                                        $prompt->updated_at
                                    )->format('d M Y')); ?>

                            </td>

                            <td>
                                <a
                                    class="bd-admin-table__action"
                                    href="<?php echo e(route(
                                            'admin.prompts.edit',
                                            $prompt
                                        )); ?>"
                                >
                                    <?php echo e($prompt->status === 'active'
                                        ? 'Lihat'
                                        : 'Edit'); ?>

                                    →
                                </a>
                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>
                            <td colspan="6">
                                Belum ada prompt.
                            </td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

        <div style="margin-top:18px;">
            <?php echo e($prompts->links()); ?>

        </div>

    <?php endif; ?>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/prompts/index.blade.php ENDPATH**/ ?>
<?php
    $editing = $prompt->exists;

    $locked =
        $editing
        && $prompt->status === 'active';

    $promptStatuses = [
        'draft',
        'active',
        'archived',
    ];
?>

<?php $__env->startSection(
    'title',
    $editing
        ? 'Prompt Editor'
        : 'Prompt Baru'
); ?>

<?php $__env->startSection('page_title', 'Prompts'); ?>

<?php $__env->startSection('content'); ?>

<section class="admin-page">

    <header class="bd-admin-page-head">

        <div
            class="bd-admin-page-head__copy"
            data-admin-reveal
        >
            <p class="bd-admin-kicker">
                AI CONTROL / PROMPT EDITOR
            </p>

            <h1>
                <?php echo e($editing
                        ? $prompt->name.' · v'.$prompt->version
                        : 'Prompt Baru'); ?>

            </h1>

            <p>
                <?php echo e($locked
                        ? 'Version aktif dikunci. Buat version baru untuk mengubah instruction tanpa merusak provenance AI Run lama.'
                        : 'Atur question template, instruction internal, retrieval behaviour, output, dan edukasi yang akan dilihat researcher.'); ?>

            </p>
        </div>


        <div
            class="bd-admin-page-head__actions"
            data-admin-reveal
            data-reveal-from="right"
        >

            <?php if($editing): ?>

                <form
                    method="POST"
                    action="<?php echo e(route(
                            'admin.prompt-versions.duplicate',
                            $prompt
                        )); ?>"
                >
                    <?php echo csrf_field(); ?>

                    <button
                        class="
                            bd-admin-button
                            bd-admin-button--ghost
                        "
                        type="submit"
                    >
                        Buat Versi Baru
                    </button>
                </form>


                <?php if(! $locked): ?>

                    <form
                        method="POST"
                        action="<?php echo e(route(
                                'admin.prompt-versions.activate',
                                $prompt
                            )); ?>"
                    >
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>

                        <button
                            class="
                                bd-admin-button
                                bd-admin-button--coral
                            "
                            type="submit"
                        >
                            Activate Version
                        </button>
                    </form>

                <?php endif; ?>

            <?php endif; ?>


            <a
                href="<?php echo e(route('admin.prompts.index')); ?>"
                class="
                    bd-admin-button
                    bd-admin-button--ghost
                "
            >
                ← Prompts
            </a>

        </div>

    </header>


    <?php if($locked): ?>

        <div
            class="
                bd-admin__flash
                bd-admin__flash--success
            "
            role="status"
        >
            <span></span>

            <p>
                Ini adalah version aktif.
                Instruction dikunci supaya AI Run lama tetap dapat
                ditelusuri ke Prompt Version yang sama.
                Untuk mengubah prompt, buat version baru.
            </p>
        </div>

    <?php endif; ?>


    <?php if($errors->any()): ?>

        <div
            class="
                bd-admin__flash
                bd-admin__flash--warning
            "
            role="alert"
        >
            <span></span>

            <div>
                <strong>
                    Prompt belum dapat disimpan.
                </strong>

                <ul style="margin:8px 0 0;padding-left:18px;">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php echo e($error); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>

    <?php endif; ?>


    <div
        class="bd-admin-prompt-layout"
        data-admin-reveal
        data-reveal-delay="70"
    >

        <aside
            class="bd-admin-prompt-versions"
            aria-label="Prompt version history"
        >

            <div class="bd-admin-prompt-versions__head">
                <strong>
                    VERSION HISTORY
                </strong>
            </div>


            <?php $__empty_1 = true; $__currentLoopData = $versions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $version): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <a
                    href="<?php echo e(route(
                            'admin.prompts.edit',
                            $version
                        )); ?>"
                    class="
                        bd-admin-prompt-version
                        <?php echo e($editing
                            && $version->id === $prompt->id
                                ? 'is-active'
                                : ''); ?>

                    "
                >
                    <span>
                        v<?php echo e($version->version); ?>

                    </span>

                    <span>
                        <?php echo e(ucfirst($version->status)); ?>

                    </span>
                </a>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <div
                    class="
                        bd-admin-prompt-version
                        is-active
                    "
                >
                    <span>
                        New
                    </span>

                    <span>
                        Draft
                    </span>
                </div>

            <?php endif; ?>

        </aside>


        <form
            method="POST"
            action="<?php echo e($editing
                    ? route(
                        'admin.prompts.update',
                        $prompt
                    )
                    : route(
                        'admin.prompts.store'
                    )); ?>"
            class="bd-admin-prompt-editor"
        >

            <?php echo csrf_field(); ?>

            <?php if($editing): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>


            

            <section class="bd-admin-form__section">

                <div class="bd-admin-form__section-head">

                    <strong>
                        Identity
                    </strong>

                    <p>
                        Hubungkan Prompt Version ke Research Tool.
                    </p>

                </div>


                <div class="bd-admin-form__grid">

                    <label class="bd-admin-form-field">

                        <span>
                            Research Tool
                        </span>

                        <select
                            class="bd-admin-select"
                            name="ai_tool_id"
                            <?php if($locked): echo 'disabled'; endif; ?>
                        >
                            <option value="">
                                Unassigned
                            </option>

                            <?php $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option
                                    value="<?php echo e($tool->id); ?>"
                                    <?php if(
                                        (string) old(
                                            'ai_tool_id',
                                            $prompt->ai_tool_id
                                        )
                                        ===
                                        (string) $tool->id
                                    ): echo 'selected'; endif; ?>
                                >
                                    <?php echo e($tool->name); ?>

                                </option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>


                        <?php if($locked): ?>

                            <input
                                type="hidden"
                                name="ai_tool_id"
                                value="<?php echo e($prompt->ai_tool_id); ?>"
                            >

                        <?php endif; ?>

                    </label>


                    <label class="bd-admin-form-field">

                        <span>
                            Version
                        </span>

                        <input
                            class="bd-admin-input"
                            type="number"
                            min="1"
                            max="9999"
                            name="version"
                            value="<?php echo e(old(
                                    'version',
                                    $prompt->version ?: 1
                                )); ?>"
                            <?php if($locked): echo 'readonly'; endif; ?>
                            required
                        >

                    </label>


                    <label
                        class="
                            bd-admin-form-field
                            is-full
                        "
                    >

                        <span>
                            English Name
                        </span>

                        <input
                            class="bd-admin-input"
                            type="text"
                            name="name"
                            value="<?php echo e(old(
                                    'name',
                                    $prompt->name
                                )); ?>"
                            maxlength="180"
                            placeholder="Research Gap"
                            <?php if($locked): echo 'readonly'; endif; ?>
                            required
                        >

                    </label>


                    <label class="bd-admin-form-field">

                        <span>
                            Nama Indonesia
                            <small>
                                opsional
                            </small>
                        </span>

                        <input
                            class="bd-admin-input"
                            type="text"
                            name="indonesian_name"
                            value="<?php echo e(old(
                                    'indonesian_name',
                                    $prompt->indonesian_name
                                )); ?>"
                            maxlength="180"
                            placeholder="Kesenjangan Penelitian"
                            <?php if($locked): echo 'readonly'; endif; ?>
                        >

                    </label>


                    <label class="bd-admin-form-field">

                        <span>
                            Status
                        </span>

                        <select
                            class="bd-admin-select"
                            name="status"
                            <?php if($locked): echo 'disabled'; endif; ?>
                        >

                            <?php $__currentLoopData = $promptStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option
                                    value="<?php echo e($status); ?>"
                                    <?php if(
                                        old(
                                            'status',
                                            $prompt->status ?: 'draft'
                                        )
                                        ===
                                        $status
                                    ): echo 'selected'; endif; ?>
                                >
                                    <?php echo e(ucfirst($status)); ?>

                                </option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>


                        <?php if($locked): ?>

                            <input
                                type="hidden"
                                name="status"
                                value="active"
                            >

                        <?php endif; ?>

                    </label>


                    <label
                        class="
                            bd-admin-form-field
                            is-full
                        "
                    >

                        <span>
                            Short Description
                            <small>
                                user-facing
                            </small>
                        </span>

                        <textarea
                            class="bd-admin-textarea"
                            name="short_description"
                            maxlength="1000"
                            placeholder="Penjelasan singkat fungsi prompt untuk researcher."
                            <?php if($locked): echo 'readonly'; endif; ?>
                        ><?php echo e(old('short_description', $prompt->short_description)); ?></textarea>

                    </label>

                </div>

            </section>


            

            <section class="bd-admin-form__section">

                <div class="bd-admin-form__section-head">

                    <strong>
                        Prompt Pertanyaan User
                    </strong>

                    <p>
                        Starter prompt yang otomatis masuk ke composer
                        ketika researcher memilih prompt ini.
                        User tetap dapat mengedit pertanyaannya sebelum dikirim.
                    </p>

                </div>


                <div class="bd-admin-form__grid">

                    <label
                        class="
                            bd-admin-form-field
                            is-full
                        "
                    >

                        <span>
                            Question Template
                            <small>
                                user-facing
                            </small>
                        </span>

                        <textarea
                            class="
                                bd-admin-textarea
                                bd-admin-codearea
                            "
                            name="question_template"
                            maxlength="5000"
                            placeholder="Contoh: Identifikasi research gap mengenai {topik} berdasarkan evidence yang tersedia."
                            <?php if($locked): echo 'readonly'; endif; ?>
                        ><?php echo e(old('question_template', $prompt->question_template)); ?></textarea>

                        <small
                            style="
                                display:block;
                                margin-top:8px;
                                line-height:1.6;
                            "
                        >
                            Gunakan placeholder seperti
                            <strong>{topik}</strong>,
                            <strong>{objek}</strong>,
                            atau
                            <strong>{fokus}</strong>.
                            Placeholder pertama akan otomatis terseleksi
                            saat template masuk ke composer.
                        </small>

                    </label>

                </div>

            </section>


            

            <section class="bd-admin-form__section">

                <div class="bd-admin-form__section-head">

                    <strong>
                        Prompt Jawaban AI
                    </strong>

                    <p>
                        Bagian internal ini mengatur cara AI bekerja.
                        User tidak melihat isinya secara mentah.
                    </p>

                </div>


                <div class="bd-admin-form__grid">

                    <label
                        class="
                            bd-admin-form-field
                            is-full
                        "
                    >

                        <span>
                            System Prompt
                        </span>

                        <textarea
                            class="
                                bd-admin-textarea
                                bd-admin-codearea
                            "
                            name="system_prompt"
                            maxlength="20000"
                            placeholder="Peran, batasan, dan behaviour utama AI..."
                            <?php if($locked): echo 'readonly'; endif; ?>
                        ><?php echo e(old('system_prompt', $prompt->system_prompt)); ?></textarea>

                    </label>


                    <label
                        class="
                            bd-admin-form-field
                            is-full
                        "
                    >

                        <span>
                            Task Prompt
                            <small>
                                wajib
                            </small>
                        </span>

                        <textarea
                            class="
                                bd-admin-textarea
                                bd-admin-codearea
                            "
                            name="task_prompt"
                            maxlength="30000"
                            placeholder="Apa pekerjaan akademik yang harus dilakukan AI..."
                            required
                            <?php if($locked): echo 'readonly'; endif; ?>
                        ><?php echo e(old('task_prompt', $prompt->task_prompt)); ?></textarea>

                    </label>


                    <label
                        class="
                            bd-admin-form-field
                            is-full
                        "
                    >

                        <span>
                            Retrieval Instructions
                        </span>

                        <textarea
                            class="
                                bd-admin-textarea
                                bd-admin-codearea
                            "
                            name="retrieval_instructions"
                            maxlength="20000"
                            placeholder="Evidence seperti apa yang harus diprioritaskan..."
                            <?php if($locked): echo 'readonly'; endif; ?>
                        ><?php echo e(old('retrieval_instructions', $prompt->retrieval_instructions)); ?></textarea>

                    </label>


                    <label
                        class="
                            bd-admin-form-field
                            is-full
                        "
                    >

                        <span>
                            Output Instructions
                        </span>

                        <textarea
                            class="
                                bd-admin-textarea
                                bd-admin-codearea
                            "
                            name="output_instructions"
                            maxlength="20000"
                            placeholder="Struktur dan format jawaban..."
                            <?php if($locked): echo 'readonly'; endif; ?>
                        ><?php echo e(old('output_instructions', $prompt->output_instructions)); ?></textarea>

                    </label>

                </div>

            </section>


            

            <section class="bd-admin-form__section">

                <div class="bd-admin-form__section-head">

                    <strong>
                        User-facing Education
                    </strong>

                    <p>
                        Informasi yang membantu researcher memahami
                        fungsi prompt sebelum menggunakannya.
                    </p>

                </div>


                <div class="bd-admin-form__grid">

                    <label
                        class="
                            bd-admin-form-field
                            is-full
                        "
                    >

                        <span>
                            Apa maksudnya?
                        </span>

                        <textarea
                            class="bd-admin-textarea"
                            name="meaning"
                            maxlength="5000"
                            <?php if($locked): echo 'readonly'; endif; ?>
                        ><?php echo e(old('meaning', $prompt->meaning)); ?></textarea>

                    </label>


                    <label class="bd-admin-form-field">

                        <span>
                            Digunakan untuk
                        </span>

                        <textarea
                            class="bd-admin-textarea"
                            name="when_to_use"
                            maxlength="5000"
                            <?php if($locked): echo 'readonly'; endif; ?>
                        ><?php echo e(old('when_to_use', $prompt->when_to_use)); ?></textarea>

                    </label>


                    <label class="bd-admin-form-field">

                        <span>
                            Jangan digunakan untuk
                        </span>

                        <textarea
                            class="bd-admin-textarea"
                            name="when_not_to_use"
                            maxlength="5000"
                            <?php if($locked): echo 'readonly'; endif; ?>
                        ><?php echo e(old('when_not_to_use', $prompt->when_not_to_use)); ?></textarea>

                    </label>


                    <label class="bd-admin-form-field">

                        <span>
                            Contoh Pertanyaan
                        </span>

                        <textarea
                            class="bd-admin-textarea"
                            name="example_text"
                            maxlength="5000"
                            <?php if($locked): echo 'readonly'; endif; ?>
                        ><?php echo e(old('example_text', $prompt->example_text)); ?></textarea>

                    </label>


                    <label class="bd-admin-form-field">

                        <span>
                            Expected Output
                        </span>

                        <textarea
                            class="bd-admin-textarea"
                            name="expected_output"
                            maxlength="5000"
                            <?php if($locked): echo 'readonly'; endif; ?>
                        ><?php echo e(old('expected_output', $prompt->expected_output)); ?></textarea>

                    </label>

                </div>

            </section>


            

            <?php if(! $locked): ?>

                <section class="bd-admin-form__section">

                    <div
                        class="bd-admin-inline-actions"
                        style="justify-content:flex-start;"
                    >

                        <button
                            class="
                                bd-admin-button
                                bd-admin-button--primary
                            "
                            type="submit"
                        >
                            <?php echo e($editing
                                    ? 'Simpan Draft'
                                    : 'Buat Prompt'); ?>

                        </button>


                        <a
                            href="<?php echo e(route('admin.prompts.index')); ?>"
                            class="
                                bd-admin-button
                                bd-admin-button--ghost
                            "
                        >
                            Batal
                        </a>

                    </div>

                </section>

            <?php endif; ?>

        </form>

    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/prompts/form.blade.php ENDPATH**/ ?>
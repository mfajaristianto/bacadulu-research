<?php $__env->startSection('title', 'Glossary'); ?>
<?php $__env->startSection('page_title', 'Glossary'); ?>

<?php $__env->startSection('content'); ?>

<section class="admin-page">

    <header class="bd-admin-page-head">

        <div class="bd-admin-page-head__copy">

            <p class="bd-admin-kicker">
                KNOWLEDGE / GLOSSARY
            </p>

            <h1>
                Research Glossary
            </h1>

            <p>
                Istilah membantu AI memahami konteks dan terminology.
                Glossary bukan evidence dan tidak dapat menjadi citation.
            </p>

        </div>

        <div class="bd-admin-page-head__actions">

            <a
                href="<?php echo e(route('admin.glossary.create')); ?>"
                class="bd-admin-button bd-admin-button--primary"
            >
                Tambah Istilah ＋
            </a>

        </div>

    </header>

    <form
        method="GET"
        class="bd-admin-filter"
    >

        <input
            class="bd-admin-input"
            type="search"
            name="search"
            value="<?php echo e(request('search')); ?>"
            placeholder="Cari istilah…"
        >

        <select
            class="bd-admin-select"
            name="category"
            data-auto-submit
        >

            <option value="">
                Semua category
            </option>

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <option
                    value="<?php echo e($category->id); ?>"
                    <?php if(
                        (string)
                            request('category')
                        ===
                        (string)
                            $category->id
                    ): echo 'selected'; endif; ?>
                >
                    <?php echo e($category->name); ?>

                </option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

        <select
            class="bd-admin-select"
            name="status"
            data-auto-submit
        >

            <option value="">
                Semua status
            </option>

            <option
                value="active"
                <?php if(
                    request('status')
                    ===
                    'active'
                ): echo 'selected'; endif; ?>
            >
                Active
            </option>

            <option
                value="inactive"
                <?php if(
                    request('status')
                    ===
                    'inactive'
                ): echo 'selected'; endif; ?>
            >
                Inactive
            </option>

        </select>

    </form>

    <div class="bd-admin-table-wrap">

        <table class="bd-admin-table">

            <thead>

                <tr>
                    <th>Term</th>
                    <th>Category</th>
                    <th>Aliases</th>
                    <th>Status</th>
                    <th></th>
                </tr>

            </thead>

            <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>

                        <td>

                            <div class="bd-admin-table__title">

                                <strong>
                                    <?php echo e($term->term); ?>

                                </strong>

                                <small>
                                    <?php echo e(\Illuminate\Support\Str::limit(
                                            $term->definition,
                                            105
                                        )); ?>

                                </small>

                            </div>

                        </td>

                        <td>
                            <?php echo e($term->category?->name ?: 'Global'); ?>

                        </td>

                        <td>

                            <?php if(
                                collect(
                                    $term->aliases_json
                                    ?? []
                                )->isNotEmpty()
                            ): ?>

                                <?php echo e(collect(
                                        $term->aliases_json
                                    )
                                        ->take(3)
                                        ->implode(', ')); ?>


                            <?php else: ?>
                                —
                            <?php endif; ?>

                        </td>

                        <td>

                            <span
                                class="
                                    bd-admin-status
                                    bd-admin-status--<?php echo e($term->status === 'active'
                                            ? 'active'
                                            : 'draft'); ?>

                                "
                            >
                                <?php echo e(ucfirst($term->status)); ?>

                            </span>

                        </td>

                        <td>

                            <a
                                class="bd-admin-table__action"
                                href="<?php echo e(route('admin.glossary.edit', $term)); ?>"
                            >
                                Edit →
                            </a>

                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td colspan="5">

                            <div class="bd-admin-empty">

                                <div class="bd-admin-empty__inner">

                                    <span class="bd-admin-empty__mark">
                                        TERM
                                    </span>

                                    <h3>
                                        Belum ada glossary.
                                    </h3>

                                    <p>
                                        Tambahkan istilah yang perlu
                                        dipahami secara konsisten oleh
                                        research engine.
                                    </p>

                                </div>

                            </div>

                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

    <?php echo e($terms->links()); ?>


</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views\admin\glossary\index.blade.php ENDPATH**/ ?>
<?php ($editing = $collection->exists); ?>

<?php $__env->startSection('title', $editing ? 'Edit Collection' : 'Tambah Collection'); ?>
<?php $__env->startSection('page_title', 'Collections'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-page">
    <header class="bd-admin-page-head">
        <div class="bd-admin-page-head__copy"><p class="bd-admin-kicker">KNOWLEDGE / COLLECTION</p><h1><?php echo e($editing ? 'Edit Collection' : 'Tambah Collection'); ?></h1><p>Pilih source yang ingin dikumpulkan dalam konteks yang sama.</p></div>
        <div class="bd-admin-page-head__actions"><a href="<?php echo e(route('admin.collections.index')); ?>" class="bd-admin-button bd-admin-button--ghost">← Collections</a></div>
    </header>

    <form method="POST" action="<?php echo e($editing ? route('admin.collections.update', $collection) : route('admin.collections.store')); ?>" class="bd-admin-form-shell">
        <?php echo csrf_field(); ?>
        <?php if($editing): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

        <div class="bd-admin-form">
            <section class="bd-admin-form__section">
                <div class="bd-admin-form__grid">
                    <label class="bd-admin-form-field is-full"><span>Nama Collection</span><input class="bd-admin-input" name="name" value="<?php echo e(old('name', $collection->name)); ?>" maxlength="180" required></label>
                    <label class="bd-admin-form-field is-full"><span>Deskripsi <small>opsional</small></span><textarea class="bd-admin-textarea" name="description" maxlength="2000"><?php echo e(old('description', $collection->description)); ?></textarea></label>
                    <label class="bd-admin-form-field"><span>Status</span><select class="bd-admin-select" name="status"><option value="active" <?php if(old('status', $collection->status ?: 'active') === 'active'): echo 'selected'; endif; ?>>Active</option><option value="archived" <?php if(old('status', $collection->status) === 'archived'): echo 'selected'; endif; ?>>Archived</option></select></label>
                </div>
            </section>

            <section class="bd-admin-form__section">
                <div class="bd-admin-form__section-head"><strong>Sources</strong><p>Collection tidak mengubah category utama source.</p></div>
                <div class="bd-admin-checklist">
                    <?php $__empty_1 = true; $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <label class="bd-admin-checkrow">
                            <input type="checkbox" name="document_ids[]" value="<?php echo e($document->id); ?>" <?php if(in_array($document->id, old('document_ids', $selectedDocuments), true)): echo 'checked'; endif; ?>>
                            <span><strong><?php echo e($document->title); ?></strong><small><?php echo e($document->category?->name ?: 'Tanpa kategori'); ?> · <?php echo e(ucfirst($document->status)); ?></small></span>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="bd-admin-muted">Belum ada source di Library.</p>
                    <?php endif; ?>
                </div>
            </section>

            <section class="bd-admin-form__section"><button class="bd-admin-button bd-admin-button--primary" type="submit"><?php echo e($editing ? 'Simpan Collection' : 'Buat Collection'); ?></button></section>
        </div>

        <aside class="bd-admin-form__aside"><section><strong>Collection</strong><p>Gunakan untuk grouping tematik, proyek, atau corpus tertentu. Jangan gunakan sebagai pengganti Category.</p></section></aside>
    </form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/collections/form.blade.php ENDPATH**/ ?>
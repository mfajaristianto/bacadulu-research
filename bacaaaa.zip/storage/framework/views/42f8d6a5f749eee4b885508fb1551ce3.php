

<?php
    $editing =
        $term->exists;

    $aliases =
        old(
            'aliases',
            collect(
                $term->aliases_json
                ?? []
            )->implode(', ')
        );
?>

<?php $__env->startSection(
    'title',
    $editing
        ? 'Edit Glossary'
        : 'Tambah Glossary'
); ?>

<?php $__env->startSection('page_title', 'Glossary'); ?>

<?php $__env->startSection('content'); ?>

<section class="admin-page">

    <header class="bd-admin-page-head">

        <div class="bd-admin-page-head__copy">

            <p class="bd-admin-kicker">
                KNOWLEDGE / GLOSSARY
            </p>

            <h1>
                <?php echo e($editing
                        ? $term->term
                        : 'Istilah Baru'); ?>

            </h1>

            <p>
                Glossary memberikan definisi terminology.
                Jangan masukkan hasil penelitian atau klaim empiris
                sebagai glossary.
            </p>

        </div>

        <div class="bd-admin-page-head__actions">

            <a
                href="<?php echo e(route('admin.glossary.index')); ?>"
                class="bd-admin-button bd-admin-button--ghost"
            >
                ← Glossary
            </a>

        </div>

    </header>

    <form
        method="POST"
        action="<?php echo e($editing
                ? route(
                    'admin.glossary.update',
                    $term
                )
                : route(
                    'admin.glossary.store'
                )); ?>"
        class="bd-admin-form-shell"
    >

        <?php echo csrf_field(); ?>

        <?php if($editing): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <div class="bd-admin-form">

            <section class="bd-admin-form__section">

                <div class="bd-admin-form__section-head">

                    <strong>
                        Terminology
                    </strong>

                    <p>
                        Global berarti dapat dipakai lintas category.
                    </p>

                </div>

                <div class="bd-admin-form__grid">

                    <label class="bd-admin-form-field">

                        <span>
                            Term
                        </span>

                        <input
                            class="bd-admin-input"
                            name="term"
                            maxlength="180"
                            value="<?php echo e(old(
                                    'term',
                                    $term->term
                                )); ?>"
                            required
                        >

                    </label>

                    <label class="bd-admin-form-field">

                        <span>
                            Category
                        </span>

                        <select
                            class="bd-admin-select"
                            name="category_id"
                        >

                            <option value="">
                                Global
                            </option>

                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option
                                    value="<?php echo e($category->id); ?>"
                                    <?php if(
                                        (string)
                                            old(
                                                'category_id',
                                                $term->category_id
                                            )
                                        ===
                                        (string)
                                            $category->id
                                    ): echo 'selected'; endif; ?>
                                >
                                    <?php echo e($category->name); ?>

                                </option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>

                    </label>

                    <label class="bd-admin-form-field">

                        <span>
                            Status
                        </span>

                        <select
                            class="bd-admin-select"
                            name="status"
                        >

                            <option
                                value="active"
                                <?php if(
                                    old(
                                        'status',
                                        $term->status
                                        ?: 'active'
                                    )
                                    ===
                                    'active'
                                ): echo 'selected'; endif; ?>
                            >
                                Active
                            </option>

                            <option
                                value="inactive"
                                <?php if(
                                    old(
                                        'status',
                                        $term->status
                                    )
                                    ===
                                    'inactive'
                                ): echo 'selected'; endif; ?>
                            >
                                Inactive
                            </option>

                        </select>

                    </label>

                    <label class="bd-admin-form-field is-full">

                        <span>
                            Aliases
                        </span>

                        <textarea
                            class="bd-admin-input"
                            name="aliases"
                            rows="3"
                            placeholder="ESG disclosure, environmental social governance"
                        ><?php echo e($aliases); ?></textarea>

                        <small>
                            Pisahkan menggunakan koma, titik koma, atau baris baru.
                        </small>

                    </label>

                    <label class="bd-admin-form-field is-full">

                        <span>
                            Definition
                        </span>

                        <textarea
                            class="bd-admin-input"
                            name="definition"
                            rows="7"
                            required
                        ><?php echo e(old('definition', $term->definition)); ?></textarea>

                    </label>

                    <label class="bd-admin-form-field is-full">

                        <span>
                            Context note
                            <small>opsional</small>
                        </span>

                        <textarea
                            class="bd-admin-input"
                            name="context_note"
                            rows="5"
                            placeholder="Contoh: bedakan ESG disclosure dari ESG performance."
                        ><?php echo e(old('context_note', $term->context_note)); ?></textarea>

                    </label>

                </div>

            </section>

            <section class="bd-admin-form__section">

                <div class="bd-admin-inline-actions">

                    <button
                        class="bd-admin-button bd-admin-button--primary"
                        type="submit"
                    >
                        <?php echo e($editing
                                ? 'Simpan Perubahan'
                                : 'Buat Istilah'); ?>

                    </button>

                </div>

            </section>

        </div>

    </form>

    <?php if(
        $editing
        &&
        $term->status === 'active'
    ): ?>

        <form
            method="POST"
            action="<?php echo e(route('admin.glossary.destroy', $term)); ?>"
            style="margin-top:18px;"
        >

            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>

            <button
                type="submit"
                class="bd-admin-button bd-admin-button--ghost"
            >
                Nonaktifkan Istilah
            </button>

        </form>

    <?php endif; ?>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views/admin/glossary/form.blade.php ENDPATH**/ ?>
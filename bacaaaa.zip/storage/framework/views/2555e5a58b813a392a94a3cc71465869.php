<?php $__env->startSection(
    'title',
    'Research History — BacaDulu Research'
); ?>

<?php $__env->startSection('content'); ?>

<section class="history-page">

    <header
        class="history-head"
        data-reveal
    >
        <div>
            <p class="eyebrow">
                RESEARCH HISTORY
            </p>

            <h1 class="display-type">
                Research yang pernah Anda kerjakan.
            </h1>

            <p>
                Buka kembali conversation,
                pin research penting,
                rename judul,
                atau hapus research yang
                sudah tidak diperlukan.
            </p>
        </div>

        <a
            href="<?php echo e(route('workspace')); ?>"
            class="btn btn-primary"
        >
            New Research
            <span>↗</span>
        </a>
    </header>

    <?php if(session('success')): ?>

        <div
            class="alert alert-success"
            role="status"
        >
            <?php echo e(session('success')); ?>

        </div>

    <?php endif; ?>

    <?php if($errors->any()): ?>

        <div
            class="alert alert-error"
            role="alert"
        >
            <?php echo e($errors->first()); ?>

        </div>

    <?php endif; ?>

    <div
        class="history-list"
        data-reveal
    >

        <?php $__empty_1 = true; $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <article
                class="
                    history-item
                    <?php echo e($item->pinned_at
                        ? 'is-pinned'
                        : ''); ?>

                "
            >

                <a
                    href="<?php echo e(route(
                        'workspace.conversation',
                        $item
                    )); ?>"
                    class="history-item__main"
                >

                    <div
                        class="
                            history-item__marker
                        "
                    >
                        <?php echo e($item->pinned_at
                            ? 'P'
                            : str_pad(
                                (string)
                                    $loop->iteration,
                                2,
                                '0',
                                STR_PAD_LEFT
                            )); ?>

                    </div>

                    <div
                        class="
                            history-item__copy
                        "
                    >

                        <div
                            class="
                                history-item__meta
                            "
                        >

                            <?php if(
                                $item->pinned_at
                            ): ?>
                                <span
                                    class="
                                        history-item__pin
                                    "
                                >
                                    PINNED
                                </span>
                            <?php endif; ?>

                            <span>
                                <?php echo e($item
                                        ->category
                                        ?->name
                                    ?: 'Research'); ?>

                            </span>

                            <span>·</span>

                            <span>
                                <?php echo e($item
                                        ->updated_at
                                        ->diffForHumans()); ?>

                            </span>

                        </div>

                        <h2>
                            <?php echo e($item->title); ?>

                        </h2>

                        <?php if(
                            $item->latestMessage
                        ): ?>

                            <p>
                                <?php echo e(Str::limit(
                                        $item
                                            ->latestMessage
                                            ->content,
                                        150
                                    )); ?>

                            </p>

                        <?php else: ?>

                            <p>
                                Belum ada pesan pada
                                conversation ini.
                            </p>

                        <?php endif; ?>

                    </div>

                    <div
                        class="
                            history-item__stats
                        "
                    >
                        <strong>
                            <?php echo e($item->messages_count); ?>

                        </strong>

                        <span>
                            pesan
                        </span>
                    </div>

                </a>

                <?php if (isset($component)) { $__componentOriginal845d2693f1ed032602bbf864fea7baa6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal845d2693f1ed032602bbf864fea7baa6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.conversation-actions','data' => ['conversation' => $item]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('conversation-actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['conversation' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal845d2693f1ed032602bbf864fea7baa6)): ?>
<?php $attributes = $__attributesOriginal845d2693f1ed032602bbf864fea7baa6; ?>
<?php unset($__attributesOriginal845d2693f1ed032602bbf864fea7baa6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal845d2693f1ed032602bbf864fea7baa6)): ?>
<?php $component = $__componentOriginal845d2693f1ed032602bbf864fea7baa6; ?>
<?php unset($__componentOriginal845d2693f1ed032602bbf864fea7baa6); ?>
<?php endif; ?>

            </article>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <div class="history-empty">

                <span>
                    00
                </span>

                <h2>
                    Belum ada research.
                </h2>

                <p>
                    Mulai research baru.
                    Conversation yang Anda buat
                    akan tersimpan di halaman ini.
                </p>

                <a
                    href="<?php echo e(route('workspace')); ?>"
                    class="btn btn-primary"
                >
                    Mulai Research
                </a>

            </div>

        <?php endif; ?>

    </div>

    <?php if(
        $conversations->hasPages()
    ): ?>

        <div class="history-pagination">
            <?php echo e($conversations->links()); ?>

        </div>

    <?php endif; ?>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Pkl\bacadulu-research\resources\views\history\index.blade.php ENDPATH**/ ?>
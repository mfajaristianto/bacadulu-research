<?php
    $isSetup = $mode === 'setup';

    $monthNames = [
        1 => 'Januari',
        2 => 'Februari',
        3 => 'Maret',
        4 => 'April',
        5 => 'Mei',
        6 => 'Juni',
        7 => 'Juli',
        8 => 'Agustus',
        9 => 'September',
        10 => 'Oktober',
        11 => 'November',
        12 => 'Desember',
    ];

    $completion = $user->profileCompletion();
?>

<form
    method="POST"
    action="<?php echo e(route('profile.update')); ?>"
    class="profile-form"
    enctype="multipart/form-data"
    data-profile-form
>
    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>

    <input
        type="hidden"
        name="profile_context"
        value="<?php echo e($isSetup ? 'setup' : 'edit'); ?>"
    >

    <section class="profile-form-section profile-form-section--photo">
        <div class="profile-section-heading">
            <div>
                <span class="profile-section-number">01</span>

                <div>
                    <h2>Foto profil</h2>
                    <p>
                        Gunakan foto yang jelas atau tetap gunakan
                        inisial sebagai fallback.
                    </p>
                </div>
            </div>
        </div>

        <div class="profile-photo-field">
            <div
                class="profile-photo-preview"
                data-avatar-preview
            >
                <span
                    class="profile-avatar-initials"
                    data-avatar-fallback
                >
                    <?php echo e($user->initials); ?>

                </span>

                <?php if($user->avatar_url): ?>
                    <img
                        src="<?php echo e($user->avatar_url); ?>"
                        alt="Foto profil <?php echo e($user->name); ?>"
                        class="profile-photo-preview-img"
                        data-avatar-image
                        decoding="async"
                        referrerpolicy="no-referrer"
                    >
                <?php endif; ?>
            </div>

            <div class="profile-photo-copy">
                <label for="avatar">
                    Upload / ganti foto
                </label>

                <p id="avatar-help">
                    JPG, JPEG, PNG, atau WebP.
                    Maksimum 3 MB.
                    Preview muncul sebelum disimpan.
                </p>

                <input
                    id="avatar"
                    type="file"
                    name="avatar"
                    accept="image/jpeg,image/png,image/webp"
                    aria-describedby="avatar-help"
                    data-avatar-input
                >

                <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="field-error">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </section>

    <section class="profile-form-section">
        <div class="profile-section-heading">
            <div>
                <span class="profile-section-number">02</span>

                <div>
                    <h2>Identitas</h2>
                    <p>
                        Informasi dasar untuk mengenali profil research Anda.
                    </p>
                </div>
            </div>
        </div>

        <div class="profile-fields-grid">
            <label for="profile-name">
                Nama lengkap

                <input
                    id="profile-name"
                    name="name"
                    value="<?php echo e(old('name', $user->name)); ?>"
                    autocomplete="name"
                    maxlength="120"
                    required
                >

                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="field-error">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label for="profile-email">
                Email

                <input
                    id="profile-email"
                    value="<?php echo e($user->email); ?>"
                    disabled
                >

                <small class="field-help">
                    Email mengikuti akun yang digunakan untuk login.
                </small>
            </label>

            <label for="profile-phone">
                Nomor telepon
                <span class="field-optional">Opsional</span>

                <input
                    id="profile-phone"
                    name="phone"
                    value="<?php echo e(old('phone', $user->phone)); ?>"
                    autocomplete="tel"
                    inputmode="tel"
                    maxlength="30"
                    placeholder="+62 812 3456 7890"
                >

                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="field-error">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label for="profile-institution">
                Institusi
                <span class="field-optional">Opsional</span>

                <input
                    id="profile-institution"
                    name="institution"
                    value="<?php echo e(old('institution', $user->institution)); ?>"
                    autocomplete="organization"
                    maxlength="180"
                    placeholder="Universitas / institusi / organisasi"
                >

                <?php $__errorArgs = ['institution'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="field-error">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
        </div>
    </section>

    <section class="profile-form-section">
        <div class="profile-section-heading">
            <div>
                <span class="profile-section-number">03</span>

                <div>
                    <h2>Informasi tambahan</h2>
                    <p>
                        Data ini membantu melengkapi profil Anda dan tidak
                        ditampilkan sebagai public profile.
                    </p>
                </div>
            </div>
        </div>

        <div class="profile-fields-grid">
            <fieldset class="profile-fieldset">
                <legend>
                    Tanggal lahir
                    <span class="field-optional">Opsional</span>
                </legend>

                <div
                    class="dob-grid"
                    data-dob-group
                >
                    <select
                        name="dob_month"
                        aria-label="Bulan lahir"
                        data-dob-month
                    >
                        <option value="">Bulan</option>

                        <?php $__currentLoopData = $monthNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monthNumber => $monthName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($monthNumber); ?>"
                                <?php if(
                                    old(
                                        'dob_month',
                                        $user->date_of_birth?->month
                                    ) == $monthNumber
                                ): echo 'selected'; endif; ?>
                            >
                                <?php echo e($monthName); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <select
                        name="dob_day"
                        aria-label="Tanggal lahir"
                        data-dob-day
                    >
                        <option value="">Tanggal</option>

                        <?php for($day = 1; $day <= 31; $day++): ?>
                            <option
                                value="<?php echo e($day); ?>"
                                <?php if(
                                    old(
                                        'dob_day',
                                        $user->date_of_birth?->day
                                    ) == $day
                                ): echo 'selected'; endif; ?>
                            >
                                <?php echo e($day); ?>

                            </option>
                        <?php endfor; ?>
                    </select>

                    <select
                        name="dob_year"
                        aria-label="Tahun lahir"
                        data-dob-year
                    >
                        <option value="">Tahun</option>

                        <?php for(
                            $year = now()->year;
                            $year >= now()->year - 100;
                            $year--
                        ): ?>
                            <option
                                value="<?php echo e($year); ?>"
                                <?php if(
                                    old(
                                        'dob_year',
                                        $user->date_of_birth?->year
                                    ) == $year
                                ): echo 'selected'; endif; ?>
                            >
                                <?php echo e($year); ?>

                            </option>
                        <?php endfor; ?>
                    </select>
                </div>

                <input
                    type="hidden"
                    name="date_of_birth"
                    value="<?php echo e(old(
                        'date_of_birth',
                        $user->date_of_birth?->format('Y-m-d')
                    )); ?>"
                    data-dob-output
                >

                <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="field-error">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </fieldset>

            <label
                for="profile-address"
                class="profile-address-field"
            >
                Alamat
                <span class="field-optional">Opsional</span>

                <textarea
                    id="profile-address"
                    name="address"
                    rows="5"
                    autocomplete="street-address"
                    maxlength="500"
                    placeholder="Kota atau alamat yang ingin dicantumkan pada profil"
                ><?php echo e(old('address', $user->address)); ?></textarea>

                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="field-error">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
        </div>
    </section>

    <?php if($isSetup): ?>
        <section class="profile-form-section profile-form-section--agreement">
            <label class="check-row profile-terms">
                <input
                    type="checkbox"
                    name="terms"
                    value="1"
                    <?php if(old('terms')): echo 'checked'; endif; ?>
                    required
                >

                <span>
                    Saya menyetujui penggunaan akun sesuai ketentuan
                    dan kebijakan privasi BacaDulu Research.
                </span>
            </label>

            <?php $__errorArgs = ['terms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="field-error">
                    <?php echo e($message); ?>

                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </section>
    <?php endif; ?>

    <div class="profile-actions">
        <div class="profile-actions-copy">
            <?php if($isSetup): ?>
                <strong>
                    Kelengkapan saat ini <?php echo e($completion); ?>%
                </strong>

                <span>
                    Minimum <?php echo e(config('research.profile_gate', 80)); ?>%
                    untuk membuka Research Workspace.
                </span>
            <?php else: ?>
                <strong>Simpan perubahan</strong>

                <span>
                    Perubahan avatar dan informasi profil akan
                    digunakan di seluruh workspace.
                </span>
            <?php endif; ?>
        </div>

        <div class="profile-actions-buttons">
            <?php if(
                ! $isSetup
                && $completion >= config('research.profile_gate', 80)
            ): ?>
                <a
                    href="<?php echo e(route('workspace')); ?>"
                    class="btn btn-secondary"
                >
                    Kembali
                </a>
            <?php endif; ?>

            <button
                type="submit"
                class="btn btn-primary"
                data-motion-button
            >
                <?php echo e($isSetup ? 'Simpan & Lanjutkan' : 'Simpan Perubahan'); ?>

            </button>
        </div>
    </div>
</form><?php /**PATH D:\Pkl\bacadulu-research\resources\views\components\profile-form.blade.php ENDPATH**/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="theme-color" content="#1A1A2E">
    <title><?php echo $__env->yieldContent('title', 'Admin Login — BacaDulu Research'); ?></title>
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="admin-auth-shell">
    <main class="admin-auth-main"><?php echo $__env->yieldContent('content'); ?></main>
</body>
</html>
<?php /**PATH D:\Pkl\bacadulu-research\resources\views/layouts/admin-auth.blade.php ENDPATH**/ ?>
<?php
    $user = auth()->user();
    $researchAccess = auth()->check()
        && $user->profileCompletion() >= config('research.profile_gate', 80);
?>

<header class="site-header">
    <nav class="navbar" aria-label="Navigasi utama">
        <a href="<?php echo e(route('home')); ?>" class="brand" aria-label="BacaDulu Research — beranda">
            <span>BacaDulu</span>
            <em>Research</em>
        </a>

        <div class="nav-links">
            <?php if(auth()->guard()->check()): ?>
                <?php if($researchAccess): ?>
                    <a
                        href="<?php echo e(route('workspace')); ?>"
                        class="<?php echo e(request()->routeIs('workspace*') ? 'is-active' : ''); ?>"
                        <?php echo request()->routeIs('workspace*') ? 'aria-current="page"' : ''; ?>

                    >
                        Research
                    </a>
                <?php endif; ?>

                <a
                    href="<?php echo e(route('profile.edit')); ?>"
                    class="avatar-link <?php echo e(request()->routeIs('profile.*') ? 'is-active' : ''); ?>"
                    aria-label="Buka profil"
                    <?php echo request()->routeIs('profile.*') ? 'aria-current="page"' : ''; ?>

                >
                    <?php if($user->avatar_url): ?>
                        <img
                            src="<?php echo e($user->avatar_url); ?>"
                            alt=""
                            class="avatar avatar-image"
                            data-avatar-image
                            decoding="async"
                            referrerpolicy="no-referrer"
                        >
                    <?php else: ?>
                        <span class="avatar avatar-fallback"><?php echo e($user->initials); ?></span>
                    <?php endif; ?>
                </a>

                <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline-form">
                    <?php echo csrf_field(); ?>
                    <button class="nav-logout" type="submit">Keluar</button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('home')); ?>#workflow">Cara Kerja</a>
                <a href="<?php echo e(route('home')); ?>#tools">Research Tools</a>
                <a href="<?php echo e(route('login')); ?>" class="login-btn">Masuk</a>
            <?php endif; ?>
        </div>

        <button
            class="mobile-toggle"
            type="button"
            aria-label="Buka navigasi"
            aria-expanded="false"
            aria-controls="mobile-navigation"
            data-mobile-menu
        >
            <span></span><span></span><span></span>
        </button>
    </nav>

    <div class="mobile-menu" id="mobile-navigation" data-mobile-panel aria-hidden="true">
        <?php if(auth()->guard()->check()): ?>
            <?php if($researchAccess): ?>
                <a href="<?php echo e(route('workspace')); ?>" <?php echo request()->routeIs('workspace*') ? 'aria-current="page"' : ''; ?>>
                    Research
                </a>
            <?php endif; ?>

            <a href="<?php echo e(route('profile.edit')); ?>" <?php echo request()->routeIs('profile.*') ? 'aria-current="page"' : ''; ?>>
                Profil Saya
            </a>

            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit">Keluar</button>
            </form>
        <?php else: ?>
            <a href="<?php echo e(route('home')); ?>#workflow">Cara Kerja</a>
            <a href="<?php echo e(route('home')); ?>#tools">Research Tools</a>
            <a href="<?php echo e(route('login')); ?>" class="mobile-login">Masuk</a>
        <?php endif; ?>
    </div>
</header>
<?php /**PATH D:\Pkl\bacadulu-research\resources\views/components/navbar.blade.php ENDPATH**/ ?>
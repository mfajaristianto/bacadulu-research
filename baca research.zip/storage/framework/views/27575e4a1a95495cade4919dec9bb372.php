<!doctype html>

<html lang="id">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <meta
        name="csrf-token"
        content="<?php echo e(csrf_token()); ?>"
    >

    <meta
        name="description"
        content="<?php echo $__env->yieldContent(
            'meta_description',
            'BacaDulu Research membantu pengguna bergerak dari pertanyaan penelitian menuju evidence, insight, dan dokumen yang siap digunakan.'
        ); ?>"
    >

    <meta
        name="theme-color"
        content="#17172B"
    >

    <title>
        <?php echo $__env->yieldContent(
            'title',
            'BacaDulu Research'
        ); ?>
    </title>


    <link
        rel="icon"
        href="<?php echo e(asset('favicon.ico')); ?>"
    >


    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/app.css',

        'resources/css/pages/research-output.css',

        'resources/js/app.js',

        'resources/js/research-output.js',

        'resources/js/auth-research.js',
    ]); ?>

</head>


<?php
    $isAuthPortal =
        request()
            ->routeIs(
                'login',
                'register',
                'google.link.*'
            );

    $isWorkspace =
        request()
            ->routeIs(
                'workspace*'
            );
?>


<body
    class="<?php echo e(collect([
            $isWorkspace
                ? 'research-chat-body'
                : null,

            $isAuthPortal
                ? 'research-auth-body'
                : null,
        ])
            ->filter()
            ->implode(' ')); ?>"
>

    <a
        class="skip-link"
        href="#main-content"
    >
        Lewati ke konten utama
    </a>


    <?php if (! ($isAuthPortal)): ?>

        <?php echo $__env->make(
            'components.navbar'
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php endif; ?>


    <main id="main-content">

        <?php echo $__env->yieldContent('content'); ?>

    </main>


    <?php if(
        ! $isWorkspace
        && ! $isAuthPortal
    ): ?>

        <?php echo $__env->make(
            'components.footer'
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php endif; ?>


    <div
        class="network-banner"
        data-network-banner
        role="status"
        aria-live="polite"
        hidden
    >
        Anda sedang offline.
        Input yang belum dikirim
        tetap dipertahankan di halaman ini.
    </div>

</body>

</html><?php /**PATH D:\Pkl\bacadulu-research\resources\views/layouts/app.blade.php ENDPATH**/ ?>
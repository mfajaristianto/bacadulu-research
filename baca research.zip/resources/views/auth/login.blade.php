@extends('layouts.app')

@section('title', 'Masuk — BacaDulu Research')

@section(
    'meta_description',
    'Masuk ke BacaDulu Research untuk melanjutkan research, evidence, conversation, dan dokumen Anda.'
)

@section('content')

<section
    class="
        research-auth
        research-auth--login
    "
    data-auth-portal
    data-auth-mode="login"
>

    <div
        class="research-auth__ambient"
        aria-hidden="true"
    >
        <span class="research-auth__orb research-auth__orb--one"></span>
        <span class="research-auth__orb research-auth__orb--two"></span>
        <span class="research-auth__orb research-auth__orb--three"></span>
    </div>


    <div class="research-auth__page">

        {{-- BACK --}}
        <div class="research-auth__topline">

            <a
                href="{{ route('home') }}"
                class="research-auth__back"
            >
                <span aria-hidden="true">
                    ←
                </span>

                Kembali ke situs
            </a>

        </div>


        <div class="research-auth__frame">

            {{-- =====================================================
                 INTERNAL HEADER
            ====================================================== --}}
            <header class="research-auth__header">

                <a
                    href="{{ route('home') }}"
                    class="research-auth__brand"
                    aria-label="BacaDulu Research"
                >
                    <span>
                        BacaDulu
                    </span>

                    <strong>
                        Research
                    </strong>
                </a>


                <nav
                    class="research-auth__tabs"
                    aria-label="Authentication"
                >

                    <a
                        href="{{ route('login') }}"
                        class="
                            research-auth__tab
                            is-active
                        "
                        aria-current="page"
                    >
                        Masuk
                    </a>

                    <a
                        href="{{ route('register') }}"
                        class="research-auth__tab"
                        data-auth-switch="register"
                    >
                        Daftar
                    </a>

                </nav>

            </header>


            {{-- =====================================================
                 STAGE
            ====================================================== --}}
            <div class="research-auth__stage">

                {{-- =================================================
                     VISUAL / RESEARCH STORY
                ================================================== --}}
                <aside class="research-auth__visual">

                    <div class="research-auth__visual-grid"></div>


                    <div class="research-auth__visual-copy">

                        <p class="research-auth__eyebrow">
                            BACADULU RESEARCH
                        </p>

                        <h1>
                            Lanjutkan research,
                            <span>
                                bukan mulai dari nol.
                            </span>
                        </h1>

                        <p>
                            Kembali ke conversation, evidence,
                            source, dan research output yang
                            sebelumnya Anda kerjakan.
                        </p>

                    </div>


                    {{-- RESEARCH PATH --}}
                    <div class="research-auth__path">

                        <div
                            class="research-auth__path-line"
                            aria-hidden="true"
                        ></div>


                        <div class="research-auth__path-item">

                            <span
                                class="
                                    research-auth__path-dot
                                    research-auth__path-dot--coral
                                "
                            ></span>

                            <small>
                                01
                            </small>

                            <strong>
                                Question
                            </strong>

                        </div>


                        <div class="research-auth__path-item">

                            <span
                                class="
                                    research-auth__path-dot
                                    research-auth__path-dot--teal
                                "
                            ></span>

                            <small>
                                02
                            </small>

                            <strong>
                                Retrieval
                            </strong>

                        </div>


                        <div class="research-auth__path-item">

                            <span class="research-auth__path-dot"></span>

                            <small>
                                03
                            </small>

                            <strong>
                                Analysis
                            </strong>

                        </div>


                        <div class="research-auth__path-item">

                            <span class="research-auth__path-dot"></span>

                            <small>
                                04
                            </small>

                            <strong>
                                Output
                            </strong>

                        </div>

                    </div>


                    {{-- =================================================
                         RESEARCH MINI WORKSPACE
                    ================================================== --}}
                    <div class="research-auth__workspace">

                        <div class="research-auth__workspace-head">

                            <div>

                                <small>
                                    RESEARCH SESSION
                                </small>

                                <strong>
                                    ESG & Firm Value
                                </strong>

                            </div>


                            <span class="research-auth__ready">

                                <span></span>

                                Evidence ready

                            </span>

                        </div>


                        <div class="research-auth__workspace-body">

                            <nav class="research-auth__mini-nav">

                                <span>
                                    Q
                                </span>

                                <span class="is-active">
                                    E
                                </span>

                                <span>
                                    A
                                </span>

                                <span>
                                    O
                                </span>

                            </nav>


                            <div class="research-auth__mini-content">

                                <div class="research-auth__mini-label">
                                    EVIDENCE
                                </div>

                                <div class="research-auth__mini-lines">

                                    <span></span>
                                    <span></span>
                                    <span></span>

                                </div>


                                <div class="research-auth__evidence-card">

                                    <span>
                                        E01
                                    </span>

                                    <div>

                                        <small>
                                            CURATED SOURCE
                                        </small>

                                        <strong>
                                            Relevant academic evidence
                                        </strong>

                                    </div>

                                </div>


                                <div class="research-auth__source-pills">

                                    <span>
                                        PDF
                                    </span>

                                    <span>
                                        Journal
                                    </span>

                                    <span>
                                        DOI
                                    </span>

                                </div>

                            </div>

                        </div>

                    </div>


                    {{-- FLOATING SOURCES --}}
                    <div
                        class="
                            research-auth__float-card
                            research-auth__float-card--source
                        "
                        aria-hidden="true"
                    >

                        <span class="research-auth__float-icon">

                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.7"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                            >
                                <path d="M6 3h9l3 3v15H6z"/>
                                <path d="M14 3v4h4"/>
                                <path d="M9 12h6"/>
                                <path d="M9 16h5"/>
                            </svg>

                        </span>

                        <div>
                            <small>
                                SOURCE
                            </small>

                            <strong>
                                Curated Evidence
                            </strong>
                        </div>

                    </div>


                    <div
                        class="
                            research-auth__float-card
                            research-auth__float-card--insight
                        "
                        aria-hidden="true"
                    >

                        <span class="research-auth__float-icon">

                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="1.7"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                            >
                                <circle
                                    cx="11"
                                    cy="11"
                                    r="6"
                                />

                                <path d="M16 16l4 4"/>
                                <path d="M8.5 11h5"/>
                                <path d="M11 8.5v5"/>
                            </svg>

                        </span>

                        <div>
                            <small>
                                NEXT
                            </small>

                            <strong>
                                Research Insight
                            </strong>
                        </div>

                    </div>


                    {{-- MOVING ORBIT --}}
                    <div
                        class="research-auth__orbit"
                        aria-hidden="true"
                    >

                        <span class="research-auth__orbit-dot"></span>
                        <span class="research-auth__orbit-dot"></span>
                        <span class="research-auth__orbit-dot"></span>

                    </div>

                </aside>


                {{-- =================================================
                     FORM
                ================================================== --}}
                <section class="research-auth__form-panel">

                    <div class="research-auth__form-inner">

                        <div class="research-auth__form-heading">

                            <p class="research-auth__eyebrow">
                                SELAMAT DATANG KEMBALI
                            </p>

                            <h2>
                                Masuk ke akun Anda.
                            </h2>

                            <p>
                                Lanjutkan research dari workspace
                                terakhir Anda.
                            </p>

                        </div>


                        @if ($errors->any())

                            <div
                                class="alert alert-error"
                                role="alert"
                            >
                                {{ $errors->first() }}
                            </div>

                        @endif


                        @if (session('success'))

                            <div
                                class="alert alert-success"
                                role="status"
                            >
                                {{ session('success') }}
                            </div>

                        @endif


                        {{-- GOOGLE --}}
                        <a
                            href="{{ route('google.redirect') }}"
                            class="research-auth__google"
                        >

                            <span
                                class="research-auth__google-mark"
                                aria-hidden="true"
                            >

                                <svg viewBox="0 0 24 24">

                                    <path
                                        fill="#4285F4"
                                        d="M21.35 12.2c0-.7-.06-1.2-.2-1.72H12v3.32h5.37a4.6 4.6 0 01-1.99 2.93l3.21 2.49c1.87-1.73 2.76-4.28 2.76-7.02z"
                                    />

                                    <path
                                        fill="#34A853"
                                        d="M12 21.7c2.68 0 4.93-.88 6.58-2.39l-3.21-2.49c-.89.6-2.03.96-3.37.96-2.58 0-4.77-1.74-5.56-4.09l-3.31 2.56A9.94 9.94 0 0012 21.7z"
                                    />

                                    <path
                                        fill="#FBBC05"
                                        d="M6.44 13.69A6.01 6.01 0 016.13 12c0-.59.1-1.16.31-1.69L3.13 7.75A9.99 9.99 0 002.05 12c0 1.54.39 3 1.08 4.25l3.31-2.56z"
                                    />

                                    <path
                                        fill="#EA4335"
                                        d="M12 6.22c1.46 0 2.77.5 3.8 1.48l2.85-2.85A9.55 9.55 0 0012 2.3a9.94 9.94 0 00-8.87 5.45l3.31 2.56C7.23 7.96 9.42 6.22 12 6.22z"
                                    />

                                </svg>

                            </span>

                            <span>
                                Lanjutkan dengan Google
                            </span>

                        </a>


                        <div class="research-auth__divider">

                            <span>
                                atau gunakan email
                            </span>

                        </div>


                        <form
                            method="POST"
                            action="{{ route('login.store') }}"
                            class="research-auth__form"
                        >

                            @csrf


                            <label for="login-email">

                                <span>
                                    Email
                                </span>

                                <div class="research-auth__input-wrap">

                                    <span
                                        class="research-auth__input-icon"
                                        aria-hidden="true"
                                    >

                                        <svg
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="1.7"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                        >
                                            <rect
                                                x="3"
                                                y="5"
                                                width="18"
                                                height="14"
                                                rx="2"
                                            />

                                            <path d="M3 7l9 6 9-6"/>

                                        </svg>

                                    </span>


                                    <input
                                        id="login-email"
                                        type="email"
                                        name="email"
                                        value="{{ old('email') }}"
                                        autocomplete="email"
                                        inputmode="email"
                                        placeholder="nama@email.com"
                                        required
                                        autofocus
                                    >

                                </div>

                                @error('email')

                                    <span class="field-error">
                                        {{ $message }}
                                    </span>

                                @enderror

                            </label>


                            <label for="login-password">

                                <span>
                                    Password
                                </span>

                                <div
                                    class="
                                        research-auth__input-wrap
                                        password-field
                                    "
                                >

                                    <span
                                        class="research-auth__input-icon"
                                        aria-hidden="true"
                                    >

                                        <svg
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="1.7"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                        >
                                            <rect
                                                x="5"
                                                y="10"
                                                width="14"
                                                height="10"
                                                rx="2"
                                            />

                                            <path
                                                d="M8 10V7a4 4 0 018 0v3"
                                            />

                                        </svg>

                                    </span>


                                    <input
                                        id="login-password"
                                        type="password"
                                        name="password"
                                        autocomplete="current-password"
                                        placeholder="Masukkan password"
                                        required
                                        data-password-input
                                    >


                                    <button
                                        type="button"
                                        class="
                                            password-toggle
                                            research-auth__password-toggle
                                        "
                                        aria-label="Tampilkan password"
                                        data-password-toggle
                                    >
                                        Show
                                    </button>

                                </div>

                                @error('password')

                                    <span class="field-error">
                                        {{ $message }}
                                    </span>

                                @enderror

                            </label>


                            <label class="research-auth__remember">

                                <input
                                    type="checkbox"
                                    name="remember"
                                    value="1"
                                    @checked(old('remember'))
                                >

                                <span>
                                    Ingat perangkat ini
                                </span>

                            </label>


                            <button
                                type="submit"
                                class="research-auth__submit"
                                data-motion-button
                            >

                                <span>
                                    Masuk
                                </span>

                                <span aria-hidden="true">
                                    →
                                </span>

                            </button>

                        </form>


                        <p class="research-auth__switch-copy">

                            Belum punya akun?

                            <a
                                href="{{ route('register') }}"
                                data-auth-switch="register"
                            >
                                Buat akun
                            </a>

                        </p>

                    </div>

                </section>

            </div>

        </div>


        <footer class="research-auth__footer">

            <span>
                © {{ now()->year }} BacaDulu Research
            </span>

            <span>
                Research with evidence,
                not just answers.
            </span>

        </footer>

    </div>

</section>

@endsection
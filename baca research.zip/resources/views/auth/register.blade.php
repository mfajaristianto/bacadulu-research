@extends('layouts.app')

@section('title', 'Daftar — BacaDulu Research')

@section(
    'meta_description',
    'Buat akun BacaDulu Research dan mulai membangun research workspace berbasis evidence.'
)

@section('content')

<section
    class="
        research-auth
        research-auth--register
    "
    data-auth-portal
    data-auth-mode="register"
>

    <div
        class="research-auth__ambient"
        aria-hidden="true"
    >
        <span class="research-auth__orb research-auth__orb--one"></span>
        <span class="research-auth__orb research-auth__orb--two"></span>
        <span class="research-auth__orb research-auth__orb--three"></span>
    </div>


    <div class="research-auth__page">

        <div class="research-auth__topline">

            <a
                href="{{ route('home') }}"
                class="research-auth__back"
            >
                <span aria-hidden="true">
                    ←
                </span>

                Kembali ke situs
            </a>

        </div>


        <div class="research-auth__frame">

            {{-- =====================================================
                 HEADER
            ====================================================== --}}
            <header class="research-auth__header">

                <a
                    href="{{ route('home') }}"
                    class="research-auth__brand"
                    aria-label="BacaDulu Research"
                >
                    <span>
                        BacaDulu
                    </span>

                    <strong>
                        Research
                    </strong>
                </a>


                <nav
                    class="research-auth__tabs"
                    aria-label="Authentication"
                >

                    <a
                        href="{{ route('login') }}"
                        class="research-auth__tab"
                        data-auth-switch="login"
                    >
                        Masuk
                    </a>

                    <a
                        href="{{ route('register') }}"
                        class="
                            research-auth__tab
                            is-active
                        "
                        aria-current="page"
                    >
                        Daftar
                    </a>

                </nav>

            </header>


            {{-- =====================================================
                 STAGE
            ====================================================== --}}
            <div class="research-auth__stage">

                {{-- =================================================
                     REGISTER FORM
                ================================================== --}}
                <section class="research-auth__form-panel">

                    <div class="research-auth__form-inner">

                        <div class="research-auth__form-heading">

                            <p class="research-auth__eyebrow">
                                MULAI DI BACADULU RESEARCH
                            </p>

                            <h2>
                                Buat akun baru.
                            </h2>

                            <p>
                                Mulai menyimpan conversation,
                                evidence, dan research output Anda.
                            </p>

                        </div>


                        @if ($errors->any())

                            <div
                                class="alert alert-error"
                                role="alert"
                            >
                                {{ $errors->first() }}
                            </div>

                        @endif


                        {{-- GOOGLE --}}
                        <a
                            href="{{ route('google.redirect') }}"
                            class="research-auth__google"
                        >

                            <span
                                class="research-auth__google-mark"
                                aria-hidden="true"
                            >

                                <svg viewBox="0 0 24 24">

                                    <path
                                        fill="#4285F4"
                                        d="M21.35 12.2c0-.7-.06-1.2-.2-1.72H12v3.32h5.37a4.6 4.6 0 01-1.99 2.93l3.21 2.49c1.87-1.73 2.76-4.28 2.76-7.02z"
                                    />

                                    <path
                                        fill="#34A853"
                                        d="M12 21.7c2.68 0 4.93-.88 6.58-2.39l-3.21-2.49c-.89.6-2.03.96-3.37.96-2.58 0-4.77-1.74-5.56-4.09l-3.31 2.56A9.94 9.94 0 0012 21.7z"
                                    />

                                    <path
                                        fill="#FBBC05"
                                        d="M6.44 13.69A6.01 6.01 0 016.13 12c0-.59.1-1.16.31-1.69L3.13 7.75A9.99 9.99 0 002.05 12c0 1.54.39 3 1.08 4.25l3.31-2.56z"
                                    />

                                    <path
                                        fill="#EA4335"
                                        d="M12 6.22c1.46 0 2.77.5 3.8 1.48l2.85-2.85A9.55 9.55 0 0012 2.3a9.94 9.94 0 00-8.87 5.45l3.31 2.56C7.23 7.96 9.42 6.22 12 6.22z"
                                    />

                                </svg>

                            </span>

                            <span>
                                Daftar dengan Google
                            </span>

                        </a>


                        <div class="research-auth__divider">

                            <span>
                                atau gunakan email
                            </span>

                        </div>


                        <form
                            method="POST"
                            action="{{ route('register.store') }}"
                            class="
                                research-auth__form
                                research-auth__form--register
                            "
                        >

                            @csrf


                            {{-- NAME --}}
                            <label
                                for="register-name"
                                class="research-auth__span-two"
                            >

                                <span>
                                    Nama lengkap
                                </span>

                                <div class="research-auth__input-wrap">

                                    <span
                                        class="research-auth__input-icon"
                                        aria-hidden="true"
                                    >

                                        <svg
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="1.7"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                        >
                                            <circle
                                                cx="12"
                                                cy="8"
                                                r="4"
                                            />

                                            <path
                                                d="M5 21a7 7 0 0114 0"
                                            />

                                        </svg>

                                    </span>


                                    <input
                                        id="register-name"
                                        type="text"
                                        name="name"
                                        value="{{ old('name') }}"
                                        autocomplete="name"
                                        maxlength="120"
                                        placeholder="Nama sesuai identitas"
                                        required
                                    >

                                </div>

                                @error('name')

                                    <span class="field-error">
                                        {{ $message }}
                                    </span>

                                @enderror

                            </label>


                            {{-- EMAIL --}}
                            <label
                                for="register-email"
                                class="research-auth__span-two"
                            >

                                <span>
                                    Email
                                </span>

                                <div class="research-auth__input-wrap">

                                    <span
                                        class="research-auth__input-icon"
                                        aria-hidden="true"
                                    >

                                        <svg
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="1.7"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                        >
                                            <rect
                                                x="3"
                                                y="5"
                                                width="18"
                                                height="14"
                                                rx="2"
                                            />

                                            <path d="M3 7l9 6 9-6"/>

                                        </svg>

                                    </span>


                                    <input
                                        id="register-email"
                                        type="email"
                                        name="email"
                                        value="{{ old('email') }}"
                                        autocomplete="email"
                                        inputmode="email"
                                        placeholder="nama@email.com"
                                        required
                                    >

                                </div>

                                @error('email')

                                    <span class="field-error">
                                        {{ $message }}
                                    </span>

                                @enderror

                            </label>


                            {{-- PASSWORD --}}
                            <label for="register-password">

                                <span>
                                    Password
                                </span>

                                <div
                                    class="
                                        research-auth__input-wrap
                                        password-field
                                    "
                                >

                                    <span
                                        class="research-auth__input-icon"
                                        aria-hidden="true"
                                    >

                                        <svg
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="1.7"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                        >
                                            <rect
                                                x="5"
                                                y="10"
                                                width="14"
                                                height="10"
                                                rx="2"
                                            />

                                            <path
                                                d="M8 10V7a4 4 0 018 0v3"
                                            />

                                        </svg>

                                    </span>


                                    <input
                                        id="register-password"
                                        type="password"
                                        name="password"
                                        autocomplete="new-password"
                                        placeholder="Buat password"
                                        required
                                        data-password-input
                                    >


                                    <button
                                        type="button"
                                        class="
                                            password-toggle
                                            research-auth__password-toggle
                                        "
                                        aria-label="Tampilkan password"
                                        data-password-toggle
                                    >
                                        Show
                                    </button>

                                </div>

                                @error('password')

                                    <span class="field-error">
                                        {{ $message }}
                                    </span>

                                @enderror

                            </label>


                            {{-- CONFIRM --}}
                            <label for="register-password-confirmation">

                                <span>
                                    Ulangi password
                                </span>

                                <div
                                    class="
                                        research-auth__input-wrap
                                        password-field
                                    "
                                >

                                    <span
                                        class="research-auth__input-icon"
                                        aria-hidden="true"
                                    >

                                        <svg
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="1.7"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                        >
                                            <rect
                                                x="5"
                                                y="10"
                                                width="14"
                                                height="10"
                                                rx="2"
                                            />

                                            <path
                                                d="M8 10V7a4 4 0 018 0v3"
                                            />

                                        </svg>

                                    </span>


                                    <input
                                        id="register-password-confirmation"
                                        type="password"
                                        name="password_confirmation"
                                        autocomplete="new-password"
                                        placeholder="Ulangi password"
                                        required
                                        data-password-input
                                    >


                                    <button
                                        type="button"
                                        class="
                                            password-toggle
                                            research-auth__password-toggle
                                        "
                                        aria-label="Tampilkan konfirmasi password"
                                        data-password-toggle
                                    >
                                        Show
                                    </button>

                                </div>

                            </label>


                            {{-- PROFILE GATE --}}
                            <div
                                class="
                                    research-auth__profile-gate
                                    research-auth__span-two
                                "
                            >

                                <div class="research-auth__profile-score">

                                    <strong>
                                        80%
                                    </strong>

                                    <span>
                                        PROFILE
                                    </span>

                                </div>


                                <div>

                                    <strong>
                                        Lengkapi profil setelah daftar.
                                    </strong>

                                    <p>
                                        Research Workspace terbuka setelah
                                        kelengkapan profil mencapai minimal
                                        80%.
                                    </p>

                                </div>

                            </div>


                            <button
                                class="
                                    research-auth__submit
                                    research-auth__span-two
                                    research-auth__submit--coral
                                "
                                type="submit"
                                data-motion-button
                            >

                                <span>
                                    Buat akun
                                </span>

                                <span aria-hidden="true">
                                    →
                                </span>

                            </button>

                        </form>


                        <p class="research-auth__switch-copy">

                            Sudah punya akun?

                            <a
                                href="{{ route('login') }}"
                                data-auth-switch="login"
                            >
                                Masuk
                            </a>

                        </p>

                    </div>

                </section>


                {{-- =================================================
                     REGISTER VISUAL
                ================================================== --}}
                <aside class="research-auth__visual">

                    <div class="research-auth__visual-grid"></div>


                    <div class="research-auth__visual-copy">

                        <p class="research-auth__eyebrow">
                            RESEARCH WORKSPACE
                        </p>

                        <h1>
                            Buat akun,
                            <span>
                                mulai jelajah riset.
                            </span>
                        </h1>

                        <p>
                            Gunakan Research Tool, curated sources,
                            evidence, dan document workflow dalam
                            satu workspace.
                        </p>

                    </div>


                    {{-- REGISTER JOURNEY --}}
                    <div class="research-auth__path">

                        <div
                            class="research-auth__path-line"
                            aria-hidden="true"
                        ></div>


                        <div class="research-auth__path-item">

                            <span
                                class="
                                    research-auth__path-dot
                                    research-auth__path-dot--coral
                                "
                            ></span>

                            <small>
                                01
                            </small>

                            <strong>
                                Daftar
                            </strong>

                        </div>


                        <div class="research-auth__path-item">

                            <span
                                class="
                                    research-auth__path-dot
                                    research-auth__path-dot--teal
                                "
                            ></span>

                            <small>
                                02
                            </small>

                            <strong>
                                Verifikasi
                            </strong>

                        </div>


                        <div class="research-auth__path-item">

                            <span class="research-auth__path-dot"></span>

                            <small>
                                03
                            </small>

                            <strong>
                                Profile 80%
                            </strong>

                        </div>


                        <div class="research-auth__path-item">

                            <span class="research-auth__path-dot"></span>

                            <small>
                                04
                            </small>

                            <strong>
                                Mulai riset
                            </strong>

                        </div>

                    </div>


                    {{-- RESEARCH ECOSYSTEM --}}
                    <div
                        class="
                            research-auth__ecosystem
                        "
                        aria-hidden="true"
                    >

                        <div class="research-auth__ecosystem-core">

                            <span class="research-auth__ecosystem-mark">
                                BD
                            </span>

                            <strong>
                                Research
                            </strong>

                        </div>


                        <div
                            class="
                                research-auth__eco-card
                                research-auth__eco-card--sources
                            "
                        >

                            <span>

                                <svg
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    stroke-width="1.7"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                >
                                    <path d="M6 3h9l3 3v15H6z"/>
                                    <path d="M14 3v4h4"/>
                                    <path d="M9 12h6"/>
                                    <path d="M9 16h5"/>
                                </svg>

                            </span>

                            <small>
                                CURATED
                            </small>

                            <strong>
                                Sources
                            </strong>

                        </div>


                        <div
                            class="
                                research-auth__eco-card
                                research-auth__eco-card--ai
                            "
                        >

                            <span>

                                <svg
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    stroke-width="1.7"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                >
                                    <path d="M12 3l1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5z"/>
                                    <path d="M18.5 15l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8z"/>
                                </svg>

                            </span>

                            <small>
                                AI RESEARCH
                            </small>

                            <strong>
                                Assistant
                            </strong>

                        </div>


                        <div
                            class="
                                research-auth__eco-card
                                research-auth__eco-card--evidence
                            "
                        >

                            <span>

                                <svg
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    stroke-width="1.7"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                >
                                    <circle
                                        cx="11"
                                        cy="11"
                                        r="6"
                                    />

                                    <path d="M16 16l4 4"/>
                                    <path d="M8 11h6"/>
                                </svg>

                            </span>

                            <small>
                                VALIDATED
                            </small>

                            <strong>
                                Evidence
                            </strong>

                        </div>


                        <div
                            class="
                                research-auth__eco-card
                                research-auth__eco-card--workspace
                            "
                        >

                            <span>

                                <svg
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    stroke-width="1.7"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                >
                                    <path d="M3 7h7l2 2h9v11H3z"/>
                                    <path d="M3 7V5h7l2 2"/>
                                </svg>

                            </span>

                            <small>
                                PERSONAL
                            </small>

                            <strong>
                                Workspace
                            </strong>

                        </div>


                        <span
                            class="
                                research-auth__eco-node
                                research-auth__eco-node--one
                            "
                        ></span>

                        <span
                            class="
                                research-auth__eco-node
                                research-auth__eco-node--two
                            "
                        ></span>

                        <span
                            class="
                                research-auth__eco-node
                                research-auth__eco-node--three
                            "
                        ></span>

                    </div>

                </aside>

            </div>

        </div>


        <footer class="research-auth__footer">

            <span>
                © {{ now()->year }} BacaDulu Research
            </span>

            <span>
                Dari pertanyaan menuju evidence.
            </span>

        </footer>

    </div>

</section>

@endsection
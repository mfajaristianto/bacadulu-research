import { gsap } from 'gsap';


const ready = (callback) => {
    if (document.readyState === 'loading') {
        document.addEventListener(
            'DOMContentLoaded',
            callback,
            {
                once: true,
            },
        );

        return;
    }

    callback();
};


ready(() => {
    const card =
        document.querySelector(
            '[data-auth-card]',
        );


    if (!card) {
        return;
    }


    const panes = [
        ...card.querySelectorAll(
            '[data-auth-pane]',
        ),
    ];


    const heroes = [
        ...card.querySelectorAll(
            '[data-auth-hero]',
        ),
    ];


    const links = [
        ...card.querySelectorAll(
            'a[data-auth-view]',
        ),
    ];


    const visual =
        card.querySelector(
            '[data-auth-visual]',
        );


    const grid =
        card.querySelector(
            '[data-auth-grid]',
        );


    const wave =
        card.querySelector(
            '[data-auth-wave]',
        );


    const wavePath =
        card.querySelector(
            '[data-auth-wave-path]',
        );


    const routes = [
        ...card.querySelectorAll(
            '[data-auth-route]',
        ),
    ];


    const packets = [
        ...card.querySelectorAll(
            '[data-auth-packet]',
        ),
    ];


    const sources = [
        ...card.querySelectorAll(
            '[data-auth-source]',
        ),
    ];


    const tiles = [
        ...card.querySelectorAll(
            '[data-auth-tile]',
        ),
    ];


    const output =
        card.querySelector(
            '[data-auth-output]',
        );


    const reducedMotion =
        window.matchMedia(
            '(prefers-reduced-motion: reduce)',
        );


    /*
    |--------------------------------------------------------------------------
    | Password toggle
    |--------------------------------------------------------------------------
    */

    card
        .querySelectorAll(
            '[data-auth-password-toggle]',
        )
        .forEach(
            (button) => {
                button.addEventListener(
                    'click',
                    () => {
                        const input =
                            document.getElementById(
                                button.dataset.target,
                            );


                        if (!input) {
                            return;
                        }


                        const showing =
                            input.type
                            === 'password';


                        input.type =
                            showing
                                ? 'text'
                                : 'password';


                        button.textContent =
                            showing
                                ? 'Hide'
                                : 'Show';
                    },
                );
            },
        );


    /*
    |--------------------------------------------------------------------------
    | Wave paths
    |--------------------------------------------------------------------------
    */

    const waveStart =
        'M -170 0 C -60 90 -260 210 -160 300 C -60 420 -240 520 -140 600 L -320 600 L -320 0 Z';


    const waveCover =
        'M 1200 0 C 1310 90 1110 210 1210 300 C 1310 420 1130 520 1230 600 L -320 600 L -320 0 Z';


    const waveEnd =
        'M 1350 0 C 1460 90 1260 210 1360 300 C 1460 420 1280 520 1380 600 L 1200 600 L 1200 0 Z';


    let transition = null;


    /*
    |--------------------------------------------------------------------------
    | Background motion
    |--------------------------------------------------------------------------
    */

    if (!reducedMotion.matches) {

        gsap.to(
            '.research-auth-final__blob--coral',
            {
                x: 24,
                y: 17,
                scale: 1.04,

                duration: 7,

                repeat: -1,

                yoyo: true,

                ease: 'sine.inOut',
            },
        );


        gsap.to(
            '.research-auth-final__blob--teal',
            {
                x: -21,
                y: 19,

                duration: 6.4,

                repeat: -1,

                yoyo: true,

                ease: 'sine.inOut',
            },
        );


        gsap.to(
            '.research-auth-final__blob--blue',
            {
                x: -25,
                y: 26,

                duration: 8,

                repeat: -1,

                yoyo: true,

                ease: 'sine.inOut',
            },
        );


        gsap.to(
            '.research-auth-final__blob--peach',
            {
                x: -24,
                y: -18,

                duration: 9,

                repeat: -1,

                yoyo: true,

                ease: 'sine.inOut',
            },
        );


        gsap.to(
            '.research-auth-final__bubble',
            {
                y: -13,

                duration: 3,

                stagger: {
                    each: .35,

                    repeat: -1,

                    yoyo: true,
                },

                ease: 'sine.inOut',
            },
        );


        /*
        |--------------------------------------------------------------------------
        | Grid
        |--------------------------------------------------------------------------
        */

        if (grid) {
            gsap.to(
                grid,
                {
                    backgroundPosition:
                        '28px 28px',

                    duration: 12,

                    repeat: -1,

                    ease: 'none',
                },
            );
        }


        /*
        |--------------------------------------------------------------------------
        | Login visual
        |--------------------------------------------------------------------------
        */

        tiles.forEach(
            (tile, index) => {
                gsap.to(
                    tile,
                    {
                        y:
                            index % 2 === 0
                                ? -6
                                : 6,

                        x:
                            index % 2 === 0
                                ? 2
                                : -2,

                        duration:
                            3.1
                            + (
                                index
                                * .35
                            ),

                        repeat: -1,

                        yoyo: true,

                        ease:
                            'sine.inOut',
                    },
                );
            },
        );


        /*
        |--------------------------------------------------------------------------
        | Register arrows
        |--------------------------------------------------------------------------
        */

        routes.forEach(
            (route) => {
                gsap.set(
                    route,
                    {
                        strokeDasharray:
                            '7 8',

                        strokeDashoffset:
                            30,
                    },
                );


                gsap.to(
                    route,
                    {
                        strokeDashoffset:
                            0,

                        duration:
                            2.1,

                        repeat: -1,

                        ease: 'none',
                    },
                );
            },
        );


        /*
        |--------------------------------------------------------------------------
        | Moving packets
        |--------------------------------------------------------------------------
        */

        packets.forEach(
            (
                packet,
                index,
            ) => {
                const startX =
                    Number(
                        packet.dataset
                            .startX,
                    );


                const startY =
                    Number(
                        packet.dataset
                            .startY,
                    );


                const endX =
                    Number(
                        packet.dataset
                            .endX,
                    );


                const endY =
                    Number(
                        packet.dataset
                            .endY,
                    );


                gsap.set(
                    packet,
                    {
                        attr: {
                            cx: startX,
                            cy: startY,
                        },

                        autoAlpha: 0,

                        transformOrigin:
                            '50% 50%',
                    },
                );


                gsap.timeline({
                    repeat: -1,

                    repeatDelay:
                        .8,

                    delay:
                        index
                        * .45,
                })
                    .to(
                        packet,
                        {
                            autoAlpha: 1,

                            scale: 1,

                            duration: .15,
                        },
                    )
                    .to(
                        packet,
                        {
                            attr: {
                                cx: endX,
                                cy: endY,
                            },

                            duration:
                                1.25,

                            ease:
                                'power1.inOut',
                        },
                    )
                    .to(
                        packet,
                        {
                            autoAlpha: 0,

                            scale: .5,

                            duration: .2,
                        },
                    );
            },
        );


        /*
        |--------------------------------------------------------------------------
        | Register source cards
        |--------------------------------------------------------------------------
        */

        sources.forEach(
            (
                source,
                index,
            ) => {
                gsap.to(
                    source,
                    {
                        y:
                            index % 2 === 0
                                ? -5
                                : 5,

                        duration:
                            3
                            + (
                                index
                                * .25
                            ),

                        repeat: -1,

                        yoyo: true,

                        ease:
                            'sine.inOut',
                    },
                );
            },
        );


        if (output) {
            gsap.to(
                output,
                {
                    y: -5,

                    duration: 3.5,

                    repeat: -1,

                    yoyo: true,

                    ease:
                        'sine.inOut',
                },
            );
        }
    }


    /*
    |--------------------------------------------------------------------------
    | View state
    |--------------------------------------------------------------------------
    */

    const applyView = (
        view,
        {
            updateHistory = false,
        } = {},
    ) => {
        if (
            view !== 'signin'
            && view !== 'signup'
        ) {
            return;
        }


        card.dataset.view =
            view;


        panes.forEach(
            (pane) => {
                const active =
                    pane.dataset.authPane
                    === view;


                pane.inert =
                    !active;


                pane.setAttribute(
                    'aria-hidden',
                    String(
                        !active,
                    ),
                );
            },
        );


        heroes.forEach(
            (hero) => {
                hero.setAttribute(
                    'aria-hidden',
                    String(
                        hero.dataset.authHero
                        !== view,
                    ),
                );
            },
        );


        links.forEach(
            (link) => {
                if (
                    link.dataset.authView
                    === view
                ) {
                    link.setAttribute(
                        'aria-current',
                        'page',
                    );
                } else {
                    link.removeAttribute(
                        'aria-current',
                    );
                }
            },
        );


        document.title =
            view === 'signup'
                ? 'Daftar — BacaDulu Research'
                : 'Masuk — BacaDulu Research';


        if (updateHistory) {
            const destination =
                links.find(
                    (link) =>
                        link.dataset
                            .authView
                        === view,
                );


            if (destination) {
                history.pushState(
                    {
                        authView:
                            view,
                    },
                    '',
                    destination.href,
                );
            }
        }


        /*
         * Supaya waktu swap nggak nyangkut
         * di scroll position lama.
         */
        window.scrollTo({
            top: 0,

            behavior:
                'smooth',
        });
    };


    /*
    |--------------------------------------------------------------------------
    | Wave transition
    |--------------------------------------------------------------------------
    */

    const switchView = (
        view,
        {
            updateHistory = false,
        } = {},
    ) => {
        if (
            view
            === card.dataset.view
            || transition
        ) {
            return;
        }


        if (
            reducedMotion.matches
            || !wave
            || !wavePath
        ) {
            applyView(
                view,
                {
                    updateHistory,
                },
            );

            return;
        }


        const origin =
            card.dataset.view
            === 'signup'
                ? 'right'
                : 'left';


        gsap.set(
            wave,
            {
                visibility:
                    'visible',

                scaleX:
                    origin
                    === 'right'
                        ? -1
                        : 1,

                transformOrigin:
                    '50% 50%',
            },
        );


        gsap.set(
            wavePath,
            {
                attr: {
                    d: waveStart,
                },
            },
        );


        transition =
            gsap.timeline({
                onComplete:
                    () => {
                        gsap.set(
                            wave,
                            {
                                visibility:
                                    'hidden',
                            },
                        );


                        gsap.set(
                            wavePath,
                            {
                                attr: {
                                    d:
                                        waveStart,
                                },
                            },
                        );


                        transition =
                            null;
                    },
            });


        transition

            .to(
                visual,
                {
                    scale: .975,

                    rotation:
                        origin
                        === 'right'
                            ? -1
                            : 1,

                    duration:
                        .20,

                    ease:
                        'sine.inOut',
                },
                0,
            )

            .to(
                wavePath,
                {
                    attr: {
                        d:
                            waveCover,
                    },

                    duration:
                        .36,

                    ease:
                        'sine.inOut',
                },
                0,
            )

            .call(
                () => {
                    applyView(
                        view,
                        {
                            updateHistory,
                        },
                    );
                },
            )

            .to(
                wavePath,
                {
                    attr: {
                        d:
                            waveEnd,
                    },

                    duration:
                        .38,

                    ease:
                        'sine.inOut',
                },
            )

            .to(
                visual,
                {
                    scale: 1,

                    rotation: 0,

                    duration:
                        .24,

                    ease:
                        'power2.out',
                },
                '-=.24',
            );
    };


    /*
    |--------------------------------------------------------------------------
    | Entry animation
    |--------------------------------------------------------------------------
    */

    if (!reducedMotion.matches) {
        gsap.fromTo(
            card,
            {
                autoAlpha: 0,

                y: 8,
            },
            {
                autoAlpha: 1,

                y: 0,

                duration: .40,

                ease:
                    'power2.out',

                clearProps:
                    'transform,opacity,visibility',
            },
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Links
    |--------------------------------------------------------------------------
    */

    links.forEach(
        (link) => {
            link.addEventListener(
                'click',
                (event) => {
                    if (
                        event.defaultPrevented
                        || event.button
                            !== 0
                        || event.metaKey
                        || event.ctrlKey
                        || event.shiftKey
                        || event.altKey
                    ) {
                        return;
                    }


                    event.preventDefault();


                    switchView(
                        link.dataset
                            .authView,
                        {
                            updateHistory:
                                true,
                        },
                    );
                },
            );
        },
    );


    /*
    |--------------------------------------------------------------------------
    | Browser back / forward
    |--------------------------------------------------------------------------
    */

    window.addEventListener(
        'popstate',
        () => {
            const view =
                location.pathname
                    .replace(
                        /\/$/,
                        '',
                    )
                    .endsWith(
                        '/register',
                    )
                    ? 'signup'
                    : 'signin';


            if (transition) {
                transition.progress(
                    1,
                );
            }


            switchView(
                view,
            );
        },
    );
});